#!/usr/bin/env python3
"""
Comprehensive test script for the Agent Analysis and Simulation Framework
"""

import os
import sys
import subprocess
import json
import time
from pathlib import Path

class Colors:
    GREEN = '\033[92m'
    RED = '\033[91m'
    YELLOW = '\033[93m'
    BLUE = '\033[94m'
    RESET = '\033[0m'
    BOLD = '\033[1m'

def print_header(text):
    print(f"\n{Colors.BOLD}{Colors.BLUE}{'='*60}{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.BLUE}{text.center(60)}{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.BLUE}{'='*60}{Colors.RESET}\n")

def print_test(test_name, status, message=""):
    if status == "PASS":
        print(f"{Colors.GREEN}✓ {test_name}: PASS{Colors.RESET}")
    elif status == "FAIL":
        print(f"{Colors.RED}✗ {test_name}: FAIL - {message}{Colors.RESET}")
    elif status == "WARN":
        print(f"{Colors.YELLOW}⚠ {test_name}: WARNING - {message}{Colors.RESET}")
    else:
        print(f"  {test_name}: {status}")

def run_command(cmd, timeout=30):
    """Run a command and return (success, output, error)"""
    try:
        result = subprocess.run(
            cmd, 
            shell=True, 
            capture_output=True, 
            text=True, 
            encoding='utf-8',
            errors='replace',
            timeout=timeout
        )
        return result.returncode == 0, result.stdout or "", result.stderr or ""
    except subprocess.TimeoutExpired:
        return False, "", "Command timed out"
    except Exception as e:
        return False, "", str(e)

def test_data_analysis():
    """Test the data analysis functionality"""
    print_header("Testing Data Analysis")
    
    tests_passed = 0
    tests_total = 0
    
    # Test 1: Check if analyze_agent_dump.py exists
    tests_total += 1
    if os.path.exists("scripts/analyze_agent_dump.py"):
        print_test("Script exists", "PASS")
        tests_passed += 1
    else:
        print_test("Script exists", "FAIL", "analyze_agent_dump.py not found")
        return tests_passed, tests_total
    
    # Test 2: Test help command
    tests_total += 1
    success, output, error = run_command("python scripts/analyze_agent_dump.py --help")
    if success and "usage:" in output:
        print_test("Help command", "PASS")
        tests_passed += 1
    else:
        print_test("Help command", "FAIL", error)
    
    # Test 3: Test summary generation
    tests_total += 1
    success, output, error = run_command("python scripts/analyze_agent_dump.py --summary --dir data/agent_0")
    if success:
        print_test("Summary generation", "PASS")
        tests_passed += 1
    else:
        print_test("Summary generation", "FAIL", error)
    
    # Test 4: Check if summary files are created
    tests_total += 1
    summary_files_exist = (
        os.path.exists("analysis/agent_analysis.summary.json") or 
        os.path.exists("agent_analysis.summary.json")
    )
    if summary_files_exist:
        print_test("Summary files created", "PASS")
        tests_passed += 1
    else:
        print_test("Summary files created", "WARN", "Summary files not in expected location")
    
    return tests_passed, tests_total

def test_simulation():
    """Test the simulation functionality"""
    print_header("Testing Simulation Scripts")
    
    tests_passed = 0
    tests_total = 0
    
    scripts = ["h.py", "ha.py", "hat.py", "hats.py"]
    
    for script in scripts:
        tests_total += 1
        if os.path.exists(f"scripts/{script}"):
            success, output, error = run_command(f"python scripts/{script}", timeout=10)
            if success:
                print_test(f"{script} execution", "PASS")
                tests_passed += 1
            else:
                print_test(f"{script} execution", "FAIL", error[:100])
        else:
            print_test(f"{script} exists", "FAIL", f"{script} not found")
    
    return tests_passed, tests_total

def test_directory_structure():
    """Test if the directory structure is correct"""
    print_header("Testing Directory Structure")
    
    tests_passed = 0
    tests_total = 0
    
    expected_dirs = ["data", "analysis", "scripts", "images"]
    for dir_name in expected_dirs:
        tests_total += 1
        if os.path.isdir(dir_name):
            print_test(f"{dir_name}/ directory", "PASS")
            tests_passed += 1
        else:
            print_test(f"{dir_name}/ directory", "FAIL", "Directory not found")
    
    # Check agent subdirectories
    for i in range(5):
        tests_total += 1
        agent_dir = f"data/agent_{i}"
        if os.path.isdir(agent_dir):
            print_test(f"{agent_dir}/ directory", "PASS")
            tests_passed += 1
        else:
            print_test(f"{agent_dir}/ directory", "FAIL", "Directory not found")
    
    return tests_passed, tests_total

def test_data_files():
    """Test if data files exist and are valid"""
    print_header("Testing Data Files")
    
    tests_passed = 0
    tests_total = 0
    
    # Check for data files in agent directories
    for i in range(5):
        agent_dir = f"data/agent_{i}"
        if os.path.isdir(agent_dir):
            files = os.listdir(agent_dir)
            tests_total += 1
            if files:
                print_test(f"agent_{i} has data files", "PASS")
                tests_passed += 1
            else:
                print_test(f"agent_{i} has data files", "WARN", "No data files found")
    
    return tests_passed, tests_total

def main():
    """Run all tests"""
    print_header("AGENT FRAMEWORK COMPREHENSIVE TEST SUITE")
    
    total_passed = 0
    total_tests = 0
    
    # Run all test suites
    test_suites = [
        ("Directory Structure", test_directory_structure),
        ("Data Files", test_data_files),
        ("Data Analysis", test_data_analysis),
        ("Simulation", test_simulation)
    ]
    
    results = []
    for suite_name, test_func in test_suites:
        passed, total = test_func()
        total_passed += passed
        total_tests += total
        results.append((suite_name, passed, total))
    
    # Print summary
    print_header("TEST SUMMARY")
    
    for suite_name, passed, total in results:
        percentage = (passed / total * 100) if total > 0 else 0
        status_color = Colors.GREEN if percentage == 100 else Colors.YELLOW if percentage >= 50 else Colors.RED
        print(f"{status_color}{suite_name}: {passed}/{total} ({percentage:.1f}%){Colors.RESET}")
    
    print(f"\n{Colors.BOLD}Total: {total_passed}/{total_tests} ({total_passed/total_tests*100:.1f}%){Colors.RESET}")
    
    if total_passed == total_tests:
        print(f"\n{Colors.GREEN}{Colors.BOLD}All tests passed! 🎉{Colors.RESET}")
    else:
        print(f"\n{Colors.YELLOW}{Colors.BOLD}Some tests failed or have warnings. Please review.{Colors.RESET}")

if __name__ == "__main__":
    main() 