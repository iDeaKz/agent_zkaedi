#!/usr/bin/env python3
"""
Critical Path Load Testing Script
=================================

Runs focused load tests on critical optimization endpoints with adaptive scaling.

Usage:
    python scripts/run_critical_load_test.py --target http://localhost:8000 --duration 5m
"""

import subprocess
import sys
import argparse
import time
import json
from pathlib import Path

def run_locust_test(target_host: str, duration: str, users: int = 200, spawn_rate: int = 20, 
                   tags: str = "critical", output_prefix: str = "critical_run"):
    """
    Run Locust load test with specified parameters.
    """
    cmd = [
        "locust",
        "-f", "dashboard/load_tests/locustfile.py",
        "--headless",
        "-u", str(users),
        "-r", str(spawn_rate),
        "-t", duration,
        "--host", target_host,
        "--tags", tags,
        "--csv", output_prefix,
        "--html", f"{output_prefix}_report.html"
    ]
    
    print(f"🚀 Starting load test:")
    print(f"   Target: {target_host}")
    print(f"   Users: {users} (spawn rate: {spawn_rate}/s)")
    print(f"   Duration: {duration}")
    print(f"   Tags: {tags}")
    print(f"   Command: {' '.join(cmd)}")
    print()
    
    try:
        result = subprocess.run(cmd, check=True, capture_output=True, text=True)
        print("✅ Load test completed successfully")
        return True
    except subprocess.CalledProcessError as e:
        print(f"❌ Load test failed: {e}")
        print(f"STDOUT: {e.stdout}")
        print(f"STDERR: {e.stderr}")
        return False

def analyze_results(output_prefix: str):
    """
    Analyze load test results and print summary.
    """
    stats_file = f"{output_prefix}_stats.csv"
    
    if not Path(stats_file).exists():
        print(f"⚠️  Stats file {stats_file} not found")
        return
    
    try:
        import pandas as pd
        
        stats = pd.read_csv(stats_file)
        
        # Focus on critical endpoints
        critical_endpoints = stats[stats['Name'].str.contains('/api/v1/optimize|/agents', na=False)]
        
        print("\n📊 Load Test Results Summary:")
        print("=" * 50)
        
        for _, row in critical_endpoints.iterrows():
            endpoint = row['Name']
            requests = row.get('Request Count', 0)
            failures = row.get('Failure Count', 0)
            avg_resp = row.get('Average Response Time', 0)
            p95_resp = row.get('95%', 0)
            
            error_rate = (failures / max(requests, 1)) * 100
            
            print(f"\n🎯 {endpoint}:")
            print(f"   Requests: {requests:,}")
            print(f"   Failures: {failures} ({error_rate:.2f}%)")
            print(f"   Avg Response: {avg_resp:.1f}ms")
            print(f"   P95 Response: {p95_resp:.1f}ms")
            
            # Performance assessment
            if p95_resp < 200 and error_rate < 0.1:
                print("   Status: ✅ EXCELLENT")
            elif p95_resp < 500 and error_rate < 1.0:
                print("   Status: ⚠️  ACCEPTABLE")
            else:
                print("   Status: ❌ NEEDS ATTENTION")
        
        # Overall summary
        total_requests = stats['Request Count'].sum()
        total_failures = stats['Failure Count'].sum()
        overall_error_rate = (total_failures / max(total_requests, 1)) * 100
        
        print(f"\n🏆 Overall Performance:")
        print(f"   Total Requests: {total_requests:,}")
        print(f"   Total Failures: {total_failures}")
        print(f"   Overall Error Rate: {overall_error_rate:.2f}%")
        
    except ImportError:
        print("⚠️  pandas not available for analysis")
    except Exception as e:
        print(f"⚠️  Analysis failed: {e}")

def run_performance_gate(output_prefix: str):
    """
    Run performance gate validation.
    """
    stats_file = f"{output_prefix}_stats.csv"
    rss_file = "rss.log"
    
    print("\n🔒 Running Performance Gate Validation...")
    
    cmd = [
        "python", "ci/perf_gate.py",
        "--locust-stats", stats_file,
        "--output", f"{output_prefix}_gate_report.json"
    ]
    
    if Path(rss_file).exists():
        cmd.extend(["--rss-log", rss_file])
    
    try:
        result = subprocess.run(cmd, check=True)
        print("✅ Performance gate validation passed")
        return True
    except subprocess.CalledProcessError:
        print("❌ Performance gate validation failed")
        return False

def main():
    """Main execution function."""
    parser = argparse.ArgumentParser(description="Run critical path load tests")
    parser.add_argument("--target", default="http://localhost:8000", 
                       help="Target host for load testing")
    parser.add_argument("--duration", default="5m", 
                       help="Test duration (e.g., 5m, 30s)")
    parser.add_argument("--users", type=int, default=200, 
                       help="Number of concurrent users")
    parser.add_argument("--spawn-rate", type=int, default=20, 
                       help="User spawn rate per second")
    parser.add_argument("--tags", default="critical", 
                       help="Locust tags to run")
    parser.add_argument("--output", default="critical_run", 
                       help="Output file prefix")
    parser.add_argument("--skip-gate", action="store_true", 
                       help="Skip performance gate validation")
    
    args = parser.parse_args()
    
    print("🎯 Critical Path Load Testing")
    print("=" * 40)
    
    # Run load test
    success = run_locust_test(
        target_host=args.target,
        duration=args.duration,
        users=args.users,
        spawn_rate=args.spawn_rate,
        tags=args.tags,
        output_prefix=args.output
    )
    
    if not success:
        sys.exit(1)
    
    # Analyze results
    analyze_results(args.output)
    
    # Run performance gate (if not skipped)
    if not args.skip_gate:
        gate_passed = run_performance_gate(args.output)
        if not gate_passed:
            sys.exit(1)
    
    print("\n🎉 Load testing completed successfully!")

if __name__ == "__main__":
    main()