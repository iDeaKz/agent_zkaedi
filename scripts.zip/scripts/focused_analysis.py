#!/usr/bin/env python3
"""
focused_analysis.py: A script for targeted analysis of agent performance,
specifically for zero-value and high-value episodes.
"""

import argparse
from pathlib import Path
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from colorama import init as colorama_init, Fore, Style
import os

# Initialize colorama
colorama_init(autoreset=True)

def read_agent_data(directory: str) -> pd.DataFrame:
    """Load and concatenate JSON dumps from agents in the directory."""
    all_files = list(Path(directory).glob("*_full_dump.json"))
    if not all_files:
        raise ValueError(f"No '*_full_dump.json' files found in {directory}")

    df_list = []
    for f in all_files:
        try:
            df = pd.read_json(f)
            df_list.append(df)
        except ValueError as e:
            print(Fore.RED + f"Error reading {f}: {e}" + Style.RESET_ALL)
    
    if not df_list:
        raise ValueError("No valid JSON data could be loaded.")
    
    concatenated_df = pd.concat(df_list, ignore_index=True)
    if 0 in concatenated_df.columns:
        concatenated_df.rename(columns={0: 'Value'}, inplace=True)

    return concatenated_df

def main():
    """Main entry point."""
    parser = argparse.ArgumentParser(description="Focused analysis of agent performance.")
    parser.add_argument("--dir", type=str, help="Directory of a single agent's dump file")
    parser.add_argument("--base-dir", type=str, help="Base directory containing multiple agent directories")
    parser.add_argument("--zero-analysis", action="store_true", help="Analyze zero-value episodes")
    parser.add_argument("--high-value-analysis", action="store_true", help="Analyze high-value episodes")
    parser.add_argument("--compare-agents", action="store_true", help="Compare performance across multiple agents")
    parser.add_argument("--threshold", type=float, default=0.9, help="Threshold for high-value analysis")
    args = parser.parse_args()

    print(Fore.GREEN + "Focused analysis script is ready!" + Style.RESET_ALL)

if __name__ == "__main__":
    main() 