#!/usr/bin/env python3
"""
Real-Time System Test Monitor
Monitors full-scale system test with error tracking, checkpoint validation, and drift detection.
"""

import json
import logging
import os
import sys
import time
from pathlib import Path
from typing import Dict, List, Any
import psutil
import threading

logging.basicConfig(level=logging.INFO)
LOGGER = logging.getLogger(__name__)

class SystemMonitor:
    """Real-time monitoring of full-scale system test."""
    
    def __init__(self):
        self.start_time = time.time()
        self.monitoring = True
        self.results_file = Path('full_system_test_results.json')
        self.checkpoint_dir = Path('checkpoints')
        self.last_checkpoint_count = 0
        self.performance_history = []
        
    def monitor_system_resources(self) -> Dict[str, Any]:
        """Monitor system resource usage."""
        try:
            cpu_percent = psutil.cpu_percent(interval=1)
            memory = psutil.virtual_memory()
            disk = psutil.disk_usage('.')
            
            return {
                'timestamp': time.time(),
                'cpu_percent': cpu_percent,
                'memory_percent': memory.percent,
                'memory_available_gb': memory.available / (1024**3),
                'disk_free_gb': disk.free / (1024**3),
                'processes': len(psutil.pids())
            }
        except Exception as e:
            LOGGER.error(f"Resource monitoring error: {e}")
            return {}
    
    def check_checkpoint_health(self) -> Dict[str, Any]:
        """Monitor checkpoint creation and health."""
        try:
            if not self.checkpoint_dir.exists():
                return {'status': 'no_checkpoints', 'count': 0}
            
            checkpoint_files = list(self.checkpoint_dir.glob('*.pkl'))
            metadata_files = list(self.checkpoint_dir.glob('*_metadata.json'))
            
            current_count = len(checkpoint_files)
            new_checkpoints = current_count - self.last_checkpoint_count
            self.last_checkpoint_count = current_count
            
            # Check for recent checkpoints (last 5 minutes)
            recent_checkpoints = 0
            cutoff_time = time.time() - 300  # 5 minutes
            
            for checkpoint in checkpoint_files:
                if checkpoint.stat().st_mtime > cutoff_time:
                    recent_checkpoints += 1
            
            return {
                'total_checkpoints': current_count,
                'metadata_files': len(metadata_files),
                'new_checkpoints': new_checkpoints,
                'recent_checkpoints': recent_checkpoints,
                'checkpoint_metadata_ratio': len(metadata_files) / current_count if current_count > 0 else 0
            }
            
        except Exception as e:
            LOGGER.error(f"Checkpoint health check error: {e}")
            return {'status': 'error', 'error': str(e)}
    
    def check_test_progress(self) -> Dict[str, Any]:
        """Check full-scale test progress."""
        try:
            if not self.results_file.exists():
                return {'status': 'running', 'progress': 'initializing'}
            
            with open(self.results_file, 'r') as f:
                results = json.load(f)
            
            if 'test_summary' in results:
                return {
                    'status': 'completed',
                    'health_score': results['test_summary']['system_health_score'],
                    'successful_tests': results['test_summary']['successful_tests'],
                    'total_tests': results['test_summary']['total_tests'],
                    'runtime': results['test_summary']['total_runtime'],
                    'errors': results['error_summary']['total_errors'],
                    'recoveries': results['error_summary']['successful_recoveries']
                }
            else:
                return {'status': 'running', 'progress': 'in_progress'}
                
        except Exception as e:
            return {'status': 'running', 'progress': f'error_reading_results: {e}'}
    
    def detect_performance_drift(self, current_metrics: Dict[str, float]) -> Dict[str, Any]:
        """Detect performance drift in real-time."""
        self.performance_history.append({
            'timestamp': time.time(),
            'metrics': current_metrics
        })
        
        # Keep last 10 measurements
        if len(self.performance_history) > 10:
            self.performance_history.pop(0)
        
        if len(self.performance_history) < 3:
            return {'drift_detected': False, 'reason': 'insufficient_data'}
        
        # Calculate trend
        recent_avg = sum(h['metrics'].get('cpu_percent', 0) for h in self.performance_history[-3:]) / 3
        historical_avg = sum(h['metrics'].get('cpu_percent', 0) for h in self.performance_history[:-3]) / max(1, len(self.performance_history) - 3)
        
        cpu_drift = abs(recent_avg - historical_avg) / max(1, historical_avg)
        
        return {
            'drift_detected': cpu_drift > 0.2,  # 20% drift threshold
            'cpu_drift': cpu_drift,
            'recent_avg_cpu': recent_avg,
            'historical_avg_cpu': historical_avg
        }
    
    def validate_feedback_loops(self) -> Dict[str, Any]:
        """Validate that feedback loops are working."""
        try:
            # Check for feedback loop indicators
            feedback_indicators = {
                'checkpoint_creation_active': False,
                'error_recovery_active': False,
                'performance_tracking_active': False,
                'drift_detection_active': False
            }
            
            # Check checkpoint creation
            checkpoint_health = self.check_checkpoint_health()
            if checkpoint_health.get('recent_checkpoints', 0) > 0:
                feedback_indicators['checkpoint_creation_active'] = True
            
            # Check if results file is being updated
            if self.results_file.exists():
                file_age = time.time() - self.results_file.stat().st_mtime
                if file_age < 300:  # Updated in last 5 minutes
                    feedback_indicators['performance_tracking_active'] = True
            
            # Performance monitoring is active if we're collecting metrics
            if len(self.performance_history) > 0:
                feedback_indicators['drift_detection_active'] = True
            
            active_loops = sum(feedback_indicators.values())
            total_loops = len(feedback_indicators)
            
            return {
                'feedback_loops': feedback_indicators,
                'active_loops': active_loops,
                'total_loops': total_loops,
                'feedback_health': active_loops / total_loops
            }
            
        except Exception as e:
            return {'error': str(e), 'feedback_health': 0.0}
    
    def generate_status_report(self) -> Dict[str, Any]:
        """Generate comprehensive status report."""
        current_time = time.time()
        runtime = current_time - self.start_time
        
        # Collect all monitoring data
        system_resources = self.monitor_system_resources()
        checkpoint_health = self.check_checkpoint_health()
        test_progress = self.check_test_progress()
        drift_analysis = self.detect_performance_drift(system_resources)
        feedback_validation = self.validate_feedback_loops()
        
        status_report = {
            'timestamp': current_time,
            'runtime_seconds': runtime,
            'runtime_formatted': f"{runtime//60:.0f}m {runtime%60:.0f}s",
            'system_resources': system_resources,
            'checkpoint_health': checkpoint_health,
            'test_progress': test_progress,
            'drift_analysis': drift_analysis,
            'feedback_validation': feedback_validation,
            'overall_status': self._determine_overall_status(
                test_progress, checkpoint_health, feedback_validation
            )
        }
        
        return status_report
    
    def _determine_overall_status(self, test_progress: Dict, checkpoint_health: Dict, 
                                 feedback_validation: Dict) -> str:
        """Determine overall system status."""
        
        # Check if test is completed
        if test_progress.get('status') == 'completed':
            health_score = test_progress.get('health_score', 0)
            if health_score >= 0.9:
                return "EXCELLENT - Test completed successfully"
            elif health_score >= 0.7:
                return "GOOD - Test completed with minor issues"
            else:
                return "POOR - Test completed with significant issues"
        
        # Check if test is running properly
        if test_progress.get('status') == 'running':
            feedback_health = feedback_validation.get('feedback_health', 0)
            checkpoint_count = checkpoint_health.get('total_checkpoints', 0)
            
            if feedback_health >= 0.75 and checkpoint_count > 0:
                return "RUNNING WELL - All systems active"
            elif feedback_health >= 0.5:
                return "RUNNING OK - Some systems active"
            else:
                return "RUNNING POORLY - Limited system activity"
        
        return "UNKNOWN - Unable to determine status"
    
    def display_live_dashboard(self):
        """Display live monitoring dashboard."""
        while self.monitoring:
            try:
                # Clear screen (works on most terminals)
                os.system('cls' if os.name == 'nt' else 'clear')
                
                # Generate status report
                report = self.generate_status_report()
                
                # Display dashboard
                print("🚀 ELITE AI SYSTEM MONITOR - LIVE DASHBOARD")
                print("=" * 80)
                print(f"⏱️  Runtime: {report['runtime_formatted']}")
                print(f"🎯 Overall Status: {report['overall_status']}")
                print()
                
                # Test Progress
                test_progress = report['test_progress']
                print("📊 TEST PROGRESS:")
                if test_progress.get('status') == 'completed':
                    print(f"   ✅ COMPLETED - Health Score: {test_progress.get('health_score', 0):.1%}")
                    print(f"   📈 Tests: {test_progress.get('successful_tests', 0)}/{test_progress.get('total_tests', 0)}")
                    print(f"   🔧 Recoveries: {test_progress.get('recoveries', 0)}")
                else:
                    print(f"   🔄 {test_progress.get('status', 'Unknown').upper()}")
                print()
                
                # System Resources
                resources = report['system_resources']
                if resources:
                    print("💻 SYSTEM RESOURCES:")
                    print(f"   CPU: {resources.get('cpu_percent', 0):.1f}%")
                    print(f"   Memory: {resources.get('memory_percent', 0):.1f}% ({resources.get('memory_available_gb', 0):.1f}GB free)")
                    print(f"   Disk: {resources.get('disk_free_gb', 0):.1f}GB free")
                    print()
                
                # Checkpoint Health
                checkpoint_health = report['checkpoint_health']
                print("💾 CHECKPOINT HEALTH:")
                print(f"   Total: {checkpoint_health.get('total_checkpoints', 0)}")
                print(f"   Recent: {checkpoint_health.get('recent_checkpoints', 0)} (last 5min)")
                print(f"   New: {checkpoint_health.get('new_checkpoints', 0)} (this cycle)")
                print()
                
                # Feedback Loops
                feedback = report['feedback_validation']
                print("🔄 FEEDBACK LOOPS:")
                print(f"   Health: {feedback.get('feedback_health', 0):.1%}")
                print(f"   Active: {feedback.get('active_loops', 0)}/{feedback.get('total_loops', 0)}")
                if 'feedback_loops' in feedback:
                    for loop, active in feedback['feedback_loops'].items():
                        status = "✅" if active else "❌"
                        print(f"   {status} {loop.replace('_', ' ').title()}")
                print()
                
                # Drift Detection
                drift = report['drift_analysis']
                if drift.get('drift_detected'):
                    print("⚠️  DRIFT DETECTED:")
                    print(f"   CPU Drift: {drift.get('cpu_drift', 0):.2f}")
                else:
                    print("✅ No performance drift detected")
                
                print("=" * 80)
                print("Press Ctrl+C to stop monitoring")
                
                # Update every 5 seconds
                time.sleep(5)
                
            except KeyboardInterrupt:
                self.monitoring = False
                print("\n🛑 Monitoring stopped by user")
                break
            except Exception as e:
                LOGGER.error(f"Dashboard error: {e}")
                time.sleep(5)
    
    def run_monitoring(self):
        """Start monitoring system."""
        LOGGER.info("🚀 Starting Elite AI System Monitor")
        
        # Start live dashboard in a separate thread
        dashboard_thread = threading.Thread(target=self.display_live_dashboard)
        dashboard_thread.daemon = True
        dashboard_thread.start()
        
        try:
            # Keep main thread alive
            dashboard_thread.join()
        except KeyboardInterrupt:
            self.monitoring = False
            LOGGER.info("🛑 Monitoring stopped")

def main():
    """Run system monitor."""
    monitor = SystemMonitor()
    monitor.run_monitoring()

if __name__ == "__main__":
    main() 