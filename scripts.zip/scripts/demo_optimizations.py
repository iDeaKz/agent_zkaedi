#!/usr/bin/env python3
"""
Performance Optimization Demonstration
======================================

Demonstrates the various optimization techniques implemented for memory optimization.

Usage:
    python scripts/demo_optimizations.py
"""

import time
import json
import sys
from pathlib import Path

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent.parent))

def generate_test_data(size: int, none_percentage: float = 0.25):
    """Generate test data with specified percentage of None values."""
    data = {}
    for i in range(size):
        if i < (size * none_percentage):
            data[f"key_{i}"] = None
        else:
            data[f"key_{i}"] = f"value_{i}"
    return data

def demo_basic_optimization():
    """Demonstrate basic memory optimization."""
    print("🧪 Basic Memory Optimization Demo")
    print("=" * 40)
    
    from project_module.utils import vector_embedding_optimizer
    
    # Test with different data sizes
    test_sizes = [100, 1000, 5000]
    
    for size in test_sizes:
        test_data = generate_test_data(size, none_percentage=0.3)
        
        print(f"\n📊 Testing with {size} elements (30% None values):")
        print(f"   Input keys: {len(test_data)}")
        print(f"   None values: {sum(1 for v in test_data.values() if v is None)}")
        
        # Time the optimization
        start_time = time.perf_counter()
        result = vector_embedding_optimizer(test_data, strategy="memory")
        end_time = time.perf_counter()
        
        duration = end_time - start_time
        ops_per_sec = 1 / duration if duration > 0 else 0
        
        # Analyze result
        output_keys = len([k for k in result.keys() if not k.startswith("_")])
        removed_count = len(test_data) - output_keys
        
        print(f"   Output keys: {output_keys}")
        print(f"   None removed: {removed_count}")
        print(f"   Duration: {duration*1000:.2f}ms")
        print(f"   Performance: {ops_per_sec:,.0f} ops/sec")

def demo_cached_optimization():
    """Demonstrate cached optimization performance."""
    print("\n🚀 Cached Optimization Demo")
    print("=" * 40)
    
    try:
        from project_module.optimizations import cached_vector_embedding_optimizer, clear_all_caches
        
        test_data = generate_test_data(1000, none_percentage=0.25)
        
        # Clear cache to start fresh
        clear_all_caches()
        
        # First call (cache miss)
        print("\n1️⃣ First call (cache miss):")
        start_time = time.perf_counter()
        result1 = cached_vector_embedding_optimizer(test_data, "memory")
        end_time = time.perf_counter()
        duration1 = end_time - start_time
        print(f"   Duration: {duration1*1000:.2f}ms")
        print(f"   Performance: {1/duration1:,.0f} ops/sec")
        
        # Second call (cache hit)
        print("\n2️⃣ Second call (cache hit):")
        start_time = time.perf_counter()
        result2 = cached_vector_embedding_optimizer(test_data, "memory")
        end_time = time.perf_counter()
        duration2 = end_time - start_time
        print(f"   Duration: {duration2*1000:.2f}ms")
        print(f"   Performance: {1/duration2:,.0f} ops/sec")
        
        speedup = duration1 / duration2 if duration2 > 0 else 0
        print(f"\n⚡ Cache speedup: {speedup:.1f}x faster")
        
        # Verify results are identical
        keys1 = set(k for k in result1.keys() if not k.startswith("_"))
        keys2 = set(k for k in result2.keys() if not k.startswith("_"))
        
        if keys1 == keys2:
            print("✅ Results verified identical")
        else:
            print("❌ Results differ!")
            
    except ImportError:
        print("⚠️  Optimization module not available")

def demo_benchmark_comparison():
    """Demonstrate benchmark comparison between methods."""
    print("\n🏁 Benchmark Comparison Demo")
    print("=" * 40)
    
    try:
        from project_module.optimizations import benchmark_optimization_methods
        
        test_data = generate_test_data(1000, none_percentage=0.25)
        
        print(f"\n📊 Benchmarking with {len(test_data)} elements...")
        print("Running 500 iterations per method...")
        
        results = benchmark_optimization_methods(test_data, iterations=500)
        
        print("\n🏆 Performance Results:")
        print("-" * 60)
        print(f"{'Method':<15} {'Ops/Sec':<12} {'Avg Time':<12} {'Relative':<10}")
        print("-" * 60)
        
        # Find fastest method for relative comparison
        fastest_ops = max(r['ops_per_sec'] for r in results.values())
        
        for method_name, metrics in results.items():
            ops_per_sec = metrics['ops_per_sec']
            avg_time_ms = metrics['avg_time'] * 1000
            relative = ops_per_sec / fastest_ops
            
            print(f"{method_name:<15} {ops_per_sec:>8,.0f}    {avg_time_ms:>8.2f}ms    {relative:>6.2f}x")
        
    except ImportError:
        print("⚠️  Optimization module not available")

def demo_telemetry():
    """Demonstrate telemetry and monitoring."""
    print("\n📈 Telemetry & Monitoring Demo")
    print("=" * 40)
    
    try:
        from project_module.optimizations import monitored_memory_optimize, get_cache_stats
        
        test_data = generate_test_data(500, none_percentage=0.4)
        
        print(f"\n🔍 Processing {len(test_data)} elements with telemetry...")
        
        result = monitored_memory_optimize(test_data)
        
        print("\n📊 Telemetry Data:")
        if "_telemetry" in result:
            telemetry = result["_telemetry"]
            print(f"   Duration: {telemetry['duration_ms']:.2f}ms")
            print(f"   Input size: {telemetry['input_size']}")
            print(f"   None removed: {telemetry['none_removed']}")
            print(f"   Timestamp: {time.ctime(telemetry['timestamp'])}")
        
        print("\n🗂️  Cache Statistics:")
        cache_stats = get_cache_stats()
        for cache_name, stats in cache_stats.items():
            print(f"   {cache_name}:")
            print(f"     Size: {stats['size']}/{stats['maxsize']}")
            print(f"     TTL: {stats['ttl']}s")
            
    except ImportError:
        print("⚠️  Optimization module not available")

def demo_property_based_tests():
    """Demonstrate property-based test examples."""
    print("\n🧪 Property-Based Testing Demo")
    print("=" * 40)
    
    from project_module.utils import vector_embedding_optimizer
    import random
    
    print("\n🎲 Running property-based test examples...")
    
    # Generate random test cases
    for i in range(5):
        size = random.randint(10, 100)
        none_ratio = random.uniform(0.1, 0.5)
        
        test_data = generate_test_data(size, none_percentage=none_ratio)
        
        try:
            result = vector_embedding_optimizer(test_data, "memory")
            
            # Verify property: no None values in non-meta fields
            none_fields = [k for k, v in result.items() 
                          if not k.startswith("_") and v is None]
            
            if len(none_fields) == 0:
                status = "✅ PASS"
            else:
                status = f"❌ FAIL ({len(none_fields)} None values)"
            
            print(f"   Test {i+1}: {size} elements, {none_ratio:.1f} None ratio - {status}")
            
        except Exception as e:
            print(f"   Test {i+1}: {size} elements, {none_ratio:.1f} None ratio - ❌ ERROR: {e}")

def main():
    """Run all demonstrations."""
    print("🎯 Performance Optimization Demonstration Suite")
    print("=" * 50)
    print("Showcasing memory optimization techniques and performance improvements")
    
    # Run demonstrations
    demo_basic_optimization()
    demo_cached_optimization()
    demo_benchmark_comparison()
    demo_telemetry()
    demo_property_based_tests()
    
    print("\n🎉 All demonstrations completed!")
    print("\n💡 Next Steps:")
    print("   • Run load tests: python scripts/run_critical_load_test.py")
    print("   • Run property tests: pytest tests/unit/test_utils_property_based.py")
    print("   • Profile with py-spy: py-spy record -o profile.svg -- python scripts/demo_optimizations.py")

if __name__ == "__main__":
    main() 