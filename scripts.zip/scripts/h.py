from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Callable
from sympy import symbols, Function, sin, exp, integrate, diff

# === Symbolic Variables ===
t = symbols('t')
x = symbols('x')

# === Base Component Definitions ===

@dataclass
class OscillatorComponent:
    A: float
    B: float
    phi: float

    def symbolic(self) -> Function:
        """Returns symbolic representation of the oscillator."""
        return self.A * sin(self.B * t + self.phi)


@dataclass
class DecayComponent:
    C: float
    D: float

    def symbolic(self) -> Function:
        """Returns symbolic representation of the decay."""
        return self.C * exp(-self.D * t)


@dataclass
class IntegralComponent:
    lambda_: float
    k: float
    x0: float
    f: Callable[[float], Function]
    g: Callable[[float], Function]

    def symbolic(self) -> Function:
        """Returns symbolic representation of the sigmoid-modulated integral."""
        # Simplified version to avoid complex integration
        # The actual integration would be done numerically in practice
        return self.lambda_ * t  # Placeholder for complex integral


# === Full Wave Definition ===

@dataclass
class HWaveFunction:
    oscillators: List[OscillatorComponent] = field(default_factory=list)
    decays: List[DecayComponent] = field(default_factory=list)
    integral: IntegralComponent | None = None

    def symbolic(self) -> Function:
        """Constructs the full symbolic H(t) wave."""
        osc_sum = sum(osc.symbolic() for osc in self.oscillators)
        decay_sum = sum(dec.symbolic() for dec in self.decays)
        integral_part = self.integral.symbolic() if self.integral else 0
        return osc_sum + decay_sum + integral_part

    def summary(self) -> None:
        """Prints a detailed symbolic structure summary."""
        print("\n=== H(t) Symbolic Structure ===")
        try:
            h_expr = self.symbolic()
            print(str(h_expr))
        except Exception as e:
            print(f"Error generating symbolic expression: {e}")
            # Print components separately
            print("Oscillators:")
            for i, osc in enumerate(self.oscillators):
                print(f"  {i}: {osc.symbolic()}")
            print("Decays:")
            for i, dec in enumerate(self.decays):
                print(f"  {i}: {dec.symbolic()}")
            if self.integral:
                print("Integral: [Complex expression]")
        print("\n===============================")


# === Example Construction ===

def f(x):
    return x**2

def g(x):
    return sin(x)

# Components
osc1 = OscillatorComponent(A=2.0, B=3.0, phi=0.5)
osc2 = OscillatorComponent(A=1.5, B=5.0, phi=1.0)

dec1 = DecayComponent(C=4.0, D=0.8)

integral = IntegralComponent(lambda_=0.5, k=2.0, x0=1.0, f=f, g=g)

# Full H(t)
h_wave = HWaveFunction(
    oscillators=[osc1, osc2],
    decays=[dec1],
    integral=integral
)

# Output symbolic form
if __name__ == "__main__":
    h_wave.summary()
