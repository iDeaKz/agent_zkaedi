from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Dict, List, Callable
import numpy as np
from sympy import lambdify, symbols, sin, exp, integrate, diff

# Define symbolic variables
t = symbols('t')
x = symbols('x')

# Local fallback symbolic_h_function implementation if missing
try:
    from symbolic_h_function import HWaveFunction, h_wave
except ImportError:

    @dataclass
    class OscillatorComponent:
        A: float
        B: float
        phi: float

        def symbolic(self) -> Any:
            return self.A * sin(self.B * t + self.phi)

    @dataclass
    class DecayComponent:
        C: float
        D: float

        def symbolic(self) -> Any:
            return self.C * exp(-self.D * t)

    @dataclass
    class IntegralComponent:
        lambda_: float
        k: float
        x0: float
        f: Callable[[Any], Any]
        g: Callable[[Any], Any]

        def numerical(self, t_val: float) -> float:
            """Numerically evaluate the integral at a specific time t."""
            from scipy.integrate import quad
            import math

            def integrand(x_val: float) -> float:
                return (self.f(x_val) * (math.cos(x_val))) / (1 + math.exp(-self.k * (x_val - self.x0)))

            result, _ = quad(integrand, 0, t_val)
            return self.lambda_ * result

    @dataclass
    class HWaveFunction:
        oscillators: List[OscillatorComponent] = field(default_factory=list)
        decays: List[DecayComponent] = field(default_factory=list)
        integral: IntegralComponent | None = None

        def symbolic(self) -> Any:
            osc_sum = sum(osc.symbolic() for osc in self.oscillators)
            decay_sum = sum(dec.symbolic() for dec in self.decays)
            return osc_sum + decay_sum

    def f(x): return x**2
    def g(x): return sin(x)

    h_wave = HWaveFunction(
        oscillators=[OscillatorComponent(A=2.0, B=3.0, phi=0.5), OscillatorComponent(A=1.5, B=5.0, phi=1.0)],
        decays=[DecayComponent(C=4.0, D=0.8)],
        integral=IntegralComponent(lambda_=0.5, k=2.0, x0=1.0, f=f, g=g)
    )


@dataclass
class HMemory:
    """Caches evaluations of H(t) over time."""
    history: Dict[float, float] = field(default_factory=dict)

    def record(self, time: float, value: float) -> None:
        self.history[time] = value

    def get(self, time: float) -> float | None:
        return self.history.get(time)


@dataclass
class HPlanner:
    """Plans evaluation schedule for H(t)."""
    start: float
    end: float
    steps: int

    def generate_timesteps(self) -> List[float]:
        return np.linspace(self.start, self.end, self.steps).tolist()


@dataclass
class HExecutor:
    """Executes symbolic H(t) into numerical evaluation."""
    h_wave: HWaveFunction

    def prepare_function(self) -> Any:
        symbolic_expr = self.h_wave.symbolic()
        return lambdify('t', symbolic_expr, modules=["numpy"])


@dataclass
class HAgent:
    """Symbolic H(t) Master Agent."""
    h_wave: HWaveFunction
    planner: HPlanner
    memory: HMemory = field(default_factory=HMemory)

    def run_simulation(self) -> None:
        executor = HExecutor(self.h_wave)
        h_func = executor.prepare_function()
        timesteps = self.planner.generate_timesteps()

        for t_val in timesteps:
            base_value = h_func(t_val)
            integral_value = self.h_wave.integral.numerical(t_val) if self.h_wave.integral else 0.0
            result = base_value + integral_value
            self.memory.record(t_val, result)

    def display_memory(self) -> None:
        print("\n=== H(t) Evaluation Memory ===")
        for time, value in sorted(self.memory.history.items()):
            print(f"t={time:.4f} -> H(t)={value:.6f}")
        print("\n==============================")


# === Example Runner ===

if __name__ == "__main__":
    agent = HAgent(
        h_wave=h_wave,
        planner=HPlanner(start=0.0, end=10.0, steps=50)
    )

    agent.run_simulation()
    agent.display_memory()
