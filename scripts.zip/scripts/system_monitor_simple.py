#!/usr/bin/env python3
"""Simple System Monitor for Full-Scale Test"""

import json
import time
from pathlib import Path

def monitor_test():
    results_file = Path('full_system_test_results.json')
    checkpoint_dir = Path('checkpoints')
    
    print("🚀 Elite AI System Test Monitor")
    print("=" * 50)
    
    start_time = time.time()
    
    while True:
        runtime = time.time() - start_time
        
        # Check test results
        if results_file.exists():
            try:
                with open(results_file, 'r') as f:
                    results = json.load(f)
                
                if 'test_summary' in results:
                    summary = results['test_summary']
                    print(f"\n✅ TEST COMPLETED!")
                    print(f"   Health Score: {summary['system_health_score']:.1%}")
                    print(f"   Tests: {summary['successful_tests']}/{summary['total_tests']}")
                    print(f"   Runtime: {summary['total_runtime']:.2f}s")
                    print(f"   Errors: {results['error_summary']['total_errors']}")
                    print(f"   Recoveries: {results['error_summary']['successful_recoveries']}")
                    break
            except:
                pass
        
        # Check checkpoints
        checkpoints = len(list(checkpoint_dir.glob('*.pkl'))) if checkpoint_dir.exists() else 0
        
        print(f"\r🔄 Running... {runtime:.0f}s | Checkpoints: {checkpoints}", end="", flush=True)
        time.sleep(2)

if __name__ == "__main__":
    monitor_test() 