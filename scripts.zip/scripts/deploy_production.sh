#!/bin/bash
# deploy_production.sh - Production deployment script
# Implements the battle-tested 8-step playbook

set -euo pipefail

# Colors
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

echo "🚀 ScriptSynthCore Production Deployment"
echo "========================================"

# Step 1: Environment Setup
echo -e "${YELLOW}Step 1: Environment Setup${NC}"
cd "$(dirname "$0")/.."

if [ ! -f "docker/.env" ]; then
    echo "❌ Missing docker/.env file"
    echo "Please create docker/.env with your production secrets"
    exit 1
fi

# Step 2: Pull latest images
echo -e "${YELLOW}Step 2: Pulling latest images${NC}"
docker-compose -f docker/docker-compose.prod.yml pull --ignore-pull-failures

# Step 3: Build and start services
echo -e "${YELLOW}Step 3: Building and starting services${NC}"
docker-compose -f docker/docker-compose.prod.yml up -d --build

# Step 4: Wait for services to be ready
echo -e "${YELLOW}Step 4: Waiting for services to be ready${NC}"
sleep 30

# Step 5: Run ready check
echo -e "${YELLOW}Step 5: Running system health check${NC}"
if ! ./scripts/ready_check.sh; then
    echo -e "${RED}❌ Health check failed! Check logs and try again${NC}"
    docker-compose -f docker/docker-compose.prod.yml logs --tail=50
    exit 1
fi

# Step 6: Run integration tests
echo -e "${YELLOW}Step 6: Running integration tests${NC}"
if command -v python &> /dev/null; then
    python -m pytest tests/integration_advanced/ -q || echo "⚠️  Integration tests failed (continuing)"
fi

# Step 7: Load testing (optional)
echo -e "${YELLOW}Step 7: Load testing (optional)${NC}"
if command -v locust &> /dev/null; then
    echo "Running quick load test..."
    locust -f dashboard/load_tests/locustfile.py \
           --headless -u 50 -r 10 -t 30s \
           --host http://localhost:8000 || echo "⚠️  Load test failed (continuing)"
fi

# Step 8: Final validation
echo -e "${YELLOW}Step 8: Final validation${NC}"
echo ""
echo "🎯 Service endpoints:"
echo "  • API Health:    http://localhost:8000/health"
echo "  • Dashboard:     http://localhost:3000"
echo "  • Grafana:       http://localhost:3001"
echo "  • Prometheus:    http://localhost:9090"
echo ""

echo -e "${GREEN}🚀 DEPLOYMENT COMPLETE!${NC}"
echo -e "${GREEN}✅ ScriptSynthCore v0.9.0 is now running in production mode${NC}"
echo ""
echo "📊 To monitor the system:"
echo "  docker-compose -f docker/docker-compose.prod.yml ps"
echo "  docker-compose -f docker/docker-compose.prod.yml logs -f"
echo ""
echo "🛠️  To stop the system:"
echo "  docker-compose -f docker/docker-compose.prod.yml down" 