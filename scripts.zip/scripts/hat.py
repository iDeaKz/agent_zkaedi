from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Dict, List, Callable
import numpy as np
from sympy import lambdify, symbols, sin, exp, integrate, diff
import matplotlib.pyplot as plt
import json

# Define symbolic variables
t = symbols('t')
x = symbols('x')

# Local fallback symbolic_h_function implementation if missing
try:
    from symbolic_h_function import HWaveFunction, h_wave
except ImportError:

    @dataclass
    class OscillatorComponent:
        A: float
        B: float
        phi: float

        def symbolic(self) -> Any:
            return self.A * sin(self.B * t + self.phi)

    @dataclass
    class DecayComponent:
        C: float
        D: float

        def symbolic(self) -> Any:
            return self.C * exp(-self.D * t)

    @dataclass
    class IntegralComponent:
        lambda_: float
        k: float
        x0: float
        f: Callable[[Any], Any]
        g: Callable[[Any], Any]

        def numerical(self, t_val: float) -> float:
            from scipy.integrate import quad
            import math

            def integrand(x_val: float) -> float:
                return (self.f(x_val) * (math.cos(x_val))) / (1 + math.exp(-self.k * (x_val - self.x0)))

            result, _ = quad(integrand, 0, t_val)
            return self.lambda_ * result

    @dataclass
    class HWaveFunction:
        oscillators: List[OscillatorComponent] = field(default_factory=list)
        decays: List[DecayComponent] = field(default_factory=list)
        integral: IntegralComponent | None = None

        def symbolic(self) -> Any:
            osc_sum = sum(osc.symbolic() for osc in self.oscillators)
            decay_sum = sum(dec.symbolic() for dec in self.decays)
            return osc_sum + decay_sum

    def f(x): return x**2
    def g(x): return sin(x)

    h_wave = HWaveFunction(
        oscillators=[OscillatorComponent(A=2.0, B=3.0, phi=0.5), OscillatorComponent(A=1.5, B=5.0, phi=1.0)],
        decays=[DecayComponent(C=4.0, D=0.8)],
        integral=IntegralComponent(lambda_=0.5, k=2.0, x0=1.0, f=f, g=g)
    )


@dataclass
class HMemory:
    history: Dict[float, float] = field(default_factory=dict)

    def record(self, time: float, value: float) -> None:
        self.history[time] = value

    def get(self, time: float) -> float | None:
        return self.history.get(time)


@dataclass
class HPlanner:
    start: float
    end: float
    steps: int

    def generate_timesteps(self) -> List[float]:
        return np.linspace(self.start, self.end, self.steps).tolist()


@dataclass
class HExecutor:
    h_wave: HWaveFunction

    def prepare_function(self) -> Any:
        symbolic_expr = self.h_wave.symbolic()
        return lambdify('t', symbolic_expr, modules=["numpy"])


@dataclass
class VaultRule:
    target: str
    operation: str
    value: float
    activation_time: float = 0.0


@dataclass
class VaultRuleParser:
    rules: List[VaultRule] = field(default_factory=list)

    @staticmethod
    def from_dict(data: List[Dict[str, Any]]) -> VaultRuleParser:
        return VaultRuleParser(rules=[VaultRule(**item) for item in data])

    @staticmethod
    def from_json_file(filepath: str) -> VaultRuleParser:
        with open(filepath, 'r') as f:
            data = json.load(f)
        return VaultRuleParser.from_dict(data)


@dataclass
class HAgent:
    h_wave: HWaveFunction
    planner: HPlanner
    memory: HMemory = field(default_factory=HMemory)
    mutation_log: List[str] = field(default_factory=list)

    def apply_vault_rule(self, rule: VaultRule) -> None:
        if rule.target.startswith("oscillator["):
            idx = int(rule.target.split("[")[1].split("]")[0])
            attr = rule.target.split(".")[1]
            setattr(self.h_wave.oscillators[idx], attr, getattr(self.h_wave.oscillators[idx], attr) + rule.value if rule.operation == "add" else rule.value)
        elif rule.target.startswith("decay["):
            idx = int(rule.target.split("[")[1].split("]")[0])
            attr = rule.target.split(".")[1]
            setattr(self.h_wave.decays[idx], attr, getattr(self.h_wave.decays[idx], attr) + rule.value if rule.operation == "add" else rule.value)
        elif rule.target == "integral.lambda_" and self.h_wave.integral:
            self.h_wave.integral.lambda_ += rule.value if rule.operation == "add" else rule.value

    def apply_active_rules(self, t_val: float, vault_parser: VaultRuleParser) -> None:
        step_duration = (self.planner.end - self.planner.start) / self.planner.steps
        pending_rules = [r for r in vault_parser.rules if abs(r.activation_time - t_val) < step_duration / 2]
        for rule in pending_rules:
            self.apply_vault_rule(rule)
            self.mutation_log.append(f"Applied {rule.target} {rule.operation} {rule.value} at t={t_val:.4f}")
            vault_parser.rules.remove(rule)

    def run_simulation(self, vault_parser: VaultRuleParser = None) -> None:
        executor = HExecutor(self.h_wave)
        h_func = executor.prepare_function()
        timesteps = self.planner.generate_timesteps()

        for t_val in timesteps:
            if vault_parser:
                self.apply_active_rules(t_val, vault_parser)

            base_value = h_func(t_val)
            integral_value = self.h_wave.integral.numerical(t_val) if self.h_wave.integral else 0.0
            result = base_value + integral_value
            self.memory.record(t_val, result)

    def display_memory(self) -> None:
        print("\n=== H(t) Evaluation Memory ===")
        for time, value in sorted(self.memory.history.items()):
            print(f"t={time:.4f} -> H(t)={value:.6f}")
        print("\n==============================")

    def display_mutation_history(self) -> None:
        print("\n=== Mutation History ===")
        for entry in self.mutation_log:
            print(entry)
        print("\n========================")

    def plot_memory(self) -> None:
        times = sorted(self.memory.history.keys())
        values = [self.memory.history[t] for t in times]
        plt.plot(times, values, marker='o', label='H(t)')
        for entry in self.mutation_log:
            if 'at t=' in entry:
                time_str = entry.split('at t=')[1]
                try:
                    time_val = float(time_str)
                    plt.axvline(x=time_val, color='red', linestyle='--', alpha=0.5)
                    plt.text(time_val, max(values), '✴', color='red', ha='center', va='bottom', fontsize=10)
                except ValueError:
                    continue
        plt.title("Evolution of H(t) with Sigil Activations")
        plt.xlabel("Time (t)")
        plt.ylabel("H(t)")
        plt.grid(True)
        plt.legend()
        plt.savefig("h_evolution_with_sigils.png")
        plt.close()


# === Example Runner ===

if __name__ == "__main__":
    agent = HAgent(
        h_wave=h_wave,
        planner=HPlanner(start=0.0, end=10.0, steps=50)
    )

    # Load from external vault file or define inline
    try:
        parser = VaultRuleParser.from_json_file("vault_rules.json")
    except Exception:
        vault_data = [
            {"target": "oscillator[0].A", "operation": "add", "value": 1.0, "activation_time": 2.0},
            {"target": "decay[0].C", "operation": "add", "value": -0.5, "activation_time": 5.0},
            {"target": "integral.lambda_", "operation": "add", "value": 0.2, "activation_time": 7.5}
        ]
        parser = VaultRuleParser.from_dict(vault_data)

    agent.run_simulation(parser)
    agent.display_memory()
    agent.display_mutation_history()
    # agent.plot_memory()  # Commented out to avoid blocking
