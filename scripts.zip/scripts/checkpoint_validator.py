#!/usr/bin/env python3
"""
Advanced Checkpoint Validation System
Validates checkpoints, handles corruption, and ensures system integrity.
"""

import hashlib
import json
import logging
import os
import pickle
import shutil
import time
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Dict, List, Optional, Any, Tuple
import numpy as np

logging.basicConfig(level=logging.INFO)
LOGGER = logging.getLogger(__name__)

@dataclass
class CheckpointHealth:
    """Checkpoint health status."""
    checkpoint_id: str
    is_valid: bool
    corruption_detected: bool
    size_mismatch: bool
    checksum_valid: bool
    metadata_valid: bool
    recovery_possible: bool
    age_hours: float
    
@dataclass
class ValidationReport:
    """Comprehensive validation report."""
    total_checkpoints: int
    valid_checkpoints: int
    corrupted_checkpoints: int
    recovered_checkpoints: int
    orphaned_files: int
    total_size_mb: float
    validation_time: float
    recommendations: List[str]

class CheckpointValidator:
    """Advanced checkpoint validation and recovery system."""
    
    def __init__(self, checkpoint_dir: str = "checkpoints"):
        self.checkpoint_dir = Path(checkpoint_dir)
        self.backup_dir = self.checkpoint_dir / "backups"
        self.quarantine_dir = self.checkpoint_dir / "quarantine"
        
        # Create directories
        self.checkpoint_dir.mkdir(exist_ok=True)
        self.backup_dir.mkdir(exist_ok=True)
        self.quarantine_dir.mkdir(exist_ok=True)
        
        self.validation_cache = {}
        self.recovery_stats = {}
        
    def validate_checkpoint_integrity(self, checkpoint_id: str) -> CheckpointHealth:
        """Comprehensive checkpoint validation."""
        LOGGER.info(f"🔍 Validating checkpoint: {checkpoint_id}")
        
        checkpoint_path = self.checkpoint_dir / f"{checkpoint_id}.pkl"
        metadata_path = self.checkpoint_dir / f"{checkpoint_id}_metadata.json"
        
        health = CheckpointHealth(
            checkpoint_id=checkpoint_id,
            is_valid=False,
            corruption_detected=False,
            size_mismatch=False,
            checksum_valid=False,
            metadata_valid=False,
            recovery_possible=False,
            age_hours=0.0
        )
        
        try:
            # Check file existence
            if not checkpoint_path.exists():
                LOGGER.error(f"❌ Checkpoint file missing: {checkpoint_id}")
                return health
            
            if not metadata_path.exists():
                LOGGER.warning(f"⚠️ Metadata file missing: {checkpoint_id}")
                health.metadata_valid = False
            else:
                health.metadata_valid = True
            
            # Calculate age
            checkpoint_time = checkpoint_path.stat().st_mtime
            health.age_hours = (time.time() - checkpoint_time) / 3600
            
            # Load and validate metadata
            metadata = None
            if health.metadata_valid:
                try:
                    with open(metadata_path, 'r') as f:
                        metadata = json.load(f)
                except Exception as e:
                    LOGGER.error(f"❌ Metadata corruption: {checkpoint_id} - {e}")
                    health.metadata_valid = False
            
            # Validate file size
            actual_size = checkpoint_path.stat().st_size
            if metadata and 'data_size' in metadata:
                expected_size = metadata['data_size']
                if actual_size != expected_size:
                    LOGGER.warning(f"⚠️ Size mismatch: {checkpoint_id} - {actual_size} vs {expected_size}")
                    health.size_mismatch = True
            
            # Validate checksum
            with open(checkpoint_path, 'rb') as f:
                data = f.read()
            
            current_checksum = hashlib.sha256(data).hexdigest()
            
            if metadata and 'checksum' in metadata:
                expected_checksum = metadata['checksum']
                if current_checksum == expected_checksum:
                    health.checksum_valid = True
                    LOGGER.info(f"✅ Checksum valid: {checkpoint_id}")
                else:
                    LOGGER.error(f"❌ Checksum mismatch: {checkpoint_id}")
                    health.corruption_detected = True
            else:
                # No metadata checksum, assume current is correct
                health.checksum_valid = True
            
            # Try to load the data
            try:
                with open(checkpoint_path, 'rb') as f:
                    loaded_data = pickle.load(f)
                LOGGER.info(f"✅ Data loadable: {checkpoint_id}")
                health.recovery_possible = True
            except Exception as e:
                LOGGER.error(f"❌ Data corruption: {checkpoint_id} - {e}")
                health.corruption_detected = True
                health.recovery_possible = False
            
            # Overall validation
            health.is_valid = (
                health.checksum_valid and 
                not health.corruption_detected and
                health.recovery_possible
            )
            
            if health.is_valid:
                LOGGER.info(f"✅ Checkpoint healthy: {checkpoint_id}")
            else:
                LOGGER.warning(f"⚠️ Checkpoint issues detected: {checkpoint_id}")
            
        except Exception as e:
            LOGGER.error(f"❌ Validation failed: {checkpoint_id} - {e}")
            health.corruption_detected = True
        
        return health
    
    def create_backup(self, checkpoint_id: str) -> bool:
        """Create backup of checkpoint before recovery attempts."""
        try:
            checkpoint_path = self.checkpoint_dir / f"{checkpoint_id}.pkl"
            metadata_path = self.checkpoint_dir / f"{checkpoint_id}_metadata.json"
            
            backup_checkpoint = self.backup_dir / f"{checkpoint_id}_backup.pkl"
            backup_metadata = self.backup_dir / f"{checkpoint_id}_metadata_backup.json"
            
            if checkpoint_path.exists():
                shutil.copy2(checkpoint_path, backup_checkpoint)
            
            if metadata_path.exists():
                shutil.copy2(metadata_path, backup_metadata)
            
            LOGGER.info(f"💾 Backup created: {checkpoint_id}")
            return True
            
        except Exception as e:
            LOGGER.error(f"❌ Backup failed: {checkpoint_id} - {e}")
            return False
    
    def attempt_recovery(self, checkpoint_id: str, health: CheckpointHealth) -> bool:
        """Attempt to recover corrupted checkpoint."""
        LOGGER.info(f"🔧 Attempting recovery: {checkpoint_id}")
        
        if not health.recovery_possible:
            LOGGER.error(f"❌ Recovery not possible: {checkpoint_id}")
            return False
        
        # Create backup first
        if not self.create_backup(checkpoint_id):
            LOGGER.error(f"❌ Cannot proceed without backup: {checkpoint_id}")
            return False
        
        recovery_attempts = 0
        max_attempts = 3
        
        while recovery_attempts < max_attempts:
            recovery_attempts += 1
            LOGGER.info(f"🔧 Recovery attempt {recovery_attempts}/{max_attempts}: {checkpoint_id}")
            
            try:
                checkpoint_path = self.checkpoint_dir / f"{checkpoint_id}.pkl"
                
                # Strategy 1: Reload and re-save
                if recovery_attempts == 1:
                    with open(checkpoint_path, 'rb') as f:
                        data = pickle.load(f)
                    
                    # Re-serialize with different protocol
                    with open(checkpoint_path, 'wb') as f:
                        pickle.dump(data, f, protocol=pickle.HIGHEST_PROTOCOL)
                    
                    LOGGER.info(f"🔧 Re-serialization attempted: {checkpoint_id}")
                
                # Strategy 2: Recreate metadata
                elif recovery_attempts == 2:
                    with open(checkpoint_path, 'rb') as f:
                        data = f.read()
                    
                    # Recreate metadata
                    new_checksum = hashlib.sha256(data).hexdigest()
                    new_metadata = {
                        'checkpoint_id': checkpoint_id,
                        'timestamp': time.time(),
                        'checksum': new_checksum,
                        'data_size': len(data),
                        'recovery_attempt': recovery_attempts,
                        'original_corruption': True
                    }
                    
                    metadata_path = self.checkpoint_dir / f"{checkpoint_id}_metadata.json"
                    with open(metadata_path, 'w') as f:
                        json.dump(new_metadata, f, indent=2)
                    
                    LOGGER.info(f"🔧 Metadata recreation attempted: {checkpoint_id}")
                
                # Strategy 3: Partial recovery
                elif recovery_attempts == 3:
                    # Move to quarantine and create recovery note
                    quarantine_path = self.quarantine_dir / f"{checkpoint_id}_corrupted.pkl"
                    checkpoint_path = self.checkpoint_dir / f"{checkpoint_id}.pkl"
                    
                    shutil.move(checkpoint_path, quarantine_path)
                    
                    recovery_note = {
                        'original_checkpoint': checkpoint_id,
                        'quarantine_reason': 'corruption_detected',
                        'quarantine_time': time.time(),
                        'recovery_attempts': recovery_attempts,
                        'backup_available': True
                    }
                    
                    note_path = self.quarantine_dir / f"{checkpoint_id}_recovery_note.json"
                    with open(note_path, 'w') as f:
                        json.dump(recovery_note, f, indent=2)
                    
                    LOGGER.warning(f"⚠️ Moved to quarantine: {checkpoint_id}")
                    return False
                
                # Validate recovery
                new_health = self.validate_checkpoint_integrity(checkpoint_id)
                if new_health.is_valid:
                    LOGGER.info(f"✅ Recovery successful: {checkpoint_id}")
                    self.recovery_stats[checkpoint_id] = {
                        'attempts': recovery_attempts,
                        'strategy': f"strategy_{recovery_attempts}",
                        'success': True
                    }
                    return True
                
            except Exception as e:
                LOGGER.error(f"❌ Recovery attempt {recovery_attempts} failed: {checkpoint_id} - {e}")
        
        LOGGER.error(f"❌ All recovery attempts failed: {checkpoint_id}")
        self.recovery_stats[checkpoint_id] = {
            'attempts': recovery_attempts,
            'success': False
        }
        return False
    
    def cleanup_orphaned_files(self) -> int:
        """Clean up orphaned checkpoint files."""
        LOGGER.info("🧹 Cleaning up orphaned files")
        
        orphaned_count = 0
        
        # Find all .pkl files
        pkl_files = set(f.stem for f in self.checkpoint_dir.glob("*.pkl"))
        metadata_files = set(f.stem.replace("_metadata", "") for f in self.checkpoint_dir.glob("*_metadata.json"))
        
        # Find orphaned pickle files (no metadata)
        orphaned_pkl = pkl_files - metadata_files
        for orphan in orphaned_pkl:
            pkl_path = self.checkpoint_dir / f"{orphan}.pkl"
            quarantine_path = self.quarantine_dir / f"{orphan}_orphaned.pkl"
            
            shutil.move(pkl_path, quarantine_path)
            orphaned_count += 1
            LOGGER.info(f"🗑️ Orphaned pickle moved: {orphan}")
        
        # Find orphaned metadata files (no pickle)
        orphaned_metadata = metadata_files - pkl_files
        for orphan in orphaned_metadata:
            metadata_path = self.checkpoint_dir / f"{orphan}_metadata.json"
            quarantine_path = self.quarantine_dir / f"{orphan}_metadata_orphaned.json"
            
            shutil.move(metadata_path, quarantine_path)
            orphaned_count += 1
            LOGGER.info(f"🗑️ Orphaned metadata moved: {orphan}")
        
        LOGGER.info(f"🧹 Cleanup complete: {orphaned_count} orphaned files moved")
        return orphaned_count
    
    def validate_all_checkpoints(self) -> ValidationReport:
        """Validate all checkpoints and generate comprehensive report."""
        LOGGER.info("🔍 Starting comprehensive checkpoint validation")
        start_time = time.perf_counter()
        
        # Find all checkpoints
        checkpoint_files = list(self.checkpoint_dir.glob("*.pkl"))
        checkpoint_ids = [f.stem for f in checkpoint_files]
        
        LOGGER.info(f"📊 Found {len(checkpoint_ids)} checkpoints to validate")
        
        health_reports = []
        valid_count = 0
        corrupted_count = 0
        recovered_count = 0
        total_size = 0
        
        for checkpoint_id in checkpoint_ids:
            health = self.validate_checkpoint_integrity(checkpoint_id)
            health_reports.append(health)
            
            # Calculate size
            checkpoint_path = self.checkpoint_dir / f"{checkpoint_id}.pkl"
            if checkpoint_path.exists():
                total_size += checkpoint_path.stat().st_size
            
            if health.is_valid:
                valid_count += 1
            else:
                corrupted_count += 1
                
                # Attempt recovery for corrupted checkpoints
                if health.recovery_possible:
                    if self.attempt_recovery(checkpoint_id, health):
                        recovered_count += 1
                        # Re-validate after recovery
                        health = self.validate_checkpoint_integrity(checkpoint_id)
                        if health.is_valid:
                            valid_count += 1
                            corrupted_count -= 1
        
        # Clean up orphaned files
        orphaned_count = self.cleanup_orphaned_files()
        
        # Generate recommendations
        recommendations = self._generate_recommendations(health_reports)
        
        validation_time = time.perf_counter() - start_time
        
        report = ValidationReport(
            total_checkpoints=len(checkpoint_ids),
            valid_checkpoints=valid_count,
            corrupted_checkpoints=corrupted_count,
            recovered_checkpoints=recovered_count,
            orphaned_files=orphaned_count,
            total_size_mb=total_size / (1024 * 1024),
            validation_time=validation_time,
            recommendations=recommendations
        )
        
        # Save report
        report_path = self.checkpoint_dir / "validation_report.json"
        with open(report_path, 'w') as f:
            json.dump(asdict(report), f, indent=2, default=str)
        
        LOGGER.info("=" * 60)
        LOGGER.info("📊 CHECKPOINT VALIDATION REPORT")
        LOGGER.info("=" * 60)
        LOGGER.info(f"📁 Total Checkpoints: {report.total_checkpoints}")
        LOGGER.info(f"✅ Valid: {report.valid_checkpoints}")
        LOGGER.info(f"❌ Corrupted: {report.corrupted_checkpoints}")
        LOGGER.info(f"🔧 Recovered: {report.recovered_checkpoints}")
        LOGGER.info(f"🗑️ Orphaned: {report.orphaned_files}")
        LOGGER.info(f"💾 Total Size: {report.total_size_mb:.2f} MB")
        LOGGER.info(f"⏱️ Validation Time: {report.validation_time:.2f}s")
        LOGGER.info("=" * 60)
        
        if recommendations:
            LOGGER.info("🎯 RECOMMENDATIONS:")
            for rec in recommendations:
                LOGGER.info(f"   {rec}")
        
        return report
    
    def _generate_recommendations(self, health_reports: List[CheckpointHealth]) -> List[str]:
        """Generate recommendations based on validation results."""
        recommendations = []
        
        # Check for old checkpoints
        old_checkpoints = [h for h in health_reports if h.age_hours > 168]  # 1 week
        if old_checkpoints:
            recommendations.append(f"🗑️ Consider archiving {len(old_checkpoints)} checkpoints older than 1 week")
        
        # Check corruption rate
        corrupted = [h for h in health_reports if h.corruption_detected]
        if corrupted:
            corruption_rate = len(corrupted) / len(health_reports)
            if corruption_rate > 0.1:  # 10%
                recommendations.append(f"⚠️ High corruption rate ({corruption_rate:.1%}) - investigate storage issues")
        
        # Check size issues
        size_issues = [h for h in health_reports if h.size_mismatch]
        if size_issues:
            recommendations.append(f"📏 {len(size_issues)} checkpoints have size mismatches - verify metadata")
        
        # Check recovery success
        if self.recovery_stats:
            successful_recoveries = sum(1 for stats in self.recovery_stats.values() if stats['success'])
            total_attempts = len(self.recovery_stats)
            recovery_rate = successful_recoveries / total_attempts
            
            if recovery_rate < 0.8:
                recommendations.append(f"🔧 Low recovery success rate ({recovery_rate:.1%}) - improve backup strategy")
        
        # Storage recommendations
        total_size_gb = sum(h.age_hours * 0.001 for h in health_reports)  # Rough estimate
        if total_size_gb > 10:
            recommendations.append("💾 Consider implementing checkpoint compression or archival")
        
        if not recommendations:
            recommendations.append("🏆 All checkpoints healthy - no actions needed")
        
        return recommendations

def main():
    """Run checkpoint validation."""
    print("🔍 Elite AI Checkpoint Validation System")
    print("=" * 50)
    
    validator = CheckpointValidator()
    report = validator.validate_all_checkpoints()
    
    # Display summary
    health_score = report.valid_checkpoints / report.total_checkpoints if report.total_checkpoints > 0 else 0
    
    print(f"\n📊 VALIDATION SUMMARY:")
    print(f"   Health Score: {health_score:.1%}")
    print(f"   Valid Checkpoints: {report.valid_checkpoints}/{report.total_checkpoints}")
    print(f"   Recoveries: {report.recovered_checkpoints}")
    print(f"   Total Size: {report.total_size_mb:.2f} MB")
    
    if health_score >= 0.95:
        print("🏆 EXCELLENT checkpoint health!")
    elif health_score >= 0.8:
        print("✅ GOOD checkpoint health")
    elif health_score >= 0.6:
        print("⚠️ FAIR checkpoint health - some issues detected")
    else:
        print("❌ POOR checkpoint health - immediate attention needed")
    
    return report

if __name__ == "__main__":
    main() 