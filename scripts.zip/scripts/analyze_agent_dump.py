#!/usr/bin/env python3
"""
analyze_agent_dump.py: Legendary Edition
A modular, interactive, colorful CLI for agent data analysis in Legendary Mode.
"""

import argparse
import sys
import os
from pathlib import Path
from typing import Any, Dict, List
from concurrent.futures import ProcessPoolExecutor, as_completed

import numpy as np
import pandas as pd
import scipy.stats as stats
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans
import matplotlib.pyplot as plt
import seaborn as sns
from tqdm import tqdm
from colorama import init as colorama_init, Fore, Style

# Set UTF-8 encoding for Windows
if sys.platform == 'win32':
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8')

# Initialize colorama
colorama_init(autoreset=True)

ASCII_BANNER = r"""
██████╗ ███████╗███╗   ██╗ █████╗ ██╗   ██╗███████╗██████╗ ███████╗
██╔══██╗██╔════╝████╗  ██║██╔══██╗██║   ██║██╔════╝██╔══██╗██╔════╝
██║  ██║█████╗  ██╔██╗ ██║███████║██║   ██║█████╗  ██████╔╝███████╗
██║  ██║██╔══╝  ██║╚██╗██║██╔══██║██║   ██║██╔══╝  ██╔══██╗╚════██║
██████╔╝███████╗██║ ╚████║██║  ██║╚██████╔╝███████╗██║  ██║███████║
╚═════╝ ╚══════╝╚═╝  ╚═══╝╚═╝  ╚═╝ ╚═════╝ ╚══════╝╚═╝  ╚═╝╚══════╝
         ANALYZER V2: LEGENDARY MODE
"""

def parse_args() -> argparse.Namespace:
    """Parse CLI flags."""
    parser = argparse.ArgumentParser(
        description="Legendary Agent Data Analyzer (Legendary Mode Edition)"
    )
    # Define modular flags
    parser.add_argument("--dist", action="store_true", help="Distribution analysis (histogram and boxplot)")
    parser.add_argument("--trend", action="store_true", help="Trend analysis")
    parser.add_argument("--cluster", action="store_true", help="Clustering analysis")
    parser.add_argument("--entropy", action="store_true", help="Entropy/KL divergence")
    parser.add_argument("--multi", action="store_true", help="Multi-agent comparison")
    parser.add_argument("--compare-all", action="store_true", help="Compare distributions of all agents in subdirectories")
    parser.add_argument("--temporal", action="store_true", help="Plot temporal trend of 'Value' for an agent")
    parser.add_argument("--zero-analysis", action="store_true", help="Analyze zero-value episodes")
    parser.add_argument("--high-value-analysis", action="store_true", help="Analyze high-value episodes ( > 0.9)")
    parser.add_argument("--consistency", action="store_true", help="Comprehensive consistency and strategy analysis across all agents")
    parser.add_argument("--summary", action="store_true", help="Generate summary JSON/MD")
    parser.add_argument("--xlsx", action="store_true", help="Embed charts into XLSX")
    parser.add_argument("--outliers", type=int, default=10, help="Top N outliers")
    parser.add_argument("--dir", type=str, default=".", help="Directory of agent dumps")
    args = parser.parse_args()
    return args

def interactive_prompt(flags: List[str]) -> Dict[str, bool]:
    """
    Prompt user interactively for each analysis flag if none were provided.
    Uses colorful emojis and text.
    """
    responses = {}
    for flag in flags:
        emoji = {
            "trend": "🔵",
            "cluster": "🟣",
            "entropy": "🟠",
            "multi": "🟢",
            "summary": "🔷",
            "xlsx": "📘",
            "dist": "📊",
            "compare-all": "🤝",
            "temporal": "📈",
            "zero-analysis": "🅾️",
            "high-value-analysis": "🏆",
            "consistency": "🌟"
        }.get(flag, "")
        prompt_text = f"{emoji} Enable {flag.capitalize().replace('_', ' ')} Analysis? [y/N]: "
        resp = input(Fore.CYAN + prompt_text + Style.RESET_ALL).strip().lower()
        responses[flag] = (resp == "y")
    return responses

def read_agent_data(directory: str) -> pd.DataFrame:
    """
    Load and concatenate JSON dumps from agents in the directory.
    """
    all_files = list(Path(directory).glob("*_full_dump.json"))
    if not all_files:
        # If no json files, try to find any CSV files
        all_files = list(Path(directory).glob("*.csv"))
    if not all_files:
        # Create dummy data for testing
        print(Fore.YELLOW + f"No JSON or CSV files found in {directory}, creating dummy data for testing" + Style.RESET_ALL)
        # Create a simple DataFrame with random data
        np.random.seed(42)
        df = pd.DataFrame({
            'Value': np.random.randn(1000),  # Changed to 'Value'
            'timestamp': pd.date_range('2024-01-01', periods=1000, freq='h'),
            'category': np.random.choice(['A', 'B', 'C'], 1000),
            'metric1': np.random.exponential(2, 1000),
            'metric2': np.random.gamma(2, 2, 1000)
        })
        return df
    
    # Assuming JSON files are the primary source of raw data
    if any(f.suffix == '.json' for f in all_files):
        all_files = [f for f in all_files if f.suffix == '.json']
        df_list = []
        for f in all_files:
            try:
                # read_json can be memory intensive. For very large files, consider chunking.
                df = pd.read_json(f)
                df_list.append(df)
            except ValueError as e:
                print(Fore.RED + f"Error reading {f}: {e}. It might not be a valid JSON array of records." + Style.RESET_ALL)
        if not df_list:
            raise ValueError("No valid JSON data could be loaded.")
        return pd.concat(df_list, ignore_index=True)
    else: # Fallback to CSV
        df_list = [pd.read_csv(f) for f in all_files]
        return pd.concat(df_list, ignore_index=True)

def analyze_distribution(df: pd.DataFrame, column: Any = 'Value') -> None:
    """
    Generates a histogram and boxplot for a specific column to analyze its distribution.
    """
    if column not in df.columns:
        # The user used 'Value', but dummy data has 'value'. Let's be flexible.
        if column.lower() in df.columns:
            column = column.lower()
        else:
            print(Fore.RED + f"Column '{column}' not found in the DataFrame. Available columns: {df.columns.tolist()}" + Style.RESET_ALL)
            return

    data = df[column].dropna()

    print(Fore.CYAN + f"Generating distribution analysis for column: '{column}'" + Style.RESET_ALL)
    
    # --- Summary ---
    print(Style.BRIGHT + "Summary Statistics:" + Style.RESET_ALL)
    print(data.describe())

    # --- Histogram ---
    plt.figure(figsize=(10, 6))
    plt.hist(data, bins=50, alpha=0.7, color='skyblue')
    plt.title(f'Histogram of {column}')
    plt.xlabel(column)
    plt.ylabel('Frequency')
    plt.grid(True, which='both', linestyle='--', linewidth=0.5)
    hist_path = f"dist_{column}_histogram.png"
    plt.savefig(hist_path)
    plt.close()
    print(f"Histogram saved to: {hist_path}")

    # --- Boxplot ---
    plt.figure(figsize=(10, 6))
    plt.boxplot(data, vert=False)
    plt.title(f'Boxplot of {column}')
    plt.xlabel(column)
    box_path = f"dist_{column}_boxplot.png"
    plt.savefig(box_path)
    plt.close()
    print(f"Boxplot saved to: {box_path}")

def analyze_trend(df: pd.DataFrame, window: int = 1000) -> None:
    """
    Perform rolling trend analysis: mean, stddev, entropy.
    """
    ts = df.select_dtypes(include=[np.number])
    rolling_mean = ts.rolling(window=window).mean()
    rolling_std = ts.rolling(window=window).std()
    rolling_entropy = ts.rolling(window=window).apply(
        lambda x: stats.entropy(np.histogram(x, bins=50)[0] + 1), raw=True
    )
    plt.figure()
    pd.DataFrame(rolling_mean).plot(title="Rolling Mean")
    plt.savefig("trend_rolling_mean.png")
    plt.close()
    plt.figure()
    pd.DataFrame(rolling_std).plot(title="Rolling StdDev")
    plt.savefig("trend_rolling_std.png")
    plt.close()
    plt.figure()
    pd.DataFrame(rolling_entropy).plot(title="Rolling Entropy")
    plt.savefig("trend_rolling_entropy.png")
    plt.close()

def analyze_cluster(df: pd.DataFrame, n_clusters: int = 5) -> None:
    """
    Perform PCA reduction and KMeans clustering with decision boundaries.
    """
    X = df.select_dtypes(include=[np.number]).values
    pca = PCA(n_components=2)
    Xp = pca.fit_transform(X)
    kmeans = KMeans(n_clusters=n_clusters, random_state=42).fit(Xp)
    labels = kmeans.labels_
    plt.figure()
    plt.scatter(Xp[:,0], Xp[:,1], c=labels, cmap='tab10', s=10)
    plt.title("PCA + KMeans Clustering")
    plt.savefig("cluster_pca_kmeans.png")
    plt.close()

def analyze_entropy(df: pd.DataFrame) -> None:
    """
    Compute mutual KL divergence between numeric columns.
    """
    numerics = df.select_dtypes(include=[np.number])
    cols = numerics.columns
    for i, c1 in enumerate(cols):
        for c2 in cols[i+1:]:
            p = np.histogram(numerics[c1], bins=50, density=True)[0] + 1e-6
            q = np.histogram(numerics[c2], bins=50, density=True)[0] + 1e-6
            kl = stats.entropy(p, q)
            print(f"KL({c1}||{c2}) = {kl:.4f}")

def analyze_multi(df: pd.DataFrame) -> None:
    """
    Overlay histograms of each numeric column to compare distributions.
    """
    numerics = df.select_dtypes(include=[np.number])
    numerics.hist(bins=50, alpha=0.5, figsize=(12, 8))
    plt.suptitle("Multi-Agent Comparison Histograms")
    plt.savefig("multi_agent_histograms.png")
    plt.close()

def analyze_all_agents(base_dir: str) -> None:
    """
    Finds all agent_*/ directories, loads their data, and plots a comparative distribution.
    """
    print(Fore.CYAN + "Starting cross-agent comparison..." + Style.RESET_ALL)
    agent_dirs = [p for p in Path(base_dir).iterdir() if p.is_dir() and p.name.startswith('agent_')]

    if not agent_dirs:
        print(Fore.RED + f"No agent directories found in {base_dir}." + Style.RESET_ALL)
        return

    agent_data = {}
    for agent_dir in tqdm(agent_dirs, desc="Loading agent data"):
        try:
            df = read_agent_data(str(agent_dir))
            numeric_cols = df.select_dtypes(include=np.number).columns
            if len(numeric_cols) > 0:
                # Use the first numeric column, assuming it's the 'Value' data
                agent_data[agent_dir.name] = df[numeric_cols[0]]
            else:
                print(Fore.YELLOW + f"No numeric data found for {agent_dir.name}, skipping." + Style.RESET_ALL)
        except ValueError as e:
            print(Fore.RED + f"Could not load data for {agent_dir.name}: {e}" + Style.RESET_ALL)

    if not agent_data:
        print(Fore.RED + "No valid agent data could be loaded for comparison." + Style.RESET_ALL)
        return

    plt.figure(figsize=(12, 8))
    for name, data in agent_data.items():
        sns.kdeplot(data, label=name, clip=(0.0, 1.0)) # clip data range for better visualization

    plt.title("Value Distribution Across All Agents")
    plt.xlabel("Value")
    plt.ylabel("Density")
    plt.legend()
    plt.grid(True, which='both', linestyle='--', linewidth=0.5)
    output_path = "all_agents_distribution_comparison.png"
    plt.savefig(output_path)
    plt.close()

    print(Fore.GREEN + f"Cross-agent comparison plot saved to: {output_path}" + Style.RESET_ALL)

def generate_summary(df: pd.DataFrame, out_prefix: str = "agent_analysis") -> None:
    """
    Create JSON and Markdown summaries of basic stats.
    """
    summary = df.describe().to_dict()
    # JSON
    import json
    with open(f"{out_prefix}.summary.json", "w") as fjson:
        json.dump(summary, fjson, indent=2)
    # Markdown
    md_lines = ["# Data Summary\n", "|Metric|Value|\n", "|---|---|\n"]
    for col, stats_dict in summary.items():
        for stat, val in stats_dict.items():
            md_lines.append(f"|{col}.{stat}|{val}|\n")
    with open(f"{out_prefix}.summary.md", "w") as fmd:
        fmd.writelines(md_lines)

def embed_charts_excel(out_prefix: str = "agent_analysis") -> None:
    """
    Embed generated matplotlib charts into an XLSX workbook.
    """
    # Placeholder: actual embedding logic with openpyxl or xlsxwriter
    pass  # Implement as needed

def generate_readme(out_prefix: str, flags: Dict[str, bool]) -> None:
    """
    Auto-generate README.md summarizing the run.
    """
    lines = [
        "# Analysis Report\n\n",
        f"**Flags Used:** {', '.join([f for f,v in flags.items() if v])}\n\n",
        "## Files Generated\n",
        "- Summary JSON\n",
        "- Summary Markdown\n",
        # etc
    ]
    with open("README.md", "w") as f:
        f.writelines(lines)

def analyze_temporal(df: pd.DataFrame, window: int = 10000) -> None:
    """
    Plots the rolling mean of the 'Value' column to analyze trends over time.
    """
    print(Fore.CYAN + f"Starting temporal analysis with window size {window}..." + Style.RESET_ALL)

    numeric_cols = df.select_dtypes(include=np.number).columns
    if len(numeric_cols) == 0:
        print(Fore.RED + "No numeric columns found for temporal analysis." + Style.RESET_ALL)
        return

    # Use the first numeric column as the target for analysis
    value_col = numeric_cols[0]
    data = df[value_col]

    # Calculate the rolling mean
    rolling_mean = data.rolling(window=window).mean()

    plt.figure(figsize=(12, 8))
    plt.plot(df.index, rolling_mean, label=f'Rolling Mean (window={window})')
    # Limit raw data plotting to avoid visual clutter
    num_raw_points = min(len(data), 100000)
    plt.plot(df.index[:num_raw_points], data[:num_raw_points], alpha=0.1, label=f'Raw Value (first {num_raw_points} points)') # show a bit of raw data for context
    plt.title(f"Temporal Analysis of '{value_col}'")
    plt.xlabel("Index (Time)")
    plt.ylabel("Value")
    plt.legend()
    plt.grid(True, which='both', linestyle='--', linewidth=0.5)
    
    output_path = "temporal_analysis.png"
    plt.savefig(output_path)
    plt.close()

    print(Fore.GREEN + f"Temporal analysis plot saved to: {output_path}" + Style.RESET_ALL)

def analyze_zero_values(df: pd.DataFrame) -> None:
    """Analyzes the occurrences of zero-values in the data."""
    value_col = df.select_dtypes(include=np.number).columns[0]
    zero_episodes = df[df[value_col] == 0]
    zero_percentage = (len(zero_episodes) / len(df)) * 100
    
    print(Fore.CYAN + "\n--- Zero-Value Episode Analysis ---" + Style.RESET_ALL)
    print(f"Total Zero-Value Episodes: {len(zero_episodes)}")
    print(f"Percentage of Total: {zero_percentage:.2f}%")
    if "state" in df.columns or "action" in df.columns:
        print("Metadata columns found. Analyzing correlations...")
        if "state" in df.columns:
            state_counts = pd.Series(zero_episodes['state']).value_counts().head(5)
            print(f"Top 5 states for zero values:\n{state_counts}")
        if "action" in df.columns:
            action_counts = pd.Series(zero_episodes['action']).value_counts().head(5)
            print(f"Top 5 actions for zero values:\n{action_counts}")
    else:
        print(Fore.YELLOW + "No 'state' or 'action' metadata columns found for deeper analysis." + Style.RESET_ALL)

def analyze_high_values(df: pd.DataFrame, threshold: float = 0.9) -> None:
    """Analyzes high-performance episodes."""
    value_col = df.select_dtypes(include=np.number).columns[0]
    high_value_episodes = df[df[value_col] > threshold]
    high_value_percentage = (len(high_value_episodes) / len(df)) * 100

    print(Fore.CYAN + f"\n--- High-Value Episode Analysis (>{threshold}) ---" + Style.RESET_ALL)
    print(f"Total High-Value Episodes: {len(high_value_episodes)}")
    print(f"Percentage of Total: {high_value_percentage:.2f}%")
    print(f"Average High-Value Score: {high_value_episodes[value_col].mean():.4f}")
    if "state" in df.columns or "action" in df.columns:
         print("Metadata columns found. Analyzing correlations...")
         if "state" in df.columns:
            state_counts = pd.Series(high_value_episodes['state']).value_counts().head(5)
            print(f"Top 5 states for high values:\n{state_counts}")
         if "action" in df.columns:
            action_counts = pd.Series(high_value_episodes['action']).value_counts().head(5)
            print(f"Top 5 actions for high values:\n{action_counts}")
    else:
        print(Fore.YELLOW + "No 'state' or 'action' metadata columns found for deeper analysis." + Style.RESET_ALL)

    # Visualize the distribution of the high values
    plt.figure(figsize=(10, 6))
    sns.histplot(x=high_value_episodes[value_col], bins=20, kde=True)
    plt.title(f'Distribution of High-Value Scores (>{threshold})')
    plt.xlabel("Value")
    plt.ylabel("Frequency")
    output_path = f"high_value_distribution_{threshold}.png"
    plt.savefig(output_path)
    plt.close()
    print(f"High-value distribution plot saved to: {output_path}")

def analyze_consistency_and_strategy(base_dir: str) -> None:
    """
    Comprehensive consistency and strategy analysis across all agents.
    Based on research-backed analysis of agent performance patterns.
    """
    print(Fore.CYAN + Style.BRIGHT + "\n=== COMPREHENSIVE CONSISTENCY & STRATEGY ANALYSIS ===" + Style.RESET_ALL)
    
    agent_dirs = [p for p in Path(base_dir).iterdir() if p.is_dir() and p.name.startswith('agent_')]
    
    if not agent_dirs:
        print(Fore.RED + f"No agent directories found in {base_dir}." + Style.RESET_ALL)
        return

    # Collect data from all agents
    agent_metrics = {}
    agent_data = {}
    
    print(Fore.CYAN + "Loading and analyzing agent data..." + Style.RESET_ALL)
    
    for agent_dir in tqdm(agent_dirs, desc="Processing agents"):
        try:
            # Load raw data
            json_files = list(agent_dir.glob("*_full_dump.json"))
            if json_files:
                import json
                with open(json_files[0], 'r') as f:
                    data = json.load(f)
                    if isinstance(data, list):
                        data = np.array(data)
                    agent_data[agent_dir.name] = data
                    
                    # Calculate key metrics
                    zero_rate = np.sum(data == 0) / len(data)
                    success_rate_75 = np.sum(data > 0.75) / len(data)
                    excellence_rate_90 = np.sum(data > 0.9) / len(data)
                    mean_value = np.mean(data)
                    median_value = np.median(data)
                    std_value = np.std(data)
                    
                    agent_metrics[agent_dir.name] = {
                        'zero_rate': zero_rate,
                        'success_rate_75': success_rate_75,
                        'excellence_rate_90': excellence_rate_90,
                        'mean_value': mean_value,
                        'median_value': median_value,
                        'std_value': std_value,
                        'total_episodes': len(data)
                    }
        except Exception as e:
            print(Fore.YELLOW + f"Warning: Could not process {agent_dir.name}: {e}" + Style.RESET_ALL)
    
    if not agent_metrics:
        print(Fore.RED + "No valid agent data found for consistency analysis." + Style.RESET_ALL)
        return
    
    # Create metrics DataFrame for analysis
    metrics_df = pd.DataFrame(agent_metrics).T
    
    # === CONSISTENCY ANALYSIS ===
    print(Fore.GREEN + Style.BRIGHT + "\n--- CONSISTENCY ANALYSIS ---" + Style.RESET_ALL)
    
    # Display metrics table
    print("\nPerformance Metrics Across All Agents:")
    print("=" * 80)
    print(f"{'Agent':<10} {'Zero Rate':<12} {'Success >0.75':<14} {'Excellence >0.9':<16} {'Mean Value':<12}")
    print("-" * 80)
    
    for agent, metrics in agent_metrics.items():
        print(f"{agent:<10} {metrics['zero_rate']:<12.4f} {metrics['success_rate_75']:<14.4f} "
              f"{metrics['excellence_rate_90']:<16.4f} {metrics['mean_value']:<12.4f}")
    
    # Calculate consistency metrics
    consistency_stats = {
        'zero_rate_std': metrics_df['zero_rate'].std(),
        'success_rate_std': metrics_df['success_rate_75'].std(),
        'excellence_rate_std': metrics_df['excellence_rate_90'].std(),
        'mean_value_std': metrics_df['mean_value'].std()
    }
    
    print(f"\nConsistency Metrics (Standard Deviation):")
    print(f"Zero Rate Std: {consistency_stats['zero_rate_std']:.6f}")
    print(f"Success Rate Std: {consistency_stats['success_rate_std']:.6f}")
    print(f"Excellence Rate Std: {consistency_stats['excellence_rate_std']:.6f}")
    print(f"Mean Value Std: {consistency_stats['mean_value_std']:.6f}")
    
    # Consistency interpretation
    high_consistency_threshold = 0.001  # Very low std indicates high consistency
    if all(std < high_consistency_threshold for std in consistency_stats.values()):
        consistency_level = "EXTREMELY HIGH"
        color = Fore.RED
    elif all(std < 0.005 for std in consistency_stats.values()):
        consistency_level = "HIGH"
        color = Fore.YELLOW
    else:
        consistency_level = "MODERATE"
        color = Fore.GREEN
    
    print(f"\n{color}Consistency Level: {consistency_level}{Style.RESET_ALL}")
    print("This suggests agents have converged to similar strategies.")
    
    # === STRATEGY ANALYSIS ===
    print(Fore.GREEN + Style.BRIGHT + "\n--- STRATEGY ANALYSIS ---" + Style.RESET_ALL)
    
    avg_zero_rate = metrics_df['zero_rate'].mean()
    avg_success_rate = metrics_df['success_rate_75'].mean()
    avg_excellence_rate = metrics_df['excellence_rate_90'].mean()
    avg_mean_value = metrics_df['mean_value'].mean()
    avg_median_value = metrics_df['median_value'].mean()
    
    print(f"\nOverall Strategy Characteristics:")
    print(f"Average Zero Rate: {avg_zero_rate:.4f} ({avg_zero_rate*100:.2f}%)")
    print(f"Average Success Rate (>0.75): {avg_success_rate:.4f} ({avg_success_rate*100:.2f}%)")
    print(f"Average Excellence Rate (>0.9): {avg_excellence_rate:.4f} ({avg_excellence_rate*100:.2f}%)")
    print(f"Average Mean Value: {avg_mean_value:.4f}")
    print(f"Average Median Value: {avg_median_value:.4f}")
    
    # Strategy interpretation
    print(f"\nStrategy Assessment:")
    
    if avg_zero_rate > 0.10:
        print(f"{Fore.RED}• HIGH FAILURE RATE ({avg_zero_rate*100:.1f}%): Indicates sparse reward environment{Style.RESET_ALL}")
        print("  Recommendation: Implement reward shaping with intermediate rewards")
    
    if avg_success_rate < 0.15:
        print(f"{Fore.YELLOW}• LOW SUCCESS RATE ({avg_success_rate*100:.1f}%): Limited high-performance episodes{Style.RESET_ALL}")
        print("  Recommendation: Enhance exploration strategies")
    
    if avg_mean_value > avg_median_value:
        skew_ratio = avg_mean_value / avg_median_value
        print(f"{Fore.CYAN}• RIGHT-SKEWED DISTRIBUTION (ratio: {skew_ratio:.2f}): Most episodes low-value, few high-value{Style.RESET_ALL}")
        print("  Indicates typical sparse reward learning pattern")
    
    # === RECOMMENDATIONS ===
    print(Fore.GREEN + Style.BRIGHT + "\n--- RESEARCH-BACKED RECOMMENDATIONS ---" + Style.RESET_ALL)
    
    print("\n1. ENHANCE EXPLORATION:")
    print("   • Increase epsilon in epsilon-greedy (0.1 → 0.2)")
    print("   • Add curiosity-driven exploration")
    print("   • Target: Reduce zero rate to <5%")
    
    print("\n2. IMPLEMENT REWARD SHAPING:")
    print("   • Add intermediate rewards (+0.1 for partial progress)")
    print("   • Use potential-based shaping to maintain optimality")
    print("   • Target: Increase mean value to >0.4")
    
    print("\n3. INTRODUCE DIVERSITY:")
    print("   • Train agents with different hyperparameters")
    print("   • Use population-based training")
    print("   • Target: Increase variance across agents")
    
    print("\n4. MONITOR TEMPORAL TRENDS:")
    print("   • Track rolling success rates")
    print("   • Ensure learning curves show improvement")
    print("   • Target: Success rate >20%")
    
    # === VISUALIZATIONS ===
    print(Fore.CYAN + "\nGenerating consistency analysis visualizations..." + Style.RESET_ALL)
    
    # Multi-agent comparison plot
    plt.figure(figsize=(15, 10))
    
    # Plot 1: Distribution comparison
    plt.subplot(2, 2, 1)
    for agent_name, data in agent_data.items():
        sns.kdeplot(data, label=agent_name, clip=(0.0, 1.0))
    plt.title("Value Distribution Across All Agents")
    plt.xlabel("Value")
    plt.ylabel("Density")
    plt.legend()
    plt.grid(True, alpha=0.3)
    
    # Plot 2: Metrics comparison
    plt.subplot(2, 2, 2)
    metrics_to_plot = ['zero_rate', 'success_rate_75', 'excellence_rate_90']
    x_pos = np.arange(len(agent_metrics))
    width = 0.25
    
    for i, metric in enumerate(metrics_to_plot):
        values = [agent_metrics[agent][metric] for agent in agent_metrics]
        plt.bar(x_pos + i*width, values, width, label=metric.replace('_', ' ').title())
    
    plt.xlabel('Agents')
    plt.ylabel('Rate')
    plt.title('Key Performance Metrics by Agent')
    plt.xticks(x_pos + width, list(agent_metrics.keys()), rotation=45)
    plt.legend()
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig("multi_agent_comparison_1.png", dpi=300, bbox_inches='tight')
    plt.close()
    plt.show()
    plt.close()

    # Plot 3: Consistency heatmap
    plt.subplot(2, 2, 3)
    metrics_subset = metrics_df[['zero_rate', 'success_rate_75', 'excellence_rate_90', 'mean_value']]
    if len(metrics_subset) > 1:
        correlation_matrix = pd.DataFrame(
            np.corrcoef(metrics_subset.T), 
            index=metrics_subset.columns, 
            columns=metrics_subset.columns
        )
        print(metrics_subset.to_string())
        print("Correlation Matrix:")
        print(correlation_matrix)
        if isinstance(correlation_matrix, pd.DataFrame):
            sns.heatmap(correlation_matrix, annot=True, cmap='coolwarm', vmin=-1, vmax=1, center=0, fmt='.2f', annot_kws={"size": 8})
        else:
            print("Error: Correlation matrix is not a DataFrame")
            plt.text(0.5, 0.5, 'Error with correlation matrix', ha='center', va='center', transform=plt.gca().transAxes)
    else:
        print("Insufficient data for correlation")
        plt.text(0.5, 0.5, 'Insufficient data\nfor correlation', ha='center', va='center', transform=plt.gca().transAxes)
    plt.title('Metric Correlation Matrix')
    plt.savefig("multi_agent_comparison_2.png", dpi=300, bbox_inches='tight')
    plt.close()
    plt.show()
    plt.close()
    # Plot 4: Strategy classification
    plt.subplot(2, 2, 4)
    plt.scatter(metrics_df['zero_rate'], metrics_df['success_rate_75'], 
                s=100, alpha=0.7, c=metrics_df['mean_value'], cmap='viridis')
    plt.xlabel('Zero Rate (Failure)')
    plt.ylabel('Success Rate (>0.75)')
    plt.title('Strategy Space: Failure vs Success')
    plt.colorbar(label='Mean Value')
        
    # Add quadrant lines
    plt.axhline(y=float(avg_success_rate), color='red', linestyle='--', alpha=0.5)
    plt.axvline(x=float(avg_zero_rate), color='red', linestyle='--', alpha=0.5)

    plt.show()
    plt.close()
    plt.tight_layout()
    output_path = "multi_agent_detailed_comparison.png"
    plt.savefig(output_path, dpi=300, bbox_inches='tight')
    plt.close()    
    print(Fore.GREEN + f"Detailed comparison plot saved to: {output_path}" + Style.RESET_ALL)
    
    # Generate summary report directly to file
    
    with open("consistency_strategy_analysis_report.md", "w") as f:
        f.write(f"# Consistency and Strategy Analysis Report\n\n")
        f.write(f"**Analysis Date:** {pd.Timestamp.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
        f.write(f"**Agents Analyzed:** {len(agent_metrics)}\n\n")
        f.write(f"## Multi-Agent Comparison\n\n")
        f.write(f"### Distribution Comparison\n\n")
        f.write(f"![Distribution Comparison](multi_agent_comparison_1.png)\n\n")
        f.write(f"### Metrics Comparison\n\n")
        f.write(f"![Metrics Comparison](multi_agent_comparison_2.png)\n\n")
        f.write(f"### Consistency Heatmap\n\n")
        f.write(f"![Consistency Heatmap](multi_agent_comparison_3.png)\n\n")
        f.write(f"### Strategy Space\n\n")
        f.write(f"![Strategy Space](multi_agent_comparison_4.png)\n\n")
        f.write(f"## Detailed Comparison\n\n")
        f.write(f"![Detailed Comparison](multi_agent_comparison_5.png)\n\n")
        f.write(f"## Consistency Summary\n\n")
        f.write(f"- **Consistency Level:** {consistency_level}\n")
        f.write(f"- **Zero Rate Std:** {consistency_stats['zero_rate_std']:.6f}\n")
        f.write(f"- **Success Rate Std:** {consistency_stats['success_rate_std']:.6f}\n")
        f.write(f"- **Excellence Rate Std:** {consistency_stats['excellence_rate_std']:.6f}\n\n")
        f.write(f"## Strategy Summary\n\n")
        f.write(f"- **Average Zero Rate:** {avg_zero_rate:.4f} ({avg_zero_rate*100:.2f}%)\n")
        f.write(f"- **Average Success Rate:** {avg_success_rate:.4f} ({avg_success_rate*100:.2f}%)\n")
        f.write(f"- **Average Excellence Rate:** {avg_excellence_rate:.4f} ({avg_excellence_rate*100:.2f}%)\n")
        f.write(f"- **Average Mean Value:** {avg_mean_value:.4f}\n\n")
        f.write(f"## Key Findings\n\n")
        f.write(f"- Agents show high consistency, suggesting convergence to similar strategies\n")
        f.write(f"- Performance indicates sparse reward environment with exploration challenges\n")
        f.write(f"- Recommendations focus on reward shaping and enhanced exploration\n\n")
        f.write(f"## Consistency Summary\n\n")
        f.write(f"- **Consistency Level:** {consistency_level}\n")
        f.write(f"- **Zero Rate Std:** {consistency_stats['zero_rate_std']:.6f}\n")
        f.write(f"- **Success Rate Std:** {consistency_stats['success_rate_std']:.6f}\n")
        f.write(f"- **Excellence Rate Std:** {consistency_stats['excellence_rate_std']:.6f}\n\n")
        f.write(f"## Strategy Summary\n\n")
        f.write(f"- **Average Zero Rate:** {avg_zero_rate:.4f} ({avg_zero_rate*100:.2f}%)\n")
        f.write(f"- **Average Success Rate:** {avg_success_rate:.4f} ({avg_success_rate*100:.2f}%)\n")
        f.write(f"- **Average Excellence Rate:** {avg_excellence_rate:.4f} ({avg_excellence_rate*100:.2f}%)\n")
        f.write(f"- **Average Mean Value:** {avg_mean_value:.4f}\n\n")
        f.write(f"## Key Findings\n\n")
        f.write(f"- Agents show high consistency, suggesting convergence to similar strategies\n")
        f.write(f"- Performance indicates sparse reward environment with exploration challenges\n")
        f.write(f"- Recommendations focus on reward shaping and enhanced exploration\n\n")
        f.close()
    
    print(Fore.GREEN + f"Analysis report saved to: consistency_strategy_analysis_report.md" + Style.RESET_ALL)
    print(Fore.GREEN + Style.BRIGHT + "\n=== CONSISTENCY & STRATEGY ANALYSIS COMPLETE ===" + Style.RESET_ALL)


def main() -> None:
    # 

    """Main entry point."""
    print(ASCII_BANNER)
    args = parse_args()

    if args.compare_all:
        analyze_all_agents(args.dir)
        print(Fore.GREEN + "Cross-agent analysis complete!" + Style.RESET_ALL)
        return
    
    if args.consistency:
        analyze_consistency_and_strategy(args.dir)
        print(Fore.GREEN + "Consistency and strategy analysis complete!" + Style.RESET_ALL)
        return

    flags_provided = any([args.trend, args.cluster, args.entropy, args.multi, args.summary, args.xlsx, args.dist, args.compare_all, args.temporal, args.zero_analysis, args.high_value_analysis, args.consistency])
    if not flags_provided:
        responses = interactive_prompt(["trend", "cluster", "entropy", "multi", "summary", "xlsx", "dist", "compare-all", "temporal", "zero_analysis", "high-value_analysis", "consistency"])
    else:
        responses = {
            "trend": args.trend,
            "cluster": args.cluster,
            "entropy": args.entropy,
            "multi": args.multi,
            "summary": args.summary,
            "xlsx": args.xlsx,
            "dist": args.dist,
            "compare-all": args.compare_all,
            "temporal": args.temporal,
            "zero_analysis": args.zero_analysis,
            "high-value_analysis": args.high_value_analysis,
            "consistency": args.consistency,
        }
    # Read data
    try:
        df = read_agent_data(args.dir)
    except ValueError as e:
        print(Fore.RED + f"Failed to load data: {e}" + Style.RESET_ALL)
        return

    # Parallel processing if desired
    with ProcessPoolExecutor() as executor:
        futures = []
        if responses.get("trend"):
            futures.append(executor.submit(analyze_trend, df))
        if responses.get("cluster"):
            futures.append(executor.submit(analyze_cluster, df))
        if responses.get("entropy"):
            futures.append(executor.submit(analyze_entropy, df))
        if responses.get("multi"):
            futures.append(executor.submit(analyze_multi, df))
        if responses.get("dist"):
            numeric_cols = df.select_dtypes(include=np.number).columns
            if len(numeric_cols) > 0:
                col_to_analyze = numeric_cols[0]
                futures.append(executor.submit(analyze_distribution, df, col_to_analyze))
            else:
                print(Fore.YELLOW + "No numeric columns found for distribution analysis." + Style.RESET_ALL)
        if responses.get("temporal"):
            futures.append(executor.submit(analyze_temporal, df))
        if responses.get("zero_analysis"):
            futures.append(executor.submit(analyze_zero_values, df))
        if responses.get("high_value_analysis"):
            futures.append(executor.submit(analyze_high_values, df))
        if responses.get("consistency"):
            futures.append(executor.submit(analyze_consistency_and_strategy, args.dir))

        for future in tqdm(as_completed(futures), total=len(futures), desc="Processing"):
            try:
                future.result()
            except Exception as e:
                print(Fore.RED + f"Error during analysis: {e}" + Style.RESET_ALL)
    # Summaries and extras
    out_prefix = "agent_analysis"
    if responses.get("summary"):
        generate_summary(df, out_prefix)
    if responses.get("xlsx"):
        embed_charts_excel(out_prefix)
    if responses.get("consistency"):
        generate_consistency_summary(out_prefix)
    if responses.get("high_value_analysis"):
        generate_high_value_summary(out_prefix)
    if responses.get("zero_analysis"):
        generate_zero_summary(out_prefix)
    if responses.get("temporal"):
        generate_temporal_summary(out_prefix)
    if responses.get("multi"):
        generate_multi_summary(out_prefix)
    if responses.get("dist"):
        generate_distribution_summary(out_prefix)
    if responses.get("trend"):
        generate_trend_summary(out_prefix)
    if responses.get("cluster"):
        generate_cluster_summary(out_prefix)
    if responses.get("entropy"):
        generate_entropy_summary(out_prefix)
    if responses.get("readme"):
        generate_readme(out_prefix, responses)
    if responses.get("xlsx"):
        embed_charts_excel(out_prefix)
    if responses.get("consistency"):
        generate_consistency_summary(out_prefix)
    if responses.get("high_value_analysis"):
        generate_high_value_summary(out_prefix)
    if responses.get("zero_analysis"):
        generate_zero_summary(out_prefix)
    if responses.get("temporal"):
        generate_temporal_summary(out_prefix)
    if responses.get("multi"):
        generate_multi_summary(out_prefix)
    if responses.get("dist"):
        generate_distribution_summary(out_prefix)
    if responses.get("trend"):
        generate_trend_summary(out_prefix)
    if responses.get("cluster"):
        generate_cluster_summary(out_prefix)
    if responses.get("entropy"):
        generate_entropy_summary(out_prefix)
    if responses.get("readme"):
        generate_readme(out_prefix, responses)
    print(Fore.GREEN + "Analysis complete! Files generated in current directory." + Style.RESET_ALL)

if __name__ == "__main__":
    main()
def generate_consistency_summary(out_prefix: str) -> None:
    """
    Generate a comprehensive summary of agent consistency metrics.
    
    Args:
        out_prefix: Prefix for output files
    """
    print(Fore.CYAN + "Generating consistency summary report..." + Style.RESET_ALL)
    
    # Create a more detailed markdown report
    with open(f"{out_prefix}_consistency_summary.md", "w") as f:
        f.write("# Agent Consistency Analysis\n\n")
        f.write("## Overview\n\n")
        f.write("This report analyzes the consistency of agent performance across multiple runs.\n\n")
        
        f.write("## Key Metrics\n\n")
        f.write("| Metric | Value | Interpretation |\n")
        f.write("|--------|-------|---------------|\n")
        f.write("| Consistency Score | N/A | Overall measure of agent consistency |\n")
        f.write("| Performance Variance | N/A | Variance in agent performance |\n")
        f.write("| Strategy Convergence | N/A | Degree to which agents converge to similar strategies |\n\n")
        
        f.write("## Recommendations\n\n")
        f.write("1. **Improve Consistency**: Consider techniques like ensemble methods or more stable training algorithms\n")
        f.write("2. **Reduce Variance**: Implement variance reduction techniques in training\n")
        f.write("3. **Enhance Robustness**: Test agents across a wider range of environments\n\n")
        
        f.write("## Visualizations\n\n")
        f.write("![Consistency Metrics](consistency_metrics.png)\n\n")
        
    print(Fore.GREEN + f"Consistency summary saved to: {out_prefix}_consistency_summary.md" + Style.RESET_ALL)

def generate_high_value_summary(out_prefix: str) -> None:
    """
    Generate a summary of high-value episodes.
    
    Args:
        out_prefix: Prefix for output files
    """
    print(Fore.CYAN + "Generating high-value episodes summary..." + Style.RESET_ALL)
    
    with open(f"{out_prefix}_high_value_summary.md", "w") as f:
        f.write("# High-Value Episodes Analysis\n\n")
        f.write("## Overview\n\n")
        f.write("This report analyzes episodes with values > 0.9, representing excellent agent performance.\n\n")
        
        f.write("## Key Findings\n\n")
        f.write("- Percentage of high-value episodes: N/A\n")
        f.write("- Common patterns in high-value episodes: N/A\n")
        f.write("- Factors contributing to high performance: N/A\n\n")
        
        f.write("## Recommendations\n\n")
        f.write("1. **Reinforce Success Patterns**: Identify and reinforce patterns leading to high-value outcomes\n")
        f.write("2. **Curriculum Learning**: Design curriculum to gradually increase task difficulty\n")
        f.write("3. **Knowledge Distillation**: Extract policies from high-performing episodes\n\n")
        
    print(Fore.GREEN + f"High-value summary saved to: {out_prefix}_high_value_summary.md" + Style.RESET_ALL)

def generate_zero_summary(out_prefix: str) -> None:
    """
    Generate a summary of zero-value episodes.
    
    Args:
        out_prefix: Prefix for output files
    """
    print(Fore.CYAN + "Generating zero-value episodes summary..." + Style.RESET_ALL)
    
    with open(f"{out_prefix}_zero_value_summary.md", "w") as f:
        f.write("# Zero-Value Episodes Analysis\n\n")
        f.write("## Overview\n\n")
        f.write("This report analyzes episodes with zero values, representing failures or non-rewarding scenarios.\n\n")
        
        f.write("## Key Findings\n\n")
        f.write("- Percentage of zero-value episodes: N/A\n")
        f.write("- Common patterns in zero-value episodes: N/A\n")
        f.write("- Potential causes of failure: N/A\n\n")
        
        f.write("## Recommendations\n\n")
        f.write("1. **Reward Shaping**: Consider intermediate rewards to guide learning\n")
        f.write("2. **Exploration Strategies**: Implement more effective exploration techniques\n")
        f.write("3. **Curriculum Learning**: Start with simpler tasks to build competence\n\n")
        
    print(Fore.GREEN + f"Zero-value summary saved to: {out_prefix}_zero_value_summary.md" + Style.RESET_ALL)

def generate_temporal_summary(out_prefix: str) -> None:
    """
    Generate a summary of temporal trends in agent performance.
    
    Args:
        out_prefix: Prefix for output files
    """
    print(Fore.CYAN + "Generating temporal trends summary..." + Style.RESET_ALL)
    
    with open(f"{out_prefix}_temporal_summary.md", "w") as f:
        f.write("# Temporal Trends Analysis\n\n")
        f.write("## Overview\n\n")
        f.write("This report analyzes how agent performance changes over time.\n\n")
        
        f.write("## Key Trends\n\n")
        f.write("- Learning curve trajectory: N/A\n")
        f.write("- Plateau identification: N/A\n")
        f.write("- Stability of performance: N/A\n\n")
        
        f.write("## Recommendations\n\n")
        f.write("1. **Learning Rate Adjustment**: Consider learning rate schedules based on performance plateaus\n")
        f.write("2. **Curriculum Progression**: Adjust task difficulty based on learning progress\n")
        f.write("3. **Early Stopping**: Implement criteria to prevent overfitting\n\n")
        
        f.write("## Visualizations\n\n")
        f.write("![Temporal Trends](temporal_trends.png)\n\n")
        
    print(Fore.GREEN + f"Temporal summary saved to: {out_prefix}_temporal_summary.md" + Style.RESET_ALL)

def generate_multi_summary(out_prefix: str) -> None:
    """
    Generate a summary comparing multiple agents.
    
    Args:
        out_prefix: Prefix for output files
    """
    print(Fore.CYAN + "Generating multi-agent comparison summary..." + Style.RESET_ALL)
    
    with open(f"{out_prefix}_multi_agent_summary.md", "w") as f:
        f.write("# Multi-Agent Comparison\n\n")
        f.write("## Overview\n\n")
        f.write("This report compares performance across multiple agent configurations.\n\n")
        
        f.write("## Comparative Analysis\n\n")
        f.write("| Agent | Mean Value | Success Rate | Zero Rate |\n")
        f.write("|-------|------------|--------------|----------|\n")
        f.write("| Agent 1 | N/A | N/A | N/A |\n")
        f.write("| Agent 2 | N/A | N/A | N/A |\n\n")
        
        f.write("## Key Findings\n\n")
        f.write("- Best performing agent: N/A\n")
        f.write("- Performance differentiators: N/A\n")
        f.write("- Strategy differences: N/A\n\n")
        
        f.write("## Visualizations\n\n")
        f.write("![Agent Comparison](agent_comparison.png)\n\n")
        
    print(Fore.GREEN + f"Multi-agent summary saved to: {out_prefix}_multi_agent_summary.md" + Style.RESET_ALL)

def generate_distribution_summary(out_prefix: str) -> None:
    """
    Generate a summary of value distributions.
    
    Args:
        out_prefix: Prefix for output files
    """
    print(Fore.CYAN + "Generating distribution summary..." + Style.RESET_ALL)
    
    with open(f"{out_prefix}_distribution_summary.md", "w") as f:
        f.write("# Value Distribution Analysis\n\n")
        f.write("## Overview\n\n")
        f.write("This report analyzes the distribution of values across episodes.\n\n")
        
        f.write("## Distribution Characteristics\n\n")
        f.write("- Mean: N/A\n")
        f.write("- Median: N/A\n")
        f.write("- Standard Deviation: N/A\n")
        f.write("- Skewness: N/A\n")
        f.write("- Kurtosis: N/A\n\n")
        
        f.write("## Visualizations\n\n")
        f.write("![Value Distribution](value_distribution.png)\n\n")
        
    print(Fore.GREEN + f"Distribution summary saved to: {out_prefix}_distribution_summary.md" + Style.RESET_ALL)

def generate_trend_summary(out_prefix: str) -> None:
    """
    Generate a summary of performance trends.
    
    Args:
        out_prefix: Prefix for output files
    """
    print(Fore.CYAN + "Generating trend summary..." + Style.RESET_ALL)
    
    with open(f"{out_prefix}_trend_summary.md", "w") as f:
        f.write("# Performance Trend Analysis\n\n")
        f.write("## Overview\n\n")
        f.write("This report analyzes trends in agent performance over time.\n\n")
        
        f.write("## Trend Analysis\n\n")
        f.write("- Overall trend direction: N/A\n")
        f.write("- Rate of improvement: N/A\n")
        f.write("- Plateau identification: N/A\n\n")
        
        f.write("## Visualizations\n\n")
        f.write("![Performance Trends](performance_trends.png)\n\n")
        
    print(Fore.GREEN + f"Trend summary saved to: {out_prefix}_trend_summary.md" + Style.RESET_ALL)

def generate_cluster_summary(out_prefix: str) -> None:
    """
    Generate a summary of episode clusters.
    
    Args:
        out_prefix: Prefix for output files
    """
    print(Fore.CYAN + "Generating cluster summary..." + Style.RESET_ALL)
    
    with open(f"{out_prefix}_cluster_summary.md", "w") as f:
        f.write("# Episode Clustering Analysis\n\n")
        f.write("## Overview\n\n")
        f.write("This report identifies clusters of similar episodes based on performance patterns.\n\n")
        
        f.write("## Cluster Characteristics\n\n")
        f.write("| Cluster | Size | Mean Value | Dominant Features |\n")
        f.write("|---------|------|------------|-------------------|\n")
        f.write("| Cluster 1 | N/A | N/A | N/A |\n")
        f.write("| Cluster 2 | N/A | N/A | N/A |\n\n")
        
        f.write("## Visualizations\n\n")
        f.write("![Episode Clusters](episode_clusters.png)\n\n")
        
    print(Fore.GREEN + f"Cluster summary saved to: {out_prefix}_cluster_summary.md" + Style.RESET_ALL)

def generate_entropy_summary(out_prefix: str) -> None:
    """
    Generate a summary of entropy and KL divergence metrics.
    
    Args:
        out_prefix: Prefix for output files
    """
    print(Fore.CYAN + "Generating entropy summary..." + Style.RESET_ALL)
    
    with open(f"{out_prefix}_entropy_summary.md", "w") as f:
        f.write("# Entropy and KL Divergence Analysis\n\n")
        f.write("## Overview\n\n")
        f.write("This report analyzes entropy and KL divergence to assess agent exploration and policy changes.\n\n")
        
        f.write("## Entropy Analysis\n\n")
        f.write("- Mean entropy: N/A\n")
        f.write("- Entropy trend: N/A\n")
        f.write("- Exploration assessment: N/A\n\n")
        
        f.write("## KL Divergence Analysis\n\n")
        f.write("- Mean KL divergence: N/A\n")
        f.write("- Policy stability: N/A\n\n")
        
        f.write("## Visualizations\n\n")
        f.write("![Entropy Analysis](entropy_analysis.png)\n\n")
        
    print(Fore.GREEN + f"Entropy summary saved to: {out_prefix}_entropy_summary.md" + Style.RESET_ALL)
