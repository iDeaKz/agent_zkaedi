# verify_installation.ps1
# Script to verify the ScriptSynthCore installation

Write-Host "`n🔍 Verifying ScriptSynthCore Installation..." -ForegroundColor Cyan

# Check Python version
Write-Host "`n📌 Python Version:" -ForegroundColor Yellow
python --version

# Check if all required files exist
Write-Host "`n📁 Checking project structure:" -ForegroundColor Yellow

$requiredFiles = @(
    "project_module/__init__.py",
    "project_module/core.py",
    "project_module/utils.py",
    "resilience.py",
    "requirements.txt",
    "setup.py",
    "pyproject.toml",
    "Makefile",
    "logging.conf",
    "README.md"
)

$allFilesExist = $true
foreach ($file in $requiredFiles) {
    if (Test-Path $file) {
        Write-Host "  ✓ $file" -ForegroundColor Green
    } else {
        Write-Host "  ✗ $file" -ForegroundColor Red
        $allFilesExist = $false
    }
}

# Check directories
Write-Host "`n📂 Checking directories:" -ForegroundColor Yellow
$requiredDirs = @(
    "docs/source",
    "tests/unit",
    "benchmarks",
    ".github/workflows"
)

foreach ($dir in $requiredDirs) {
    if (Test-Path $dir) {
        Write-Host "  ✓ $dir" -ForegroundColor Green
    } else {
        Write-Host "  ✗ $dir" -ForegroundColor Red
        $allFilesExist = $false
    }
}

if ($allFilesExist) {
    Write-Host "`n✅ All files and directories are present!" -ForegroundColor Green
    Write-Host "`n🎯 Next steps:" -ForegroundColor Cyan
    Write-Host "  1. Install dependencies: pip install -r requirements.txt" -ForegroundColor White
    Write-Host "  2. Install package: pip install -e ." -ForegroundColor White
    Write-Host "  3. Run tests: python -m pytest tests/" -ForegroundColor White
    Write-Host "  4. Build docs: cd docs && make html" -ForegroundColor White
    Write-Host "  5. Run test script: python test_implementation.py" -ForegroundColor White
} else {
    Write-Host "`n❌ Some files are missing. Please check the setup." -ForegroundColor Red
}
