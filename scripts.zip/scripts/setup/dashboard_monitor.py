#!/usr/bin/env python3
"""
Real-Time Performance Dashboard
Provides live monitoring of system performance with visual dashboard.
"""

import time
import json
import threading
from pathlib import Path
from typing import Dict, Any, List
from datetime import datetime
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class PerformanceDashboard:
    """Real-time performance monitoring dashboard."""
    
    def __init__(self, update_interval: float = 5.0):
        self.update_interval = update_interval
        self.repo_root = Path.cwd()
        self.monitoring_active = False
        self.metrics_history = []
        self.alert_thresholds = self._load_thresholds()
        
    def _load_thresholds(self) -> Dict[str, Any]:
        """Load performance thresholds from configuration."""
        baseline_file = self.repo_root / "ci" / "baseline_metrics.json"
        
        # Default thresholds
        thresholds = {
            'pbt_config_generation_time': 15.0,  # ms
            'holomorphic_throughput_min': 0.5,   # M samples/sec
            'memory_usage_max': 85.0,             # %
            'cpu_usage_max': 90.0                 # %
        }
        
        # Load from baseline if available
        if baseline_file.exists():
            try:
                with open(baseline_file, 'r') as f:
                    baseline_data = json.load(f)
                
                # Update thresholds based on baselines
                if 'metrics' in baseline_data:
                    metrics = baseline_data['metrics']
                    
                    # PBT thresholds (150% of baseline)
                    if 'pbt_system' in metrics and 'config_generation_time' in metrics['pbt_system']:
                        baseline_val = metrics['pbt_system']['config_generation_time']['value']
                        thresholds['pbt_config_generation_time'] = baseline_val * 1.5
                    
                    # Holomorphic thresholds (80% of baseline)
                    for key, data in metrics.get('holomorphic_processing', {}).items():
                        if 'throughput' in key:
                            baseline_val = data['value']
                            thresholds['holomorphic_throughput_min'] = baseline_val * 0.8
                            break
                
                logger.info("✅ Loaded thresholds from baseline metrics")
                
            except Exception as e:
                logger.warning(f"⚠️ Failed to load baseline thresholds: {e}")
        
        return thresholds
    
    def measure_current_performance(self) -> Dict[str, Any]:
        """Measure current system performance."""
        current_metrics = {
            'timestamp': datetime.now().isoformat(),
            'pbt_performance': {},
            'holomorphic_performance': {},
            'system_resources': {},
            'alerts': []
        }
        
        try:
            # PBT Performance
            from src.agents.pbt.agent import AgentConfig
            
            start = time.perf_counter()
            config = AgentConfig.random_init()
            config_time = (time.perf_counter() - start) * 1000
            
            current_metrics['pbt_performance'] = {
                'config_generation_time_ms': config_time,
                'learning_rate_property_test': config.learning_rate
            }
            
            # Check PBT threshold
            if config_time > self.alert_thresholds['pbt_config_generation_time']:
                current_metrics['alerts'].append({
                    'component': 'pbt_system',
                    'metric': 'config_generation_time',
                    'current': config_time,
                    'threshold': self.alert_thresholds['pbt_config_generation_time'],
                    'severity': 'warning'
                })
            
        except Exception as e:
            logger.error(f"❌ PBT measurement failed: {e}")
            current_metrics['pbt_performance']['error'] = str(e)
        
        try:
            # Holomorphic Performance
            from src.holomorphic_core import evaluate, default_params
            import numpy as np
            
            test_size = 5000
            t = np.linspace(0, 2*np.pi, test_size)
            params = default_params()
            
            start = time.perf_counter()
            result = evaluate(t, params)
            elapsed = time.perf_counter() - start
            
            throughput = test_size / elapsed / 1e6  # M samples/sec
            
            current_metrics['holomorphic_performance'] = {
                'throughput_m_samples_per_sec': throughput,
                'processing_time_ms': elapsed * 1000,
                'test_size': test_size
            }
            
            # Check holomorphic threshold
            if throughput < self.alert_thresholds['holomorphic_throughput_min']:
                current_metrics['alerts'].append({
                    'component': 'holomorphic_processing',
                    'metric': 'throughput',
                    'current': throughput,
                    'threshold': self.alert_thresholds['holomorphic_throughput_min'],
                    'severity': 'warning'
                })
            
        except Exception as e:
            logger.error(f"❌ Holomorphic measurement failed: {e}")
            current_metrics['holomorphic_performance']['error'] = str(e)
        
        try:
            # System Resources (basic implementation)
            import psutil
            
            cpu_percent = psutil.cpu_percent(interval=1)
            memory = psutil.virtual_memory()
            
            current_metrics['system_resources'] = {
                'cpu_usage_percent': cpu_percent,
                'memory_usage_percent': memory.percent,
                'memory_available_gb': memory.available / (1024**3)
            }
            
        except ImportError:
            current_metrics['system_resources'] = {
                'error': 'psutil not installed - system monitoring disabled'
            }
        except Exception as e:
            current_metrics['system_resources']['error'] = str(e)
        
        return current_metrics
    
    def display_dashboard(self, metrics: Dict[str, Any]) -> None:
        """Display the real-time dashboard."""
        # Clear screen (works on most terminals)
        print("\033[2J\033[H")
        
        # Header
        print("🚀 SCRIPTSYNTHCORE PERFORMANCE DASHBOARD")
        print("=" * 60)
        print(f"📅 {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} | Update: {self.update_interval}s")
        print()
        
        # Alerts section
        if metrics.get('alerts'):
            print("🚨 ACTIVE ALERTS")
            print("-" * 30)
            for alert in metrics['alerts']:
                severity_emoji = "🔥" if alert['severity'] == 'critical' else "⚠️"
                print(f"{severity_emoji} {alert['component']}: {alert['metric']}")
                print(f"   Current: {alert['current']:.2f} | Threshold: {alert['threshold']:.2f}")
            print()
        else:
            print("✅ NO ACTIVE ALERTS")
            print()
        
        # PBT Performance
        pbt = metrics.get('pbt_performance', {})
        if 'error' not in pbt:
            config_time = pbt.get('config_generation_time_ms', 0)
            status = "🟢" if config_time < self.alert_thresholds['pbt_config_generation_time'] else "🟡"
            print("🤖 PBT SYSTEM PERFORMANCE")
            print("-" * 30)
            print(f"{status} Config Generation: {config_time:.2f}ms")
            print(f"🎯 Learning Rate Property: {pbt.get('learning_rate_property_test', 0):.4f}")
        else:
            print("🤖 PBT SYSTEM PERFORMANCE")
            print("-" * 30)
            print(f"❌ Error: {pbt['error']}")
        print()
        
        # Holomorphic Performance
        holo = metrics.get('holomorphic_performance', {})
        if 'error' not in holo:
            throughput = holo.get('throughput_m_samples_per_sec', 0)
            status = "🟢" if throughput > self.alert_thresholds['holomorphic_throughput_min'] else "🟡"
            print("🧠 HOLOMORPHIC PROCESSING")
            print("-" * 30)
            print(f"{status} Throughput: {throughput:.2f}M samples/sec")
            print(f"⏱️ Processing Time: {holo.get('processing_time_ms', 0):.2f}ms")
            print(f"📊 Test Size: {holo.get('test_size', 0):,} samples")
        else:
            print("🧠 HOLOMORPHIC PROCESSING")
            print("-" * 30)
            print(f"❌ Error: {holo['error']}")
        print()
        
        # System Resources
        resources = metrics.get('system_resources', {})
        if 'error' not in resources:
            cpu = resources.get('cpu_usage_percent', 0)
            memory = resources.get('memory_usage_percent', 0)
            cpu_status = "🟢" if cpu < 70 else "🟡" if cpu < 85 else "🔴"
            memory_status = "🟢" if memory < 70 else "🟡" if memory < 85 else "🔴"
            
            print("💻 SYSTEM RESOURCES")
            print("-" * 30)
            print(f"{cpu_status} CPU Usage: {cpu:.1f}%")
            print(f"{memory_status} Memory Usage: {memory:.1f}%")
            print(f"💾 Available Memory: {resources.get('memory_available_gb', 0):.2f}GB")
        else:
            print("💻 SYSTEM RESOURCES")
            print("-" * 30)
            print(f"⚠️ Monitoring unavailable: {resources['error']}")
        print()
        
        # Footer
        print("=" * 60)
        print("Press Ctrl+C to stop monitoring")
    
    def save_metrics_history(self, metrics: Dict[str, Any]) -> None:
        """Save metrics to history for trend analysis."""
        self.metrics_history.append(metrics)
        
        # Keep only last 100 measurements
        if len(self.metrics_history) > 100:
            self.metrics_history.pop(0)
        
        # Save to file periodically
        if len(self.metrics_history) % 10 == 0:
            history_file = self.repo_root / "logs" / "performance_history.json"
            history_file.parent.mkdir(exist_ok=True)
            
            try:
                with open(history_file, 'w') as f:
                    json.dump(self.metrics_history[-50:], f, indent=2)  # Save last 50
            except Exception as e:
                logger.warning(f"⚠️ Failed to save metrics history: {e}")
    
    def run_monitoring(self) -> None:
        """Run continuous monitoring loop."""
        self.monitoring_active = True
        logger.info("🚀 Starting real-time performance monitoring...")
        
        try:
            while self.monitoring_active:
                # Measure current performance
                metrics = self.measure_current_performance()
                
                # Display dashboard
                self.display_dashboard(metrics)
                
                # Save to history
                self.save_metrics_history(metrics)
                
                # Wait for next update
                time.sleep(self.update_interval)
                
        except KeyboardInterrupt:
            logger.info("⏹️ Monitoring stopped by user")
        except Exception as e:
            logger.error(f"❌ Monitoring error: {e}")
        finally:
            self.monitoring_active = False
    
    def start_monitoring(self) -> None:
        """Start monitoring in a separate thread."""
        monitoring_thread = threading.Thread(target=self.run_monitoring)
        monitoring_thread.daemon = True
        monitoring_thread.start()
        return monitoring_thread


def main():
    """Main dashboard function."""
    print("📈 REAL-TIME PERFORMANCE DASHBOARD")
    print("=" * 60)
    
    # Check dependencies
    try:
        import psutil
        logger.info("✅ System monitoring available")
    except ImportError:
        logger.warning("⚠️ psutil not installed. System resource monitoring disabled.")
        print("To enable system monitoring: pip install psutil")
    
    # Create and start dashboard
    dashboard = PerformanceDashboard(update_interval=3.0)
    
    print("\n🚀 Starting dashboard...")
    print("📊 Measuring initial performance...")
    
    # Run monitoring
    dashboard.run_monitoring()


if __name__ == "__main__":
    main() 