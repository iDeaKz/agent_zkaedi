#!/usr/bin/env python3
"""
Performance Baseline Establishment
Establishes initial performance baselines for the monitoring system.
"""

import time
import json
import statistics
import numpy as np
from pathlib import Path
from typing import Dict, Any, List
from dataclasses import dataclass
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@dataclass
class PerformanceBaseline:
    """Represents a performance baseline measurement."""
    component: str
    metric: str
    value: float
    unit: str
    timestamp: str
    sample_count: int

class BaselineEstablisher:
    """Establishes and manages performance baselines."""
    
    def __init__(self):
        self.repo_root = Path.cwd()
        self.ci_dir = self.repo_root / "ci"
        self.ci_dir.mkdir(exist_ok=True)
        self.baselines: List[PerformanceBaseline] = []
    
    def measure_pbt_performance(self, iterations: int = 20) -> Dict[str, Any]:
        """Measure PBT system performance."""
        logger.info("📊 Measuring PBT system performance...")
        
        config_times = []
        learning_rate_tests = []
        
        try:
            from src.agents.pbt.agent import AgentConfig
            
            for i in range(iterations):
                # Measure config generation time
                start = time.perf_counter()
                config = AgentConfig.random_init()
                config_time = (time.perf_counter() - start) * 1000  # ms
                config_times.append(config_time)
                
                # Test learning_rate property performance
                start = time.perf_counter()
                _ = config.learning_rate
                config.learning_rate = 0.002
                _ = config.learning_rate
                lr_time = (time.perf_counter() - start) * 1000  # ms
                learning_rate_tests.append(lr_time)
            
            # Calculate statistics
            config_avg = statistics.mean(config_times)
            lr_avg = statistics.mean(learning_rate_tests)
            
            logger.info(f"✅ PBT Config Generation: {config_avg:.2f}ms avg")
            logger.info(f"✅ Learning Rate Property: {lr_avg:.4f}ms avg")
            
            # Store baselines
            self.baselines.append(PerformanceBaseline(
                component="pbt_system",
                metric="config_generation_time",
                value=config_avg,
                unit="ms",
                timestamp=time.strftime("%Y-%m-%d %H:%M:%S UTC"),
                sample_count=iterations
            ))
            
            return {
                'config_generation_avg': config_avg,
                'learning_rate_property_avg': lr_avg,
                'sample_count': iterations
            }
            
        except Exception as e:
            logger.error(f"❌ PBT performance measurement failed: {e}")
            return {'error': str(e)}
    
    def measure_holomorphic_performance(self, test_sizes: List[int] = None) -> Dict[str, Any]:
        """Measure holomorphic processing performance."""
        logger.info("🧠 Measuring holomorphic processing performance...")
        
        if test_sizes is None:
            test_sizes = [1000, 5000, 10000]
        
        results = {}
        
        try:
            from src.holomorphic_core import evaluate, default_params
            
            for size in test_sizes:
                logger.info(f"Testing {size:,} samples...")
                
                times = []
                throughputs = []
                
                # Run multiple iterations
                for iteration in range(3):
                    t = np.linspace(0, 2*np.pi, size)
                    params = default_params()
                    
                    start = time.perf_counter()
                    result = evaluate(t, params)
                    elapsed = time.perf_counter() - start
                    
                    times.append(elapsed * 1000)  # ms
                    throughput = size / elapsed / 1e6  # M samples/sec
                    throughputs.append(throughput)
                
                # Calculate averages
                avg_time = statistics.mean(times)
                avg_throughput = statistics.mean(throughputs)
                
                results[f'size_{size}'] = {
                    'samples': size,
                    'avg_time_ms': avg_time,
                    'avg_throughput_m_per_sec': avg_throughput
                }
                
                logger.info(f"✅ {size:,} samples: {avg_throughput:.2f}M samples/sec")
                
                # Store baseline
                self.baselines.append(PerformanceBaseline(
                    component="holomorphic_processing",
                    metric=f"throughput_size_{size}",
                    value=avg_throughput,
                    unit="M_samples_per_sec",
                    timestamp=time.strftime("%Y-%m-%d %H:%M:%S UTC"),
                    sample_count=3
                ))
            
            return results
            
        except Exception as e:
            logger.error(f"❌ Holomorphic performance measurement failed: {e}")
            return {'error': str(e)}
    
    def save_baseline_metrics(self) -> None:
        """Save baseline metrics to CI baseline file."""
        baseline_file = self.ci_dir / "baseline_metrics.json"
        
        # Convert baselines to dictionary format
        baseline_data = {
            'timestamp': time.strftime("%Y-%m-%d %H:%M:%S UTC"),
            'establishment_method': 'automated_baseline_script',
            'metrics': {}
        }
        
        for baseline in self.baselines:
            component_key = baseline.component
            if component_key not in baseline_data['metrics']:
                baseline_data['metrics'][component_key] = {}
            
            baseline_data['metrics'][component_key][baseline.metric] = {
                'value': baseline.value,
                'unit': baseline.unit,
                'timestamp': baseline.timestamp,
                'sample_count': baseline.sample_count
            }
        
        with open(baseline_file, 'w') as f:
            json.dump(baseline_data, f, indent=2)
        
        logger.info(f"✅ Baseline metrics saved to {baseline_file}")


def main():
    """Main baseline establishment function."""
    print("📊 PERFORMANCE BASELINE ESTABLISHMENT")
    print("=" * 60)
    
    establisher = BaselineEstablisher()
    
    # Warm up the system
    print("\n🔥 Warming up system...")
    try:
        from src.holomorphic_core import evaluate, default_params
        import numpy as np
        t = np.linspace(0, 1, 100)
        params = default_params()
        _ = evaluate(t, params)  # Warm up JIT
        logger.info("✅ System warmed up")
    except Exception as e:
        logger.warning(f"⚠️ Warmup failed: {e}")
    
    # Measure all components
    print("\n📊 Establishing performance baselines...")
    
    # PBT System
    pbt_results = establisher.measure_pbt_performance()
    
    # Holomorphic Processing  
    holo_results = establisher.measure_holomorphic_performance()
    
    # Save baselines
    establisher.save_baseline_metrics()
    
    # Display results
    print("\n🎯 BASELINE ESTABLISHMENT COMPLETE")
    print("=" * 50)
    
    print(f"✅ {len(establisher.baselines)} baselines established")
    print("🚀 CI/CD pipeline is now ready with performance baselines!")


if __name__ == "__main__":
    main() 