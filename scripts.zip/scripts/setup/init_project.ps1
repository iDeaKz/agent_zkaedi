# init_project_fixed.ps1
# PowerShell script to initialize ScriptSynthCore project structure

Write-Host "🚀 Initializing ScriptSynthCore Project Structure..." -ForegroundColor Cyan

# Create directories
Write-Host "📁 Creating directory structure..." -ForegroundColor Yellow
$directories = @(
    "project_module",
    "docs/source/api",
    "docs/source/guides", 
    "docs/build",
    "tests/unit",
    "tests/integration",
    "tests/blockchain",
    "benchmarks",
    ".github/workflows"
)

foreach ($dir in $directories) {
    New-Item -ItemType Directory -Force -Path $dir | Out-Null
    Write-Host "  ✓ Created $dir" -ForegroundColor Green
}

# Create logs directory for logging
New-Item -ItemType Directory -Force -Path "logs" | Out-Null

Write-Host "`n📝 Creating project files..." -ForegroundColor Yellow

# Helper scripts
$verificationScript = @'
# verify_installation.ps1
Write-Host "`n🔍 Verifying ScriptSynthCore Installation..." -ForegroundColor Cyan

# Check Python version
Write-Host "`n📌 Python Version:" -ForegroundColor Yellow
python --version

# Check if all required files exist
Write-Host "`n📁 Checking project structure:" -ForegroundColor Yellow

$requiredFiles = @(
    "project_module/__init__.py",
    "project_module/core.py", 
    "project_module/utils.py",
    "resilience.py",
    "requirements.txt",
    "setup.py",
    "pyproject.toml",
    "README.md"
)

$allFilesExist = $true
foreach ($file in $requiredFiles) {
    if (Test-Path $file) {
        Write-Host "  ✓ $file" -ForegroundColor Green
    } else {
        Write-Host "  ✗ $file" -ForegroundColor Red
        $allFilesExist = $false
    }
}

if ($allFilesExist) {
    Write-Host "`n✅ All files and directories are present!" -ForegroundColor Green
} else {
    Write-Host "`n❌ Some files are missing. Please check the setup." -ForegroundColor Red
}
'@

Set-Content -Path "verify_installation.ps1" -Value $verificationScript

# Windows-compatible make script
$makeScript = @'
# make.ps1
param([Parameter(Position=0)][string]$Command = "help")

function Show-Help {
    Write-Host "Available commands:" -ForegroundColor Cyan
    Write-Host "  .\make.ps1 help      - Show this help message" -ForegroundColor White
    Write-Host "  .\make.ps1 install   - Install all dependencies" -ForegroundColor White
    Write-Host "  .\make.ps1 test      - Run all tests with coverage" -ForegroundColor White
    Write-Host "  .\make.ps1 clean     - Clean build artifacts" -ForegroundColor White
}

function Install-Dependencies {
    Write-Host "📦 Installing dependencies..." -ForegroundColor Yellow
    pip install -r requirements.txt
    pip install -e .
}

function Run-Tests {
    Write-Host "🧪 Running tests..." -ForegroundColor Yellow
    python -m pytest --cov=project_module --cov-report=term-missing
}

function Clean-Build {
    Write-Host "🧹 Cleaning build artifacts..." -ForegroundColor Yellow
    Remove-Item -Recurse -Force -ErrorAction SilentlyContinue build, dist, *.egg-info
    Remove-Item -Recurse -Force -ErrorAction SilentlyContinue htmlcov, .coverage, .pytest_cache
    Get-ChildItem -Recurse -Filter "*.pyc" | Remove-Item -Force
    Get-ChildItem -Recurse -Filter "__pycache__" -Directory | Remove-Item -Recurse -Force
    Write-Host "✅ Clean complete!" -ForegroundColor Green
}

switch ($Command.ToLower()) {
    "help"    { Show-Help }
    "install" { Install-Dependencies }
    "test"    { Run-Tests }
    "clean"   { Clean-Build }
    default   { 
        Write-Host "Unknown command: $Command" -ForegroundColor Red
        Show-Help 
    }
}
'@

Set-Content -Path "make.ps1" -Value $makeScript

# Core module files
Set-Content -Path 'project_module/__init__.py' -Value @'
"""
ScriptSynthCore - A full-spectrum blockchain API toolkit
"""
__version__ = "0.1.0"
'@

Set-Content -Path 'project_module/core.py' -Value @'
"""
Core functionality of ScriptSynthCore.
"""
import logging
from typing import TypeVar, Callable, Any
from resilience import retry, circuit_breaker, RetryConfig, CircuitBreakerConfig

logger = logging.getLogger(__name__)

T = TypeVar('T')

def compute_heavy(x: int, y: int) -> int:
    """
    Example function that may fail/transient errors.
    
    Args:
        x: First number
        y: Second number
        
    Returns:
        Sum of x and y
    """
    logger.debug(f"Computing heavy: {x} + {y}")
    return x + y

def with_resilience(
    func: Callable[..., T],
    retry_config: RetryConfig = None,
    breaker_config: CircuitBreakerConfig = None
) -> Callable[..., T]:
    """
    Apply resilience patterns to any function.
    
    Args:
        func: Function to decorate
        retry_config: Retry configuration
        breaker_config: Circuit breaker configuration
        
    Returns:
        Decorated function with retry and circuit breaker
    """
    if retry_config is None:
        retry_config = RetryConfig()
    if breaker_config is None:
        breaker_config = CircuitBreakerConfig()
        
    return retry(retry_config)(circuit_breaker(breaker_config)(func))
'@

Set-Content -Path 'project_module/utils.py' -Value @'
"""
Utility functions for ScriptSynthCore.
"""
from typing import Dict, Any

def dummy_data() -> Dict[str, Any]:
    """
    Return a dummy data placeholder.
    
    Returns:
        Empty dictionary
    """
    return {}
'@

# Test files
Set-Content -Path 'tests/__init__.py' -Value ''

Set-Content -Path 'tests/unit/test_core.py' -Value @'
import pytest
from project_module.core import compute_heavy

def test_compute_heavy():
    assert compute_heavy(1, 2) == 3
'@

Set-Content -Path 'tests/unit/test_utils.py' -Value @'
import pytest
from project_module.utils import dummy_data

def test_dummy_data():
    assert isinstance(dummy_data(), dict)
    assert len(dummy_data()) == 0
'@

# Requirements file
Set-Content -Path 'requirements.txt' -Value @'
# Core dependencies
fastapi>=0.95.0
uvicorn>=0.20.0
pydantic>=1.10.0
redis>=4.5.0
pytest>=7.0.0
pytest-cov>=4.0.0
pytest-asyncio>=0.21.0
black>=23.0.0
isort>=5.12.0
flake8>=6.0.0
mypy>=1.0.0
'@

Write-Host "`n✅ Project initialization complete!" -ForegroundColor Green
Write-Host "`n📋 Created helper scripts:" -ForegroundColor Cyan
Write-Host "  - verify_installation.ps1 : Verify project setup" -ForegroundColor White
Write-Host "  - make.ps1               : Windows-compatible make commands" -ForegroundColor White

Write-Host "`n🚀 To get started:" -ForegroundColor Cyan
Write-Host "  1. Run: .\verify_installation.ps1" -ForegroundColor White
Write-Host "  2. Run: .\make.ps1 install" -ForegroundColor White
Write-Host "  3. Run: .\make.ps1 test" -ForegroundColor White 