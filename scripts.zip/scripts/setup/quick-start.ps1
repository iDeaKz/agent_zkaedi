# 🚀 Elite AI Agent System - Quick Start Script
# Handles Docker Desktop startup and deployment

Write-Host "🌟 ELITE AI AGENT SYSTEM - QUICK START" -ForegroundColor Blue
Write-Host "=" * 50 -ForegroundColor Blue

# Function to check if Docker Desktop is running
function Test-DockerRunning {
    try {
        $null = docker ps 2>$null
        return $true
    } catch {
        return $false
    }
}

# Function to start Docker Desktop
function Start-DockerDesktop {
    Write-Host "🐳 Starting Docker Desktop..." -ForegroundColor Yellow
    
    # Try to start Docker Desktop
    $dockerPath = "C:\Program Files\Docker\Docker\Docker Desktop.exe"
    if (Test-Path $dockerPath) {
        Start-Process $dockerPath
        Write-Host "⏳ Waiting for Docker Desktop to start..." -ForegroundColor Yellow
        
        # Wait up to 2 minutes for Docker to start
        $timeout = 120
        $elapsed = 0
        
        while (-not (Test-DockerRunning) -and $elapsed -lt $timeout) {
            Start-Sleep -Seconds 5
            $elapsed += 5
            Write-Host "." -NoNewline -ForegroundColor Yellow
        }
        
        if (Test-DockerRunning) {
            Write-Host "`n✅ Docker Desktop is running!" -ForegroundColor Green
            return $true
        } else {
            Write-Host "`n❌ Docker Desktop failed to start within 2 minutes" -ForegroundColor Red
            return $false
        }
    } else {
        Write-Host "❌ Docker Desktop not found at expected location" -ForegroundColor Red
        Write-Host "Please install Docker Desktop from: https://www.docker.com/products/docker-desktop" -ForegroundColor Yellow
        return $false
    }
}

# Main deployment function
function Start-Deployment {
    Write-Host "🚀 Starting Elite AI Agent System deployment..." -ForegroundColor Green
    
    # Create .env file if it doesn't exist
    if (-not (Test-Path ".env")) {
        Write-Host "📝 Creating environment configuration..." -ForegroundColor Yellow
        
        $envContent = @"
# Elite AI Agent System Environment Configuration
JWT_SECRET_KEY=elite-secret-key-change-in-production
POSTGRES_PASSWORD=elite_password
REDIS_PASSWORD=elite_redis_password
GRAFANA_ADMIN_PASSWORD=elite_admin_password

# Database Configuration
DATABASE_URL=postgresql://elite_user:elite_password@postgres:5432/elite_db
REDIS_URL=redis://redis:6379/0

# Application Configuration
ELITE_MODE=production
LOG_LEVEL=INFO
MONITORING_ENABLED=true

# Security
CORS_ORIGINS=http://localhost:3000,http://localhost:8080
SESSION_TIMEOUT=3600

# Performance
WORKER_PROCESSES=4
MAX_CONNECTIONS=1000
"@
        
        $envContent | Out-File -FilePath ".env" -Encoding utf8
        Write-Host "✅ Environment file created" -ForegroundColor Green
    }
    
    # Create necessary directories
    $dirs = @("logs", "data")
    foreach ($dir in $dirs) {
        if (-not (Test-Path $dir)) {
            New-Item -ItemType Directory -Path $dir -Force | Out-Null
        }
    }
    
    # Start the deployment
    Write-Host "🔨 Building and starting services..." -ForegroundColor Yellow
    
    try {
        # Remove version warning by using newer compose syntax
        docker compose build
        docker compose up -d
        
        Write-Host "⏳ Waiting for services to start..." -ForegroundColor Yellow
        Start-Sleep -Seconds 30
        
        # Check service status
        Write-Host "🔍 Checking service status..." -ForegroundColor Yellow
        docker compose ps
        
        Write-Host "`n🎉 DEPLOYMENT COMPLETE!" -ForegroundColor Green
        Write-Host "=" * 50 -ForegroundColor Green
        
        # Show service URLs
        Write-Host "🌐 Your Elite AI Agent System is available at:" -ForegroundColor Magenta
        Write-Host "   🎛️  Main Dashboard:     http://localhost:8000" -ForegroundColor White
        Write-Host "   📊 Grafana:            http://localhost:3000" -ForegroundColor White
        Write-Host "   📈 Prometheus:         http://localhost:9090" -ForegroundColor White
        Write-Host "   🗄️  PostgreSQL:        localhost:5432" -ForegroundColor White
        Write-Host "   🔴 Redis:              localhost:6379" -ForegroundColor White
        
        Write-Host "`n📋 Quick Commands:" -ForegroundColor Cyan
        Write-Host "   View logs:       docker compose logs -f" -ForegroundColor White
        Write-Host "   Stop system:     docker compose down" -ForegroundColor White
        Write-Host "   Restart:         docker compose restart" -ForegroundColor White
        
    } catch {
        Write-Host "❌ Deployment failed: $($_.Exception.Message)" -ForegroundColor Red
        Write-Host "💡 Try running: docker compose logs" -ForegroundColor Yellow
    }
}

# Main execution
try {
    # Check if Docker is already running
    if (Test-DockerRunning) {
        Write-Host "✅ Docker Desktop is already running" -ForegroundColor Green
        Start-Deployment
    } else {
        Write-Host "⚠️  Docker Desktop is not running" -ForegroundColor Yellow
        
        # Ask user if they want to start Docker Desktop
        $response = Read-Host "Would you like me to start Docker Desktop? (y/n)"
        
        if ($response -eq 'y' -or $response -eq 'Y' -or $response -eq '') {
            if (Start-DockerDesktop) {
                Start-Deployment
            } else {
                Write-Host "❌ Could not start Docker Desktop. Please start it manually and run this script again." -ForegroundColor Red
            }
        } else {
            Write-Host "📝 Please start Docker Desktop manually and run this script again." -ForegroundColor Yellow
            Write-Host "   1. Open Docker Desktop from the Start menu" -ForegroundColor White
            Write-Host "   2. Wait for it to fully start" -ForegroundColor White
            Write-Host "   3. Run this script again: .\quick-start.ps1" -ForegroundColor White
        }
    }
} catch {
    Write-Host "💥 An error occurred: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "🆘 Please ensure Docker Desktop is installed and try again." -ForegroundColor Yellow
}

Write-Host "`n👋 Quick Start completed!" -ForegroundColor Blue 