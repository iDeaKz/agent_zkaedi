#!/usr/bin/env python3
"""
Alert Configuration Setup
Configures webhook alerts and notification systems for the performance monitoring pipeline.
"""

import json
import os
import subprocess
import time
from pathlib import Path
from typing import Dict, Any, Optional, List
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class AlertConfigurationManager:
    """Manages alert configuration for the performance monitoring system."""
    
    def __init__(self):
        self.repo_root = Path.cwd()
        self.config_dir = self.repo_root / "config"
        self.config_dir.mkdir(exist_ok=True)
    
    def setup_github_webhook_secret(self, webhook_url: str) -> bool:
        """Set up GitHub repository secret for webhook alerts."""
        try:
            # Check if GitHub CLI is available
            result = subprocess.run(['gh', '--version'], capture_output=True, text=True)
            if result.returncode != 0:
                logger.error("GitHub CLI (gh) not found. Install: https://cli.github.com/")
                return False
            
            # Set the secret
            cmd = ['gh', 'secret', 'set', 'PERFORMANCE_ALERT_WEBHOOK', '--body', webhook_url]
            result = subprocess.run(cmd, capture_output=True, text=True)
            
            if result.returncode == 0:
                logger.info("✅ Successfully set PERFORMANCE_ALERT_WEBHOOK secret")
                return True
            else:
                logger.error(f"❌ Failed to set GitHub secret: {result.stderr}")
                return False
                
        except Exception as e:
            logger.error(f"❌ Error setting up webhook secret: {e}")
            return False
    
    def test_webhook_connectivity(self, webhook_url: str, platform: str = "slack") -> bool:
        """Test webhook connectivity with a sample alert."""
        try:
            import requests
            
            # Create test payload for Slack
            payload = {
                "text": "🧪 Test Alert from ScriptSynthCore Performance Monitor",
                "attachments": [
                    {
                        "color": "good",
                        "fields": [
                            {"title": "Status", "value": "Webhook Test Successful", "short": True},
                            {"title": "System", "value": "Performance Monitoring", "short": True},
                            {"title": "Time", "value": time.strftime("%Y-%m-%d %H:%M:%S UTC"), "short": True}
                        ]
                    }
                ]
            }
            
            # Send test request
            response = requests.post(
                webhook_url,
                json=payload,
                headers={"Content-Type": "application/json"},
                timeout=10
            )
            
            if response.status_code in [200, 204]:
                logger.info("✅ Webhook test successful!")
                return True
            else:
                logger.error(f"❌ Webhook test failed: HTTP {response.status_code}")
                return False
                
        except Exception as e:
            logger.error(f"❌ Webhook test error: {e}")
            return False
    
    def interactive_setup(self) -> Dict[str, Any]:
        """Interactive setup wizard for alert configuration."""
        print("🔔 ALERT CONFIGURATION WIZARD")
        print("=" * 50)
        
        config = {
            "webhook_url": "",
            "platform": "slack",
            "test_successful": False,
            "setup_date": time.strftime("%Y-%m-%d %H:%M:%S UTC")
        }
        
        print("\n📋 Slack Webhook Setup:")
        print("1. Go to https://api.slack.com/incoming-webhooks")
        print("2. Create a new webhook for your workspace")
        print("3. Choose the channel for alerts (e.g., #alerts)")
        print("4. Copy the webhook URL")
        
        # Webhook URL input
        webhook_url = input("\nEnter your Slack webhook URL: ").strip()
        config["webhook_url"] = webhook_url
        
        if webhook_url:
            # Test webhook
            print("\n🧪 Testing webhook connectivity...")
            test_result = self.test_webhook_connectivity(webhook_url)
            config["test_successful"] = test_result
            
            if test_result:
                # Set GitHub secret
                print("\n🔑 Setting up GitHub repository secret...")
                secret_result = self.setup_github_webhook_secret(webhook_url)
                config["github_secret_set"] = secret_result
                
                if secret_result:
                    print("✅ Complete setup successful!")
                else:
                    print("⚠️ Webhook test passed but GitHub secret setup failed.")
                    print("You can manually set the secret using:")
                    print(f"gh secret set PERFORMANCE_ALERT_WEBHOOK --body '{webhook_url}'")
            else:
                print("❌ Webhook test failed. Please check your URL and try again.")
        
        return config


def main():
    """Main setup function."""
    print("🚀 PERFORMANCE ALERT SETUP")
    print("=" * 60)
    
    manager = AlertConfigurationManager()
    config = manager.interactive_setup()
    
    print("\n🎯 SETUP SUMMARY")
    print("-" * 30)
    print(f"Webhook URL: {config['webhook_url'][:50]}..." if len(config['webhook_url']) > 50 else f"Webhook URL: {config['webhook_url']}")
    print(f"Test Result: {'✅ Success' if config['test_successful'] else '❌ Failed'}")
    print(f"GitHub Secret: {'✅ Set' if config.get('github_secret_set', False) else '❌ Not Set'}")
    
    if config['test_successful']:
        print("\n🎉 Alert system is ready!")
        print("Your CI/CD pipeline will now send alerts on performance issues.")


if __name__ == "__main__":
    main() 