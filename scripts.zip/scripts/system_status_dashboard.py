#!/usr/bin/env python3
"""
Elite AI System Status Dashboard
Comprehensive display of all system test results, checkpoints, and health metrics.
"""

import json
import os
import time
from pathlib import Path
from typing import Dict, Any

def load_test_results() -> Dict[str, Any]:
    """Load the latest test results."""
    results_file = Path('full_system_test_results.json')
    if results_file.exists():
        with open(results_file, 'r') as f:
            return json.load(f)
    return {}

def load_checkpoint_report() -> Dict[str, Any]:
    """Load checkpoint validation report."""
    report_file = Path('checkpoints/validation_report.json')
    if report_file.exists():
        with open(report_file, 'r') as f:
            return json.load(f)
    return {}

def get_checkpoint_stats() -> Dict[str, Any]:
    """Get checkpoint directory statistics."""
    checkpoint_dir = Path('checkpoints')
    if not checkpoint_dir.exists():
        return {'total_files': 0, 'total_size': 0}
    
    pkl_files = list(checkpoint_dir.glob('*.pkl'))
    metadata_files = list(checkpoint_dir.glob('*_metadata.json'))
    
    total_size = sum(f.stat().st_size for f in pkl_files)
    
    return {
        'total_checkpoints': len(pkl_files),
        'metadata_files': len(metadata_files),
        'total_size_mb': total_size / (1024 * 1024),
        'backup_dir_exists': (checkpoint_dir / 'backups').exists(),
        'quarantine_dir_exists': (checkpoint_dir / 'quarantine').exists()
    }

def display_system_header():
    """Display system header."""
    print("🚀" + "=" * 78 + "🚀")
    print("🏆" + " " * 20 + "ELITE AI SYSTEM STATUS DASHBOARD" + " " * 20 + "🏆")
    print("🚀" + "=" * 78 + "🚀")
    print()

def display_test_summary(results: Dict[str, Any]):
    """Display test summary section."""
    if not results:
        print("❌ No test results available")
        return
    
    summary = results.get('test_summary', {})
    
    print("📊 SYSTEM TEST SUMMARY")
    print("=" * 50)
    
    health_score = summary.get('system_health_score', 0)
    total_tests = summary.get('total_tests', 0)
    successful_tests = summary.get('successful_tests', 0)
    failed_tests = summary.get('failed_tests', 0)
    runtime = summary.get('total_runtime', 0)
    
    # Health score with emoji
    if health_score >= 0.9:
        health_emoji = "🏆"
        health_status = "EXCELLENT"
    elif health_score >= 0.7:
        health_emoji = "✅"
        health_status = "GOOD"
    elif health_score >= 0.5:
        health_emoji = "⚠️"
        health_status = "FAIR"
    else:
        health_emoji = "❌"
        health_status = "POOR"
    
    print(f"   {health_emoji} System Health: {health_score:.1%} ({health_status})")
    print(f"   📈 Tests Passed: {successful_tests}/{total_tests}")
    print(f"   ❌ Tests Failed: {failed_tests}")
    print(f"   ⏱️  Runtime: {runtime:.2f}s")
    print()

def display_component_results(results: Dict[str, Any]):
    """Display detailed component results."""
    if not results:
        return
    
    component_results = results.get('component_results', {})
    
    print("🔧 COMPONENT TEST RESULTS")
    print("=" * 50)
    
    for component, result in component_results.items():
        status = result.get('status', 'UNKNOWN')
        
        if status == 'SUCCESS':
            emoji = "✅"
        elif status == 'SKIPPED':
            emoji = "⏭️"
        elif status == 'FAILED':
            emoji = "❌"
        else:
            emoji = "❓"
        
        print(f"   {emoji} {component.replace('_', ' ').title()}: {status}")
        
        # Show performance metrics if available
        if 'performance_metrics' in result:
            metrics = result['performance_metrics']
            for key, value in metrics.items():
                if isinstance(value, float):
                    if 'throughput' in key.lower():
                        print(f"      📊 {key}: {value:,.0f} samples/sec")
                    elif 'rate' in key.lower():
                        print(f"      📊 {key}: {value:.1%}")
                    else:
                        print(f"      📊 {key}: {value:.3f}")
                else:
                    print(f"      📊 {key}: {value}")
        
        # Show errors if failed
        if status == 'FAILED' and 'error' in result:
            error = result['error']
            print(f"      🔴 Error: {error.get('error_type', 'Unknown')}")
            print(f"      💬 Message: {error.get('error_message', 'No message')}")
        
        print()

def display_performance_highlights(results: Dict[str, Any]):
    """Display performance highlights."""
    if not results:
        return
    
    performance_metrics = results.get('performance_metrics', {})
    
    if not performance_metrics:
        return
    
    print("🎯 PERFORMANCE HIGHLIGHTS")
    print("=" * 50)
    
    # Holomorphic processing highlights
    if 'holomorphic_processing' in performance_metrics:
        holo_metrics = performance_metrics['holomorphic_processing']
        max_throughput = holo_metrics.get('max_throughput', 0)
        avg_throughput = holo_metrics.get('avg_throughput', 0)
        
        print(f"   🧠 Holomorphic Processing:")
        print(f"      🚀 Peak Throughput: {max_throughput:,.0f} samples/sec")
        print(f"      📊 Average Throughput: {avg_throughput:,.0f} samples/sec")
        
        # Performance rating
        if max_throughput > 4_000_000:
            print(f"      🏆 Rating: EXCELLENT (>4M samples/sec)")
        elif max_throughput > 2_000_000:
            print(f"      ✅ Rating: GOOD (>2M samples/sec)")
        else:
            print(f"      ⚠️ Rating: NEEDS IMPROVEMENT")
        print()
    
    # System integration highlights
    if 'system_integration' in performance_metrics:
        integration_metrics = performance_metrics['system_integration']
        success_rate = integration_metrics.get('integration_success_rate', 0)
        cohesion = integration_metrics.get('system_cohesion', 0)
        
        print(f"   🔗 System Integration:")
        print(f"      ✅ Success Rate: {success_rate:.1%}")
        print(f"      🤝 System Cohesion: {cohesion:.1%}")
        print()

def display_error_analysis(results: Dict[str, Any]):
    """Display error analysis."""
    if not results:
        return
    
    error_summary = results.get('error_summary', {})
    
    print("🔍 ERROR ANALYSIS")
    print("=" * 50)
    
    total_errors = error_summary.get('total_errors', 0)
    critical_errors = error_summary.get('critical_errors', 0)
    recovery_attempts = error_summary.get('recovery_attempts', 0)
    successful_recoveries = error_summary.get('successful_recoveries', 0)
    
    if total_errors == 0:
        print("   🏆 No errors detected - system running perfectly!")
    else:
        print(f"   📊 Total Errors: {total_errors}")
        print(f"   🔴 Critical Errors: {critical_errors}")
        print(f"   🔧 Recovery Attempts: {recovery_attempts}")
        print(f"   ✅ Successful Recoveries: {successful_recoveries}")
        
        if recovery_attempts > 0:
            recovery_rate = successful_recoveries / recovery_attempts
            print(f"   📈 Recovery Success Rate: {recovery_rate:.1%}")
    
    print()

def display_checkpoint_status():
    """Display checkpoint system status."""
    print("💾 CHECKPOINT SYSTEM STATUS")
    print("=" * 50)
    
    checkpoint_stats = get_checkpoint_stats()
    checkpoint_report = load_checkpoint_report()
    
    total_checkpoints = checkpoint_stats.get('total_checkpoints', 0)
    total_size = checkpoint_stats.get('total_size_mb', 0)
    
    print(f"   📁 Total Checkpoints: {total_checkpoints}")
    print(f"   💾 Total Size: {total_size:.2f} MB")
    
    # Validation status
    if checkpoint_report:
        valid_checkpoints = checkpoint_report.get('valid_checkpoints', 0)
        corrupted_checkpoints = checkpoint_report.get('corrupted_checkpoints', 0)
        
        if total_checkpoints > 0:
            health_rate = valid_checkpoints / total_checkpoints
            if health_rate == 1.0:
                print(f"   🏆 Checkpoint Health: 100% (ALL HEALTHY)")
            elif health_rate >= 0.9:
                print(f"   ✅ Checkpoint Health: {health_rate:.1%} (EXCELLENT)")
            elif health_rate >= 0.7:
                print(f"   ⚠️ Checkpoint Health: {health_rate:.1%} (GOOD)")
            else:
                print(f"   ❌ Checkpoint Health: {health_rate:.1%} (POOR)")
        
        print(f"   ✅ Valid: {valid_checkpoints}")
        print(f"   ❌ Corrupted: {corrupted_checkpoints}")
    else:
        print("   ⚠️ No validation report available")
    
    # Backup system
    if checkpoint_stats.get('backup_dir_exists'):
        print(f"   💾 Backup System: ACTIVE")
    else:
        print(f"   ⚠️ Backup System: NOT CONFIGURED")
    
    print()

def display_recommendations(results: Dict[str, Any]):
    """Display system recommendations."""
    if not results:
        return
    
    recommendations = results.get('system_recommendations', [])
    
    print("🎯 SYSTEM RECOMMENDATIONS")
    print("=" * 50)
    
    if not recommendations:
        print("   🏆 No recommendations - system performing optimally!")
    else:
        for i, rec in enumerate(recommendations, 1):
            print(f"   {i}. {rec}")
    
    print()

def display_system_footer():
    """Display system footer."""
    print("🚀" + "=" * 78 + "🚀")
    current_time = time.strftime("%Y-%m-%d %H:%M:%S")
    print(f"📅 Generated: {current_time}")
    print(f"🏠 Working Directory: {os.getcwd()}")
    print("🚀" + "=" * 78 + "🚀")

def main():
    """Main dashboard function."""
    # Clear screen
    os.system('cls' if os.name == 'nt' else 'clear')
    
    # Load data
    test_results = load_test_results()
    
    # Display dashboard
    display_system_header()
    display_test_summary(test_results)
    display_component_results(test_results)
    display_performance_highlights(test_results)
    display_error_analysis(test_results)
    display_checkpoint_status()
    display_recommendations(test_results)
    display_system_footer()

if __name__ == "__main__":
    main() 