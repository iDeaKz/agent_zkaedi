#!/usr/bin/env python3
"""
Elite AI System - Infrastructure Validation & Performance Analysis
Comprehensive end-to-end validation and bottleneck identification
"""

import time
import sys
import json
import asyncio
import psutil
import requests
from pathlib import Path
from typing import Dict, List, Tuple
import subprocess
import concurrent.futures
from datetime import datetime

class InfrastructureValidator:
    """Comprehensive infrastructure validation and performance analysis"""
    
    def __init__(self):
        self.results = {
            "timestamp": datetime.now().isoformat(),
            "system_info": {},
            "component_status": {},
            "performance_metrics": {},
            "bottlenecks": [],
            "recommendations": []
        }
        
    def print_header(self, title: str):
        """Print formatted section header"""
        print(f"\n{'='*60}")
        print(f"🔍 {title}")
        print(f"{'='*60}")
        
    def check_system_resources(self) -> Dict:
        """Check system resource availability"""
        self.print_header("System Resources Check")
        
        cpu_percent = psutil.cpu_percent(interval=1)
        memory = psutil.virtual_memory()
        disk = psutil.disk_usage('/')
        
        resources = {
            "cpu_usage_percent": cpu_percent,
            "memory_total_gb": round(memory.total / (1024**3), 2),
            "memory_available_gb": round(memory.available / (1024**3), 2),
            "memory_percent": memory.percent,
            "disk_total_gb": round(disk.total / (1024**3), 2),
            "disk_free_gb": round(disk.free / (1024**3), 2),
            "disk_percent": disk.percent
        }
        
        print(f"✅ CPU Usage: {cpu_percent}%")
        print(f"✅ Memory: {memory.percent}% used ({resources['memory_available_gb']}GB available)")
        print(f"✅ Disk: {disk.percent}% used ({resources['disk_free_gb']}GB free)")
        
        # Identify bottlenecks
        if cpu_percent > 80:
            self.results["bottlenecks"].append("High CPU usage detected")
        if memory.percent > 80:
            self.results["bottlenecks"].append("High memory usage detected")
        if disk.percent > 90:
            self.results["bottlenecks"].append("Low disk space warning")
            
        self.results["system_info"] = resources
        return resources
        
    def validate_python_environment(self) -> bool:
        """Validate Python environment and dependencies"""
        self.print_header("Python Environment Validation")
        
        try:
            # Check Python version
            python_version = sys.version
            print(f"✅ Python Version: {sys.version.split()[0]}")
            
            # Check critical imports
            critical_modules = [
                "project_module.core",
                "project_module.utils",
                "resilience",
                "dashboard",
                "pbt"
            ]
            
            failed_imports = []
            for module in critical_modules:
                try:
                    __import__(module)
                    print(f"✅ Module '{module}' loaded successfully")
                except ImportError as e:
                    print(f"❌ Failed to import '{module}': {e}")
                    failed_imports.append(module)
                    
            self.results["component_status"]["python_modules"] = {
                "total": len(critical_modules),
                "successful": len(critical_modules) - len(failed_imports),
                "failed": failed_imports
            }
            
            return len(failed_imports) == 0
            
        except Exception as e:
            print(f"❌ Python environment validation failed: {e}")
            return False
            
    def test_api_endpoints(self) -> Dict:
        """Test API endpoint performance"""
        self.print_header("API Endpoint Performance Testing")
        
        base_url = "http://localhost:8000"
        endpoints = [
            ("/health", "GET", None),
            ("/api/health", "GET", None),
            ("/", "GET", None),
        ]
        
        performance_results = {}
        
        for endpoint, method, data in endpoints:
            url = f"{base_url}{endpoint}"
            try:
                start_time = time.time()
                
                if method == "GET":
                    response = requests.get(url, timeout=5)
                else:
                    response = requests.post(url, json=data, timeout=5)
                    
                end_time = time.time()
                response_time = (end_time - start_time) * 1000  # Convert to ms
                
                performance_results[endpoint] = {
                    "status_code": response.status_code,
                    "response_time_ms": round(response_time, 2),
                    "success": response.status_code < 400
                }
                
                print(f"✅ {endpoint}: {response.status_code} ({response_time:.2f}ms)")
                
                # Identify slow endpoints
                if response_time > 100:
                    self.results["bottlenecks"].append(f"Slow API response: {endpoint} ({response_time:.2f}ms)")
                    
            except requests.exceptions.RequestException as e:
                print(f"❌ {endpoint}: Failed - {type(e).__name__}")
                performance_results[endpoint] = {
                    "status_code": 0,
                    "response_time_ms": 0,
                    "success": False,
                    "error": str(e)
                }
                
        self.results["performance_metrics"]["api_endpoints"] = performance_results
        return performance_results
        
    def test_database_performance(self) -> Dict:
        """Test database query performance"""
        self.print_header("Database Performance Testing")
        
        try:
            # Test database operations
            from project_module.core import BlockchainAPI
            
            api = BlockchainAPI("testnet")
            
            # Measure initialization time
            start_time = time.time()
            test_api = BlockchainAPI("testnet")
            init_time = (time.time() - start_time) * 1000
            
            print(f"✅ BlockchainAPI initialization: {init_time:.2f}ms")
            
            if init_time > 50:
                self.results["bottlenecks"].append(f"Slow BlockchainAPI initialization: {init_time:.2f}ms")
                
            return {"initialization_time_ms": init_time}
            
        except Exception as e:
            print(f"❌ Database performance test failed: {e}")
            return {"error": str(e)}
            
    def test_concurrent_load(self) -> Dict:
        """Test system under concurrent load"""
        self.print_header("Concurrent Load Testing")
        
        def worker_task(worker_id: int) -> Dict:
            """Simulate worker processing"""
            try:
                from project_module.utils import vector_embedding_optimizer
                
                start_time = time.time()
                data = {"id": worker_id, "data": list(range(100))}
                result = vector_embedding_optimizer(data, strategy="performance")
                end_time = time.time()
                
                return {
                    "worker_id": worker_id,
                    "success": True,
                    "duration_ms": (end_time - start_time) * 1000
                }
            except Exception as e:
                return {
                    "worker_id": worker_id,
                    "success": False,
                    "error": str(e)
                }
                
        # Test with increasing concurrent workers
        concurrent_levels = [1, 5, 10, 20]
        load_results = {}
        
        for num_workers in concurrent_levels:
            print(f"\nTesting with {num_workers} concurrent workers...")
            
            start_time = time.time()
            with concurrent.futures.ThreadPoolExecutor(max_workers=num_workers) as executor:
                futures = [executor.submit(worker_task, i) for i in range(num_workers)]
                results = [f.result() for f in concurrent.futures.as_completed(futures)]
            end_time = time.time()
            
            total_time = (end_time - start_time) * 1000
            successful = sum(1 for r in results if r.get("success", False))
            avg_time = sum(r.get("duration_ms", 0) for r in results) / len(results)
            
            load_results[f"{num_workers}_workers"] = {
                "total_time_ms": round(total_time, 2),
                "avg_worker_time_ms": round(avg_time, 2),
                "success_rate": successful / num_workers,
                "throughput_per_second": round(num_workers / (total_time / 1000), 2)
            }
            
            print(f"✅ Completed: {successful}/{num_workers} successful")
            print(f"   Total time: {total_time:.2f}ms")
            print(f"   Throughput: {load_results[f'{num_workers}_workers']['throughput_per_second']} ops/sec")
            
            # Identify scaling issues
            if num_workers > 1 and avg_time > 100:
                self.results["bottlenecks"].append(f"Performance degradation with {num_workers} workers")
                
        self.results["performance_metrics"]["concurrent_load"] = load_results
        return load_results
        
    def test_memory_leaks(self) -> Dict:
        """Test for memory leaks during operations"""
        self.print_header("Memory Leak Detection")
        
        import gc
        
        # Force garbage collection
        gc.collect()
        
        initial_memory = psutil.Process().memory_info().rss / 1024 / 1024  # MB
        
        # Perform repeated operations
        print("Running memory leak test...")
        for i in range(100):
            try:
                from project_module.utils import vector_embedding_optimizer
                data = {"test": list(range(1000))}
                result = vector_embedding_optimizer(data, strategy="memory")
            except:
                pass
                
        # Force garbage collection again
        gc.collect()
        time.sleep(1)
        
        final_memory = psutil.Process().memory_info().rss / 1024 / 1024  # MB
        memory_growth = final_memory - initial_memory
        
        print(f"✅ Initial memory: {initial_memory:.2f}MB")
        print(f"✅ Final memory: {final_memory:.2f}MB")
        print(f"✅ Memory growth: {memory_growth:.2f}MB")
        
        if memory_growth > 50:
            self.results["bottlenecks"].append(f"Potential memory leak: {memory_growth:.2f}MB growth")
            
        return {
            "initial_memory_mb": round(initial_memory, 2),
            "final_memory_mb": round(final_memory, 2),
            "memory_growth_mb": round(memory_growth, 2)
        }
        
    def generate_recommendations(self):
        """Generate recommendations based on findings"""
        self.print_header("Performance Recommendations")
        
        if not self.results["bottlenecks"]:
            self.results["recommendations"].append("✅ No significant bottlenecks detected!")
        else:
            # CPU recommendations
            if any("CPU" in b for b in self.results["bottlenecks"]):
                self.results["recommendations"].append("🔧 Consider optimizing CPU-intensive operations or scaling horizontally")
                
            # Memory recommendations
            if any("memory" in b.lower() for b in self.results["bottlenecks"]):
                self.results["recommendations"].append("🔧 Implement memory pooling and optimize data structures")
                
            # API recommendations
            if any("API" in b for b in self.results["bottlenecks"]):
                self.results["recommendations"].append("🔧 Add caching layer (Redis) for frequently accessed endpoints")
                
            # Concurrency recommendations
            if any("workers" in b for b in self.results["bottlenecks"]):
                self.results["recommendations"].append("🔧 Implement connection pooling and async processing")
                
        for rec in self.results["recommendations"]:
            print(rec)
            
    def save_report(self):
        """Save validation report"""
        report_path = Path("infrastructure_validation_report.json")
        with open(report_path, "w") as f:
            json.dump(self.results, f, indent=2)
        print(f"\n📊 Full report saved to: {report_path}")
        
    def run_full_validation(self):
        """Run complete infrastructure validation"""
        print("\n🚀 ELITE AI SYSTEM - INFRASTRUCTURE VALIDATION")
        print("=" * 60)
        
        # Run all validation steps
        self.check_system_resources()
        self.validate_python_environment()
        self.test_api_endpoints()
        self.test_database_performance()
        self.test_concurrent_load()
        self.test_memory_leaks()
        
        # Generate recommendations
        self.generate_recommendations()
        
        # Save report
        self.save_report()
        
        # Summary
        print("\n" + "="*60)
        print("📊 VALIDATION SUMMARY")
        print("="*60)
        print(f"✅ Components tested: {len(self.results['component_status'])}")
        print(f"⚠️  Bottlenecks found: {len(self.results['bottlenecks'])}")
        print(f"💡 Recommendations: {len(self.results['recommendations'])}")
        
        if self.results["bottlenecks"]:
            print("\n🔍 Key Bottlenecks:")
            for bottleneck in self.results["bottlenecks"][:5]:
                print(f"   - {bottleneck}")
                
        return len(self.results["bottlenecks"]) == 0


if __name__ == "__main__":
    validator = InfrastructureValidator()
    success = validator.run_full_validation()
    sys.exit(0 if success else 1) 