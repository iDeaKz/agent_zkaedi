from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Dict, List, Callable
import numpy as np
from sympy import lambdify, symbols, sin, exp
import matplotlib.pyplot as plt
import json
import os

# Define symbolic variables
t, x = symbols('t x')

# Local fallback symbolic_h_function implementation if missing
try:
    from symbolic_h_function import HWaveFunction, h_wave
except ImportError:
    @dataclass
    class OscillatorComponent:
        A: float
        B: float
        phi: float

        def symbolic(self) -> Any:
            return self.A * sin(self.B * t + self.phi)

    @dataclass
    class DecayComponent:
        C: float
        D: float

        def symbolic(self) -> Any:
            return self.C * exp(-self.D * t)

    @dataclass
    class IntegralComponent:
        lambda_: float
        k: float
        x0: float
        f: Callable[[Any], Any]
        g: Callable[[Any], Any]

        def numerical(self, t_val: float) -> float:
            from scipy.integrate import quad
            def integrand(x_val: float) -> float:
                return (self.f(x_val) * np.cos(x_val)) / (1 + np.exp(-self.k * (x_val - self.x0)))
            result, _ = quad(integrand, 0, t_val)
            return self.lambda_ * result

    @dataclass
    class HWaveFunction:
        oscillators: List[OscillatorComponent] = field(default_factory=list)
        decays: List[DecayComponent] = field(default_factory=list)
        integral: IntegralComponent | None = None

        def symbolic(self) -> Any:
            return sum(osc.symbolic() for osc in self.oscillators) + sum(dec.symbolic() for dec in self.decays)

    def f(x): return x**2
    def g(x): return sin(x)

    h_wave = HWaveFunction(
        oscillators=[OscillatorComponent(2.0, 3.0, 0.5), OscillatorComponent(1.5, 5.0, 1.0)],
        decays=[DecayComponent(4.0, 0.8)],
        integral=IntegralComponent(0.5, 2.0, 1.0, f, g)
    )

@dataclass
class HMemory:
    history: Dict[float, float] = field(default_factory=dict)

    def record(self, time: float, value: float) -> None:
        self.history[time] = value

    def get(self, time: float) -> float | None:
        return self.history.get(time)

@dataclass
class HPlanner:
    start: float
    end: float
    steps: int

    def generate_timesteps(self) -> List[float]:
        return np.linspace(self.start, self.end, self.steps).tolist()

@dataclass
class HExecutor:
    h_wave: HWaveFunction

    def prepare_function(self) -> Any:
        return lambdify('t', self.h_wave.symbolic(), modules=["numpy"])

@dataclass
class VaultRule:
    target: str
    operation: str
    value: float
    activation_time: float = 0.0

@dataclass
class VaultRuleParser:
    rules: List[VaultRule] = field(default_factory=list)

    @staticmethod
    def from_dict(data: List[Dict[str, Any]]) -> VaultRuleParser:
        return VaultRuleParser(rules=[VaultRule(**item) for item in data])

    @staticmethod
    def from_json_file(filepath: str) -> VaultRuleParser:
        with open(filepath, 'r') as f:
            return VaultRuleParser.from_dict(json.load(f))

    def to_json(self, filepath: str) -> None:
        with open(filepath, 'w') as f:
            json.dump([r.__dict__ for r in self.rules], f, indent=2)

@dataclass
class HAgent:
    h_wave: HWaveFunction
    planner: HPlanner
    memory: HMemory = field(default_factory=HMemory)
    mutation_log: List[str] = field(default_factory=list)

    # Sigil style mapping: color and marker per sigil type
    sigil_styles: Dict[str, tuple] = field(default_factory=lambda: {
        'Healing Boost': ('green', '*'),
        'Critical Recovery': ('red', 'o'),
        'Oscillator Sigil': ('blue', '^'),
        'Decay Sigil': ('purple', 's'),
        'Integral Sigil': ('orange', 'D'),
        'Unknown Sigil': ('gray', 'x')
    })

    def apply_vault_rule(self, rule: VaultRule) -> None:
        oc, dc = self.h_wave.oscillators, self.h_wave.decays
        if rule.target.startswith("oscillator["):
            idx = int(rule.target.split("[")[1].split("]")[0])
            attr = rule.target.split('.')[1]
            setattr(oc[idx], attr, getattr(oc[idx], attr) + rule.value)
        elif rule.target.startswith("decay["):
            idx = int(rule.target.split("[")[1].split("]")[0])
            attr = rule.target.split('.')[1]
            setattr(dc[idx], attr, getattr(dc[idx], attr) + rule.value)
        elif rule.target == "integral.lambda_" and self.h_wave.integral:
            self.h_wave.integral.lambda_ += rule.value

    def apply_active_rules(self, t_val: float, vp: VaultRuleParser) -> None:
        dt = (self.planner.end - self.planner.start) / self.planner.steps
        pending = [r for r in vp.rules if abs(r.activation_time - t_val) < dt / 2]
        for r in pending:
            self.apply_vault_rule(r)
            self.mutation_log.append(f"Applied {r.target} {r.operation} {r.value} at t={t_val:.4f}")
            vp.rules.remove(r)

    def auto_generate_sigils(self, t_val: float, vp: VaultRuleParser) -> None:
        val = self.memory.get(t_val)
        if val is None:
            return
        if val > 25 or val < -10:
            if val > 25:
                rule = VaultRule("decay[0].C", "add", -0.3, t_val + 1)
                label = "Healing Boost"
            else:
                rule = VaultRule("oscillator[0].A", "add", 1.0, t_val + 1)
                label = "Critical Recovery"
            vp.rules.append(rule)
            self.mutation_log.append(f"Auto-generated sigil ({label}): {rule.target} {rule.operation} {rule.value} at t={rule.activation_time:.4f}")

    def run_simulation(self, vp: VaultRuleParser = None) -> None:
        f = HExecutor(self.h_wave).prepare_function()
        for t_val in self.planner.generate_timesteps():
            if vp:
                self.apply_active_rules(t_val, vp)
            val = f(t_val) + (self.h_wave.integral.numerical(t_val) if self.h_wave.integral else 0)
            self.memory.record(t_val, val)
            if vp:
                self.auto_generate_sigils(t_val, vp)

    def generate_sigil_image(self, filepath: str = "healing_sigil.png") -> None:
        fig, ax = plt.subplots(figsize=(6, 6))
        times, vals = zip(*sorted(self.memory.history.items()))
        ax.plot(times, vals, alpha=0.2, linewidth=2)
        for entry in self.mutation_log:
            if 'at t=' in entry:
                t0 = float(entry.split('at t=')[1])
                label = next((lbl for lbl in self.sigil_styles if lbl in entry), 'Unknown Sigil')
                color, marker = self.sigil_styles[label]
                ax.scatter(t0, 0, s=300, c=color, marker=marker)
        ax.axis('off')
        fig.savefig(filepath, bbox_inches='tight')
        plt.close(fig)
        print(f"Sigil image saved to {filepath}")

    def display_memory(self) -> None:
        print("\n=== H(t) Evaluation Memory ===")
        for t_val, v in sorted(self.memory.history.items()):
            print(f"t={t_val:.4f} -> H(t)={v:.6f}")
        print("\n==============================")

    def display_mutation_history(self) -> None:
        print("\n=== Mutation History ===")
        for m in self.mutation_log:
            print(m)
        print("\n========================")

    def plot_memory(self) -> None:
        times, vals = zip(*sorted(self.memory.history.items()))
        plt.plot(times, vals, marker='o', label='H(t)')
        seen = set()
        for e in self.mutation_log:
            t0 = float(e.split('at t=')[1])
            label = next((lbl for lbl in self.sigil_styles if lbl in e), 'Unknown Sigil')
            color, marker = self.sigil_styles[label]
            if label not in seen:
                plt.axvline(t0, color=color, linestyle='--', label=label)
                seen.add(label)
            else:
                plt.axvline(t0, color=color, linestyle='--')
            plt.scatter(t0, max(vals), s=100, c=color, marker=marker)
        plt.title("Evolution of H(t) with Healing Sigil Activations")
        plt.xlabel("Time (t)")
        plt.ylabel("H(t)")
        plt.grid(True)
        plt.legend()
        plt.savefig("h_evolution_sigils.png")
        plt.close()

if __name__ == "__main__":
    agent = HAgent(h_wave, HPlanner(0, 10, 50))
    agent.run_simulation()
    agent.display_memory()
    agent.display_mutation_history()
    # agent.plot_memory()  # Commented out to avoid blocking
    agent.generate_sigil_image()
