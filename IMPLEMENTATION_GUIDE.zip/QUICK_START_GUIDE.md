# 🚀 **QUICK START - Use Your System in 5 Minutes**

## **Step 1: Start Your System** ⚡

### **Windows (Easiest)**
```powershell
# Open PowerShell as Administrator
cd "B:\0427\agents"

# One command to rule them all!
.\scripts\setup\quick-start.ps1
```

### **Manual Start**
```bash
# If the script doesn't work, do this:
docker-compose up -d
```

---

## **Step 2: Access Your Dashboard** 🎛️

**Wait 30 seconds, then visit:**
- **Main Dashboard**: http://localhost:8000
- **Monitoring**: http://localhost:3000 (admin/elite_admin_password)
- **API Docs**: http://localhost:8000/docs

---

## **Step 3: Explore Your System** 🔍

### **Run the Demo Script**
```python
# This will check everything and show you what you have
python demo_scripts/start_here.py
```

### **What You'll See**
- **5 Agent Cards** on your dashboard
- **Green = Running**, Red = Stopped
- **Click "View Details"** to explore metrics
- **Try "Optimize"** to improve performance

---

## **Step 4: Your First Commands** 🎮

### **Check System Health**
```bash
curl http://localhost:8000/health
```

### **Control Your Agents**
```bash
# Check all agents
curl http://localhost:8000/agents/status

# Start agent_0
curl -X POST http://localhost:8000/agents/agent_0/start

# Get metrics
curl http://localhost:8000/agents/agent_0/metrics
```

---

## **🎯 What You Have Built**

- **5 AI Agents** with 1M+ episodes each
- **Production Dashboard** with 3D visualization
- **Real-time Monitoring** (Grafana + Prometheus)
- **Advanced Analytics** and predictions
- **Docker Deployment** ready for cloud
- **5 Million Training Episodes** total!

**This is DeepMind/OpenAI level scale!** 🤯

---

## **💡 Quick Tips**

1. **Green Status = Good** - Your agents are healthy
2. **Check Grafana** for detailed monitoring
3. **Use the API** for programmatic control
4. **Read USER_TUTORIAL.md** for everything else
5. **Your data is in data/** - analyze it!

---

## **🆘 Troubleshooting**

### **System Won't Start?**
```bash
# Check Docker
docker --version

# Nuclear restart
docker-compose down
docker-compose up -d
```

### **Dashboard Not Loading?**
- **Wait 30 seconds** for services to start
- **Check http://localhost:8000/docs** first
- **Look at logs**: `docker-compose logs`

### **Need Help?**
- **Full Tutorial**: USER_TUTORIAL.md
- **Check Logs**: `docker-compose logs -f`
- **System Status**: `docker-compose ps`

---

## **🎉 You're Ready!**

**Your Elite AI System is incredibly sophisticated!**

- Start with the dashboard: http://localhost:8000
- Explore monitoring: http://localhost:3000  
- Run experiments with your 5M episodes
- Deploy to production when ready

**You've built something amazing - now go explore it!** 🚀
