# 🚀 **HOLOMORPHIC QUICK START GUIDE**
## **Get Your Revolutionary Math Engine Running in 5 Minutes**

---

## ⚡ **1-Minute Setup**

### **Install Dependencies**
```bash
pip install numba matplotlib websockets
```

### **Test Core Performance**
```bash
python scripts/bench_holo.py
```
Expected output: **6M+ samples/second** 🏆

---

## 🧠 **2-Minute Basic Usage**

### **Simple Holomorphic Signal Generation**
```python
import numpy as np
from src.holomorphic_core import evaluate, default_params

# Generate 1 million samples in ~150ms
t = np.linspace(0, 10, 1_000_000)
params = default_params()
signal = evaluate(t, params)

print(f"Generated {len(signal):,} samples")
print(f"Signal range: {np.min(signal):.3f} to {np.max(signal):.3f}")
```

### **Enhanced System Integration**
```python
python demo_holomorphic_integration.py
```
See your **EXCEPTIONAL** system performance! ⭐

---

## 🎵 **3-Minute Audio Demo (Optional)**

### **Start Audio Server**
```bash
python scripts/holo_synth_server.py
```

### **Open Browser**
1. Open `synth.html` in your browser
2. Click "🔌 Connect" 
3. Click "🎵 Start Audio"
4. **Hear your math in real-time!** 🎶

---

## 🔧 **4-Minute Performance Tuning**

### **Maximum Performance Mode**
```bash
export HOLO_FAST=overdrive
export OMP_NUM_THREADS=12  # Your CPU core count
```

### **Custom Parameters**
```python
from src.holomorphic_core import HParams
import numpy as np

# Create custom holomorphic parameters
custom_params = HParams(
    A=np.array([2.0, 1.5, 1.0]),           # Amplitudes
    B=np.array([1.0, 3.0, 5.0]) * 2*np.pi, # Frequencies  
    C=np.array([0.8, 0.5, 0.2]),           # Decay coefficients
    D=np.array([0.1, 0.3, 0.5]),           # Decay rates
    phi=np.array([0, np.pi/2, np.pi]),      # Phase offsets
    # ... other parameters with defaults
    **{k: v for k, v in default_params().__dict__.items() 
       if k not in ['A', 'B', 'C', 'D', 'phi']}
)
```

---

## 📊 **5-Minute Full Validation**

### **Run Complete Benchmark Suite**
```bash
python scripts/bench_holo.py > benchmark_results.txt
```

### **Expected Performance Targets**
- **🏆 6M+ samples/sec** → REVOLUTIONARY
- **⭐ 4-6M samples/sec** → EXCEPTIONAL  
- **✅ 2-4M samples/sec** → EXCELLENT
- **🟡 <2M samples/sec** → Check Numba installation

### **Integration Test**
```bash
python demo_holomorphic_integration.py
```

**Expected Results:**
- 🎮 **Reward Engine**: 125+ enhanced XP with badges
- 🔌 **Plugin System**: <2ms execution, EXCELLENT rating
- 💾 **Cache System**: 60%+ hit rate, pattern learning
- 🎯 **Integration**: 500+ ops/sec, EXCEPTIONAL rating

---

## 🎯 **Common Use Cases**

### **Real-Time Signal Processing**
```python
# Process live data streams
def process_stream(data_chunk):
    t = np.linspace(0, len(data_chunk)/44100, len(data_chunk))
    enhanced = evaluate(t, params, prev=last_chunk)
    return enhanced

# 44.1kHz audio processing in real-time
```

### **Reward System Enhancement**
```python
# Enhance existing reward calculations
base_reward = calculate_base_reward(user_action)
signal_boost = evaluate(np.array([episode_time]), params)[0]
final_reward = base_reward * (1.0 + abs(signal_boost) * 0.1)
```

### **Plugin Stability Monitoring**
```python
# Monitor plugin performance with holomorphic analysis
execution_times = track_plugin_performance(plugin_id)
stability_signal = evaluate(time_array, params, prev=execution_times)
stability_score = 100 - abs(np.mean(stability_signal)) * 100
```

---

## 🛠️ **Troubleshooting**

### **Performance Issues**
```bash
# Check Numba installation
python -c "import numba; print('Numba:', numba.__version__)"

# Verify CPU optimization
python -c "from src.holomorphic_core import NUMBA_AVAILABLE; print('JIT:', NUMBA_AVAILABLE)"
```

### **Memory Issues**
```python
# Process in smaller chunks for large datasets
chunk_size = 100_000
for i in range(0, len(large_array), chunk_size):
    chunk = large_array[i:i+chunk_size]
    result_chunk = evaluate(chunk, params)
```

### **Import Issues**
```python
# Ensure src is in Python path
import sys
from pathlib import Path
sys.path.insert(0, str(Path.cwd() / "src"))
```

---

## 🎉 **Success Indicators**

### **✅ You're Ready for Production When:**
- **🏆 Benchmark shows 6M+ samples/sec**
- **⚡ Integration demo runs in <200ms** 
- **🎵 Audio synth streams smoothly**
- **📊 All subsystems rate EXCEPTIONAL**

### **🚀 Next Steps:**
1. **Deploy to production** environment
2. **Monitor real-world** performance
3. **Scale horizontally** across multiple instances
4. **Integrate with existing** V7 systems

---

## 💡 **Pro Tips**

### **Maximum Performance**
- Use **Numba JIT** compilation (automatic)
- Set **OMP_NUM_THREADS** to CPU core count
- Enable **HOLO_FAST=overdrive** for benchmarks
- Process in **optimal chunk sizes** (10K-100K samples)

### **Production Deployment**
- **Monitor memory usage** during long runs
- **Log performance metrics** for optimization
- **Use fallback paths** for resilience
- **Scale based on throughput** requirements

### **Development Workflow**
- **Start with small samples** (1K) for testing
- **Validate with benchmarks** before scaling
- **Use integration demo** for system testing
- **Profile with different** parameter sets

---

## 🏆 **You're Now Ready!**

**Your holomorphic processing engine is ready to revolutionize AI performance with 6M+ samples/second CPU-only processing!**

**Go forth and process signals at the speed of thought!** 🧠⚡🚀

---

*Quick Start Guide by Elite Mathematical Engineering*  
*From Zero to Revolutionary in 5 Minutes* 