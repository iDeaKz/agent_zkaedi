# 🚀 Agent Monitoring Platform - Comprehensive Developer Documentation

**The Ultimate Developer's Guide to the Agent Monitoring Ecosystem**

[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/downloads/)
[![TypeScript](https://img.shields.io/badge/typescript-5.0+-blue.svg)](https://www.typescriptlang.org/)
[![React](https://img.shields.io/badge/react-18+-blue.svg)](https://reactjs.org/)
[![FastAPI](https://img.shields.io/badge/fastapi-0.95+-green.svg)](https://fastapi.tiangolo.com/)

## 📖 Table of Contents

1. [🏗️ System Architecture](#-system-architecture)
2. [🔧 Core Components](#-core-components)
3. [🚀 Quick Start Guide](#-quick-start-guide)
4. [📊 API Reference](#-api-reference)
5. [🧩 Plugin System](#-plugin-system)
6. [🛡️ Security Framework](#-security-framework)
7. [📈 Monitoring & Observability](#-monitoring--observability)
8. [🔄 Resilience Patterns](#-resilience-patterns)
9. [🧪 Testing Strategy](#-testing-strategy)
10. [🚢 Deployment Guide](#-deployment-guide)
11. [🔍 Debugging & Troubleshooting](#-debugging--troubleshooting)
12. [🛠️ Development Workflow](#-development-workflow)

---

## 🏗️ System Architecture

### High-Level Overview

```mermaid
graph TB
    subgraph "Frontend Layer"
        UI[React Dashboard]
        VIZ[3D Visualizations]
        CHARTS[Real-time Charts]
    end
    
    subgraph "API Gateway"
        PROXY[Vite Proxy]
        CORS[CORS Handler]
        RATE[Rate Limiter]
    end
    
    subgraph "Backend Services"
        API[FastAPI Main]
        AUTH[Auth Service]
        ANOMALY[Anomaly Detection]
        AUDIT[Audit Logging]
        PLUGINS[Plugin System]
    end
    
    subgraph "Data Layer"
        REDIS[(Redis Cache)]
        SQLITE[(SQLite DB)]
        METRICS[(Metrics Store)]
    end
    
    subgraph "Resilience Core"
        CIRCUIT[Circuit Breakers]
        RETRY[Retry Patterns]
        HEALTH[Health Checks]
    end
    
    UI --> PROXY
    PROXY --> API
    API --> AUTH
    API --> ANOMALY
    API --> AUDIT
    API --> PLUGINS
    API --> REDIS
    API --> SQLITE
    API --> CIRCUIT
```

### Technology Stack

#### Frontend
- **React 18** - Modern UI framework with hooks
- **TypeScript** - Type-safe JavaScript
- **Material-UI** - Component library
- **Vite** - Build tool and dev server
- **Three.js** - 3D visualizations
- **Chart.js** - Data visualization
- **Framer Motion** - Animations

#### Backend
- **FastAPI** - High-performance Python API framework
- **Pydantic** - Data validation and serialization
- **SQLAlchemy** - Database ORM
- **Redis** - Caching and real-time data
- **JWT** - Authentication tokens
- **Prometheus** - Metrics collection

#### Infrastructure
- **Docker** - Containerization
- **GitHub Actions** - CI/CD pipeline
- **Playwright** - E2E testing
- **Locust** - Load testing

---

## 🔧 Core Components

### 1. Dashboard Backend (`dashboard/backend/`)

#### Main Application (`main.py`)
```python
# Entry point with lifecycle management
@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup: Initialize all services
    initialize_resilience_system()
    await anomaly_engine.init_redis()
    plugin_health_check = initialize_plugin_health_check(plugin_manager)
    
    yield
    
    # Shutdown: Cleanup resources
    resilience_manager.stop_all_health_checks()
```

**Key Features:**
- Lifespan management for graceful startup/shutdown
- CORS middleware for cross-origin requests
- Rate limiting with Redis backend
- Comprehensive error handling
- Structured logging with trace IDs

#### Authentication System (`auth.py`, `auth_service.py`)
```python
# JWT with refresh token rotation
class AuthService:
    - Short-lived access tokens (5 minutes)
    - Rotating refresh tokens (30 minutes)
    - Device fingerprint binding
    - IP hash verification
    - RBAC with hierarchical roles
```

#### Anomaly Detection (`anomaly_service.py`)
```python
# Multi-model ensemble approach
class AnomalyEngine:
    detectors = {
        "halfspace": HalfSpaceTrees(n_trees=10),
        "lof": LocalOutlierFactor(n_neighbors=20),
        "svm": OneClassSVM(nu=0.1)
    }
    
    # Dynamic threshold adjustment
    # Redis persistence with 7-day retention
    # WebSocket streaming interface
```

#### Plugin System (`plugin_sandbox.py`)
```python
# Secure execution environment
class PluginSandbox:
    - Process isolation with subprocess
    - Resource limits (CPU, memory, time)
    - Import whitelist validation
    - Checksum verification
    - Health monitoring
```

### 2. Dashboard Frontend (`dashboard/frontend/`)

#### React Architecture
```typescript
// Plugin-based architecture
interface Plugin {
  name: string;
  init(): Promise<void>;
  destroy?(): Promise<void>;
  onError?(error: Error): void;
}

// Main plugins:
- MetricsPlugin: Data collection
- VisualizationPlugin: Charts and graphs
- AgentPlugin: Agent monitoring
```

#### Component Structure
```
src/
├── components/
│   ├── AgentVisualization.tsx    # 3D network graph
│   ├── AuditLogViewer.tsx       # Security audit trail
│   └── LoginDialog.tsx          # Authentication UI
├── config/
│   ├── security.ts              # Security configuration
│   ├── performance.ts           # Performance monitoring
│   └── accessibility.ts         # A11y configuration
├── plugins/
│   ├── PluginManager.ts         # Plugin lifecycle
│   ├── usePlugin.ts             # React hook
│   └── index.ts                 # Plugin registry
```

### 3. Resilience Core (`resilience_core/`)

#### Retry Pattern
```python
@retry_on_exception(RetryConfig(
    max_attempts=3,
    base_delay=1.0,
    exponential_base=2.0,
    jitter=True
))
def unreliable_operation():
    # Your code here
    pass
```

#### Circuit Breaker
```python
breaker = CircuitBreaker(CircuitBreakerConfig(
    failure_threshold=5,
    recovery_timeout=60.0
))

result = breaker.call(external_service_call)
```

#### Health Monitoring
```python
health_thread = HealthCheckThread(
    check_function=system_health_check,
    interval=30.0
)
health_thread.start()
```

---

## 🚀 Quick Start Guide

### Prerequisites
```bash
# Required software
- Python 3.10+
- Node.js 18+
- Redis 6+
- Git

# Optional for development
- Docker & Docker Compose
- PostgreSQL 14+ (production)
```

### One-Command Setup
```bash
# Clone and setup everything
git clone <repository-url>
cd agents
make install  # Installs all dependencies
make dev      # Starts all services
```

### Manual Setup

#### Backend Setup
```bash
cd dashboard/backend
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate
pip install -r requirements.txt

# Start Redis
docker run -d -p 6379:6379 redis:alpine

# Configure environment
cp ../env.example .env
# Edit .env with your settings

# Start backend
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

#### Frontend Setup
```bash
cd dashboard/frontend
npm ci
npm run dev
```

### Verification
```bash
# Check services
curl http://localhost:8000/health
curl http://localhost:5173

# Run tests
make test
```

---

## 📊 API Reference

### Authentication Endpoints

#### Login
```http
POST /token
Content-Type: application/x-www-form-urlencoded

username=admin&password=admin123
```

Response:
```json
{
  "access_token": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9...",
  "token_type": "bearer"
}
```

#### Refresh Token
```http
POST /auth/refresh
Content-Type: application/json
Authorization: Bearer <token>

{
  "refresh_token": "refresh_token_here",
  "device_fingerprint": "device_id"
}
```

### Agent Management

#### List Agents
```http
GET /agents
Authorization: Bearer <token>
```

Response:
```json
{
  "agents": [
    {
      "id": "agent1",
      "name": "Blockchain Agent",
      "status": "active",
      "last_active": "2024-01-01T12:00:00Z",
      "metrics": {
        "cpu_usage": 45.2,
        "memory_usage": 256.5,
        "response_time": 106,
        "success_rate": 0.98
      }
    }
  ]
}
```

#### Execute Agent Action
```http
POST /agents/{agent_id}/action
Authorization: Bearer <token>
Content-Type: application/json

{
  "action": "restart",
  "parameters": {
    "force": false,
    "timeout": 30
  }
}
```

### Anomaly Detection

#### Single Detection
```http
POST /anomaly/detect
Content-Type: application/json

{
  "metric": "cpu_usage",
  "value": 95.5,
  "timestamp": 1640995200.0,
  "agent_id": "agent1"
}
```

Response:
```json
{
  "metric": "cpu_usage",
  "value": 95.5,
  "score": 0.8,
  "threshold": 0.7,
  "is_anomaly": true,
  "timestamp": 1640995200.0,
  "confidence": 0.92
}
```

#### WebSocket Streaming
```javascript
const ws = new WebSocket('ws://localhost:8000/anomaly/ws/stream');
ws.onmessage = (event) => {
  const anomaly = JSON.parse(event.data);
  console.log('Real-time anomaly:', anomaly);
};
```

### Audit Logging

#### Create Audit Entry
```http
POST /audit
Authorization: Bearer <token>
Content-Type: application/json

{
  "actor": "admin",
  "action": "execute",
  "target": "agent:agent1",
  "meta": {
    "action_type": "restart",
    "parameters": {"force": false}
  }
}
```

#### Verify Audit Chain
```http
GET /audit/verify
Authorization: Bearer <token>
```

Response:
```json
{
  "valid": true,
  "total_entries": 1247,
  "checked_entries": 1247,
  "integrity_hash": "sha256:abc123..."
}
```

### Plugin System

#### List Plugins
```http
GET /plugins
Authorization: Bearer <token>
```

#### Execute Plugin
```http
POST /plugins/{plugin_name}/execute
Authorization: Bearer <token>
Content-Type: application/json

{
  "data": {
    "input": "process this data"
  },
  "config": {
    "timeout": 10
  }
}
```

---

## 🧩 Plugin System

### Plugin Architecture

The plugin system provides secure, isolated execution of custom code with comprehensive monitoring and resource controls.

#### Plugin Interface
```python
def execute(**kwargs):
    """
    Main entry point for plugin execution.
    
    Args:
        **kwargs: Arguments passed from the dashboard
        
    Returns:
        Any JSON-serializable result
    """
    # Plugin logic here
    return {"result": "success"}

# Optional metadata
__plugin_info__ = {
    "name": "my_plugin",
    "version": "1.0.0",
    "author": "Developer Name",
    "description": "Plugin description"
}
```

#### Plugin Configuration
```python
config = PluginConfig(
    name="my_plugin",
    version="1.0.0",
    module="plugins.my_plugin",
    allowed_imports=["json", "datetime", "math"],
    resource_limits=ResourceLimits(
        cpu_seconds=5,
        memory_mb=256,
        timeout_seconds=10
    ),
    read_only=True,
    network_enabled=False
)
```

#### Security Features
- **Process Isolation**: Plugins run in separate processes
- **Resource Limits**: CPU, memory, and time constraints
- **Import Restrictions**: Whitelist-based module access
- **Checksum Verification**: Integrity validation
- **Audit Logging**: All executions are logged

#### Plugin Development Workflow
```bash
# Create plugin template
make create-plugin NAME=my_plugin

# Validate plugin
make validate-plugin PLUGIN=my_plugin

# Test plugin locally
make test-plugin PLUGIN=my_plugin

# Deploy plugin
make deploy-plugin PLUGIN=my_plugin
```

---

## 🛡️ Security Framework

### Authentication & Authorization

#### JWT Token Flow
```mermaid
sequenceDiagram
    Client->>+API: Login (username/password)
    API->>+Redis: Check rate limit
    API->>API: Validate credentials
    API->>-Client: Access token (5min) + Refresh token (30min)
    Client->>+API: API Request + Access token
    API->>API: Validate token
    API->>-Client: Response
    Client->>+API: Refresh token request
    API->>Redis: Validate refresh token
    API->>-Client: New token pair
```

#### RBAC (Role-Based Access Control)
```yaml
# rbac.yml
roles:
  ADMIN: [MANAGER]
  MANAGER: [USER]
  USER: [GUEST]

permissions:
  execute_plugin:
    roles: [ADMIN, MANAGER]
    conditions:
      payload_size: {max: 1048576}
```

#### Security Headers
```python
security_headers = {
    'Strict-Transport-Security': 'max-age=31536000; includeSubDomains',
    'X-Content-Type-Options': 'nosniff',
    'X-Frame-Options': 'DENY',
    'X-XSS-Protection': '1; mode=block',
    'Referrer-Policy': 'strict-origin-when-cross-origin'
}
```

### Rate Limiting
```python
# Different limits for different endpoints
limits = {
    "/token": "5/minute",      # Login attempts
    "/agents/*/action": "10/minute",  # Agent actions
    "/api/*": "100/minute"     # General API
}
```

### Audit Trail
Every significant action is cryptographically logged:
```python
audit_entry = {
    "id": "uuid",
    "actor": "username",
    "action": "execute",
    "target": "agent:id",
    "timestamp": 1640995200.0,
    "hash": "sha256:...",
    "prev_hash": "sha256:..."  # Chain link
}
```

---

## 📈 Monitoring & Observability

### Metrics Collection

#### Prometheus Metrics
```python
# HTTP request metrics
http_request_duration = Histogram(
    'http_request_duration_seconds',
    'HTTP request latency',
    ['method', 'endpoint', 'status_code']
)

# Business metrics
agent_actions_total = Counter(
    'agent_actions_total',
    'Total agent actions',
    ['agent_id', 'action', 'status']
)

# Anomaly detection metrics
anomaly_detections_total = Counter(
    'anomaly_detections_total',
    'Anomaly detections',
    ['metric', 'is_anomaly']
)
```

#### Structured Logging
```python
# Contextual logging with trace IDs
logger.info(
    "plugin_executed",
    plugin_name=name,
    duration_ms=duration,
    success=result.success,
    trace_id=trace_id,
    request_id=request_id
)
```

### Health Checks

#### Service Health
```http
GET /health
```

Response:
```json
{
  "status": "healthy",
  "timestamp": "2024-01-01T12:00:00Z",
  "version": "2.0.0",
  "components": {
    "database": "healthy",
    "redis": "healthy",
    "plugins": "healthy"
  }
}
```

#### Resilience Health
```http
GET /resilience/health
```

#### Plugin Health
Each plugin has health monitoring:
```python
health_metrics = {
    "success_rate": 0.98,
    "avg_duration_ms": 150.5,
    "error_rate": 0.02,
    "consecutive_failures": 0,
    "state": "HEALTHY"
}
```

### Grafana Dashboard
```json
{
  "dashboard": {
    "title": "Agent Dashboard Metrics",
    "panels": [
      {
        "title": "HTTP Request Rate",
        "type": "graph",
        "targets": [
          {"expr": "rate(http_requests_total[5m])"}
        ]
      },
      {
        "title": "Anomaly Detection Rate",
        "type": "stat",
        "targets": [
          {"expr": "rate(anomaly_detections_total[5m])"}
        ]
      }
    ]
  }
}
```

---

## 🔄 Resilience Patterns

### Circuit Breaker Implementation
```python
# Automatic failure protection
@circuit_breaker(
    failure_threshold=5,
    recovery_timeout=60.0,
    monitor_interval=10.0
)
def external_api_call():
    # External service call
    response = requests.get("https://api.external.com/data")
    return response.json()

# States: CLOSED -> OPEN -> HALF_OPEN -> CLOSED
```

### Retry Patterns
```python
# Exponential backoff with jitter
@retry_on_exception(RetryConfig(
    max_attempts=3,
    base_delay=1.0,
    max_delay=60.0,
    exponential_base=2.0,
    jitter=True,
    exceptions=(requests.RequestException,)
))
async def resilient_operation():
    # Operation that may fail
    pass
```

### Health Monitoring
```python
def database_health_check():
    try:
        db.execute("SELECT 1")
        return HealthCheckResult(
            status=HealthStatus.HEALTHY,
            message="Database responsive",
            details={"connection_pool": "5/10"}
        )
    except Exception as e:
        return HealthCheckResult(
            status=HealthStatus.UNHEALTHY,
            message=f"Database error: {e}"
        )
```

---

## 🧪 Testing Strategy

### Test Pyramid
```
             E2E Tests (Playwright)
           ┌─────────────────────┐
          ┌─────────────────────────┐
         │  Integration Tests      │
        ├─────────────────────────────┤
       │     Unit Tests (Pytest)     │
      └─────────────────────────────────┘
```

### Unit Tests
```python
# pytest with fixtures
@pytest.fixture
def mock_redis():
    with patch('redis.Redis') as mock:
        yield mock

def test_anomaly_detection(mock_redis):
    engine = AnomalyEngine()
    result = await engine.process_metric({
        "metric": "cpu_usage",
        "value": 95.0
    })
    assert result.is_anomaly == True
```

### Integration Tests
```python
# Full API testing
def test_authentication_flow():
    # Test login
    response = client.post("/token", data={
        "username": "admin",
        "password": "admin123"
    })
    assert response.status_code == 200
    token = response.json()["access_token"]
    
    # Test protected endpoint
    response = client.get("/agents", headers={
        "Authorization": f"Bearer {token}"
    })
    assert response.status_code == 200
```

### Load Testing
```python
# Locust performance tests
class UserBehavior(HttpUser):
    wait_time = between(1, 3)
    
    def on_start(self):
        # Login once
        response = self.client.post("/token", data={
            "username": "user",
            "password": "user123"
        })
        self.token = response.json()["access_token"]
    
    @task(3)
    def view_agents(self):
        self.client.get("/agents", headers={
            "Authorization": f"Bearer {self.token}"
        })
    
    @task(1)
    def execute_action(self):
        self.client.post("/agents/agent1/action", 
                        json={"action": "status"},
                        headers={"Authorization": f"Bearer {self.token}"})
```

### Security Testing
```python
# Security test suite
class SecurityTests:
    def test_jwt_algorithm_confusion(self):
        # Test algorithm switching attacks
        pass
    
    def test_rate_limiting(self):
        # Verify rate limits are enforced
        pass
    
    def test_sql_injection(self):
        # Test parameterized queries
        pass
    
    def test_xss_protection(self):
        # Test input sanitization
        pass
```

### Test Execution
```bash
# Run all tests
make test

# Specific test suites
make test-unit
make test-integration
make test-security
make test-load

# Coverage report
make coverage
```

---

## 🚢 Deployment Guide

### Docker Deployment

#### Multi-stage Dockerfile
```dockerfile
# Backend Dockerfile
FROM python:3.11-slim as base
WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

FROM base as production
COPY . .
EXPOSE 8000
CMD ["uvicorn", "main:app", "--host", "0.0.0.0", "--port", "8000"]
```

#### Docker Compose
```yaml
version: '3.8'
services:
  backend:
    build: ./dashboard/backend
    ports:
      - "8000:8000"
    environment:
      - REDIS_URL=redis://redis:6379
      - DATABASE_URL=postgresql://user:pass@postgres:5432/agents
    depends_on:
      - redis
      - postgres
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8000/health"]
      interval: 30s
      timeout: 10s
      retries: 3

  frontend:
    build: ./dashboard/frontend
    ports:
      - "3000:3000"
    depends_on:
      - backend
    environment:
      - REACT_APP_API_URL=http://localhost:8000

  redis:
    image: redis:7-alpine
    command: redis-server --appendonly yes
    volumes:
      - redis_data:/data
    healthcheck:
      test: ["CMD", "redis-cli", "ping"]

  postgres:
    image: postgres:15
    environment:
      POSTGRES_DB: agents
      POSTGRES_USER: admin
      POSTGRES_PASSWORD: secure_password
    volumes:
      - postgres_data:/var/lib/postgresql/data
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U admin"]

volumes:
  redis_data:
  postgres_data:
```

### Kubernetes Deployment

#### Helm Chart Structure
```
helm/
├── Chart.yaml
├── values.yaml
├── templates/
│   ├── deployment.yaml
│   ├── service.yaml
│   ├── ingress.yaml
│   ├── configmap.yaml
│   └── secret.yaml
```

#### Deployment Manifest
```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: agent-dashboard-backend
spec:
  replicas: 3
  selector:
    matchLabels:
      app: agent-dashboard-backend
  template:
    metadata:
      labels:
        app: agent-dashboard-backend
    spec:
      containers:
      - name: backend
        image: agent-dashboard:latest
        ports:
        - containerPort: 8000
        env:
        - name: REDIS_URL
          valueFrom:
            configMapKeyRef:
              name: app-config
              key: redis-url
        - name: JWT_SECRET
          valueFrom:
            secretKeyRef:
              name: app-secrets
              key: jwt-secret
        resources:
          requests:
            memory: "256Mi"
            cpu: "250m"
          limits:
            memory: "512Mi"
            cpu: "500m"
        livenessProbe:
          httpGet:
            path: /health
            port: 8000
          initialDelaySeconds: 30
          periodSeconds: 10
        readinessProbe:
          httpGet:
            path: /health
            port: 8000
          initialDelaySeconds: 5
          periodSeconds: 5
```

### CI/CD Pipeline

#### GitHub Actions
```yaml
name: CI/CD Pipeline
on:
  push:
    branches: [main]
  pull_request:
    branches: [main]

jobs:
  test:
    runs-on: ubuntu-latest
    strategy:
      matrix:
        python-version: ['3.10', '3.11', '3.12']
    steps:
    - uses: actions/checkout@v4
    - name: Set up Python
      uses: actions/setup-python@v5
      with:
        python-version: ${{ matrix.python-version }}
    - name: Install dependencies
      run: |
        pip install -r requirements.txt
        pip install -e .
    - name: Run tests
      run: |
        pytest tests/ --cov=. --cov-report=xml
    - name: Upload coverage
      uses: codecov/codecov-action@v3

  security-scan:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v4
    - name: Run security scan
      uses: pypa/gh-action-pip-audit@v1.0.8
    - name: Run Trivy scan
      uses: aquasecurity/trivy-action@master
      with:
        scan-type: 'fs'
        scan-ref: '.'

  build-and-deploy:
    needs: [test, security-scan]
    runs-on: ubuntu-latest
    if: github.ref == 'refs/heads/main'
    steps:
    - uses: actions/checkout@v4
    - name: Build Docker image
      run: |
        docker build -t agent-dashboard:${{ github.sha }} .
    - name: Deploy to staging
      run: |
        kubectl apply -f k8s/staging/
    - name: Run E2E tests
      run: |
        npm run test:e2e
    - name: Deploy to production
      if: success()
      run: |
        kubectl apply -f k8s/production/
```

### Environment Configuration

#### Production Environment Variables
```bash
# Security
JWT_SECRET=<strong-random-secret>
ADMIN_PASSWORD_HASH=<bcrypt-hash>

# Database
DATABASE_URL=postgresql://user:pass@postgres:5432/agents
REDIS_URL=redis://redis:6379/0

# Monitoring
PROMETHEUS_ENABLED=true
GRAFANA_URL=https://grafana.example.com

# External Services
ALERT_WEBHOOK_URL=https://alerts.example.com/webhook
```

#### Secrets Management
```yaml
# Kubernetes Secret
apiVersion: v1
kind: Secret
metadata:
  name: app-secrets
type: Opaque
data:
  jwt-secret: <base64-encoded-secret>
  db-password: <base64-encoded-password>
```

---

## 🔍 Debugging & Troubleshooting

### Common Issues

#### Backend Won't Start
```bash
# Check dependencies
pip list | grep -E "(fastapi|uvicorn|redis)"

# Verify Redis connection
redis-cli ping

# Check port conflicts
netstat -tulpn | grep :8000

# View logs
tail -f logs/app.log
```

#### Frontend Build Errors
```bash
# Clear cache
npm run clean
rm -rf node_modules package-lock.json
npm install

# Check Node version
node --version  # Should be 18+

# TypeScript errors
npm run type-check
```

#### Authentication Issues
```bash
# Verify JWT secret
echo $JWT_SECRET

# Check token expiration
# Decode JWT at jwt.io

# Verify Redis connection
redis-cli get "session:username"
```

#### Plugin Execution Failures
```bash
# Check plugin syntax
python -m py_compile plugins/my_plugin.py

# Verify imports
python -c "import json, datetime, math"

# Check resource limits
docker stats  # Monitor container resources
```

### Debugging Tools

#### Backend Debugging
```python
# Enable debug mode
app = FastAPI(debug=True)

# Add request logging
@app.middleware("http")
async def log_requests(request: Request, call_next):
    start_time = time.time()
    response = await call_next(request)
    process_time = time.time() - start_time
    logger.info(f"{request.method} {request.url} - {response.status_code} - {process_time:.2f}s")
    return response

# Profile performance
import cProfile
cProfile.run('your_function()', 'profile.out')
```

#### Frontend Debugging
```typescript
// React DevTools
console.log('Component state:', state);

// Performance monitoring
performance.mark('component-render-start');
// Component logic
performance.mark('component-render-end');
performance.measure('component-render', 'component-render-start', 'component-render-end');

// Network debugging
const response = await fetch('/api/agents');
console.log('Response headers:', response.headers);
console.log('Response time:', response.headers.get('X-Response-Time'));
```

### Log Analysis

#### Structured Log Queries
```bash
# Filter by trace ID
jq '.trace_id == "abc123"' logs/app.log

# Find errors
jq 'select(.levelname == "ERROR")' logs/app.log

# Performance analysis
jq 'select(.duration_ms > 1000)' logs/app.log

# Plugin execution stats
jq 'select(.event == "plugin_executed") | {plugin: .plugin_name, duration: .duration_ms}' logs/app.log
```

### Performance Monitoring

#### Real-time Metrics
```bash
# System metrics
htop
iotop
nethogs

# Application metrics
curl http://localhost:8000/prometheus

# Database performance
redis-cli info stats
```

---

## 🛠️ Development Workflow

### Git Workflow

#### Branch Strategy
```
main
├── develop
│   ├── feature/auth-improvements
│   ├── feature/new-plugin-system
│   └── bugfix/memory-leak
├── release/v2.1.0
└── hotfix/security-patch
```

#### Commit Convention
```bash
# Format: <type>(<scope>): <subject>
feat(auth): add refresh token rotation
fix(plugin): resolve memory leak in sandbox
docs(api): update authentication endpoints
test(anomaly): add integration tests
chore(deps): update dependencies
```

### Code Quality

#### Pre-commit Hooks
```yaml
# .pre-commit-config.yaml
repos:
  - repo: https://github.com/psf/black
    rev: 23.0.0
    hooks:
      - id: black
  - repo: https://github.com/pycqa/isort
    rev: 5.12.0
    hooks:
      - id: isort
  - repo: https://github.com/pycqa/flake8
    rev: 6.0.0
    hooks:
      - id: flake8
  - repo: https://github.com/pre-commit/mirrors-mypy
    rev: v1.0.0
    hooks:
      - id: mypy
```

#### Code Review Checklist
- [ ] Code follows style guidelines
- [ ] Tests cover new functionality
- [ ] Documentation is updated
- [ ] Security considerations addressed
- [ ] Performance impact assessed
- [ ] Backward compatibility maintained

### Development Environment

#### VSCode Configuration
```json
{
  "python.defaultInterpreterPath": "./venv/bin/python",
  "python.linting.enabled": true,
  "python.linting.pylintEnabled": false,
  "python.linting.flake8Enabled": true,
  "python.formatting.provider": "black",
  "editor.formatOnSave": true,
  "files.associations": {
    "*.yml": "yaml"
  }
}
```

#### Development Scripts
```bash
# Start development environment
make dev

# Run tests with watch
make test-watch

# Code formatting
make format

# Security scan
make security-scan

# Generate documentation
make docs
```

### Release Process

#### Version Bumping
```bash
# Semantic versioning
bump2version patch  # 2.0.0 -> 2.0.1
bump2version minor  # 2.0.1 -> 2.1.0
bump2version major  # 2.1.0 -> 3.0.0
```

#### Release Checklist
1. [ ] Update CHANGELOG.md
2. [ ] Run full test suite
3. [ ] Update version numbers
4. [ ] Create release branch
5. [ ] Deploy to staging
6. [ ] Run integration tests
7. [ ] Create GitHub release
8. [ ] Deploy to production
9. [ ] Monitor metrics
10. [ ] Update documentation

### Contributing Guidelines

#### Getting Started
```bash
# Fork and clone repository
git clone https://github.com/your-username/agents.git
cd agents

# Create feature branch
git checkout -b feature/your-feature-name

# Make changes and commit
git add .
git commit -m "feat: add your feature"

# Push and create PR
git push origin feature/your-feature-name
```

#### Pull Request Template
```markdown
## Description
Brief description of changes

## Type of Change
- [ ] Bug fix
- [ ] New feature
- [ ] Breaking change
- [ ] Documentation update

## Testing
- [ ] Unit tests pass
- [ ] Integration tests pass
- [ ] Manual testing completed

## Checklist
- [ ] Code follows style guidelines
- [ ] Self-review completed
- [ ] Documentation updated
- [ ] Tests added for new functionality
```

---

## 📚 Additional Resources

### Documentation Links
- [FastAPI Documentation](https://fastapi.tiangolo.com/)
- [React Documentation](https://reactjs.org/docs/)
- [Redis Documentation](https://redis.io/documentation)
- [Material-UI Components](https://mui.com/components/)

### Monitoring & Observability
- [Prometheus Metrics](http://localhost:8000/prometheus)
- [Grafana Dashboard](http://localhost:3000)
- [Health Check Endpoint](http://localhost:8000/health)

### Development Tools
- [API Documentation](http://localhost:8000/docs)
- [Interactive API](http://localhost:8000/redoc)
- [Test Coverage Report](./htmlcov/index.html)

### Community
- [GitHub Issues](https://github.com/your-org/agents/issues)
- [Discussions](https://github.com/your-org/agents/discussions)
- [Contributing Guide](./CONTRIBUTING.md)

---

**Last Updated:** January 2024  
**Version:** 2.0.0  
**Maintainers:** Development Team

🎉 **Happy Coding!** 🎉 