# 🎓 **Elite AI Agent System - Complete User Guide**

## **🚀 Getting Started - Your First Steps**

### **Step 1: Quick System Startup**

#### **Option A: Windows Quick Start (Recommended)**
```powershell
# Navigate to your project directory
cd /path/to/your/agents/project

# Run the automated setup script
.\scripts\setup\quick-start.ps1
```

#### **Option B: Manual Docker Startup**
```bash
# Copy environment template
cp deploy/production.env .env

# Edit your environment settings
# nano .env  # or use your favorite editor

# Start all services
docker-compose up -d

# Check status
docker-compose ps
```

### **Step 2: Access Your System**
After startup, your system will be available at:
- 🎛️ **Main Dashboard**: http://localhost:8000
- 📊 **Grafana Monitoring**: http://localhost:3000 (admin/admin)
- 📈 **Prometheus Metrics**: http://localhost:9090
- 📚 **API Documentation**: http://localhost:8000/docs

---

## **🎛️ Using the Main Dashboard**

### **Dashboard Overview**
Your React/TypeScript dashboard provides:
- **Agent Status Monitoring** - Real-time health of all 5 agents
- **3D Visualization** - Interactive agent network graphs
- **Performance Analytics** - Charts, metrics, and trends
- **Control Panel** - Start/stop agents, run optimizations

### **Navigation Guide**

#### **1. Agent Overview Tab**
- **Purpose**: Monitor all 5 agents at once
- **Key Features**:
  - Agent status indicators (running/stopped/error)
  - Performance metrics (CPU, memory, response time)
  - Success rates and error counts

#### **2. 3D Visualization Tab**
- **Purpose**: Interactive visualization of agent relationships
- **Controls**:
  - Mouse: Rotate and zoom the 3D graph
  - Click nodes: View detailed agent information
  - Hover: Quick performance tooltips

#### **3. Analytics Tab**
- **Purpose**: Deep performance analysis
- **Features**:
  - Performance heatmaps
  - Time series charts
  - Anomaly detection results
  - Predictive forecasting

#### **4. Control Panel Tab**
- **Purpose**: Agent management and operations
- **Actions Available**:
  - Start/Stop individual agents
  - Run optimization routines
  - Update agent configurations
  - Create backups

---

## **🤖 Working with Your AI Agents**

### **Understanding Your Agents**
You have 5 sophisticated AI agents (agent_0 through agent_4), each with:
- **1M+ training episodes** per agent
- **Consistent performance profiles** (99.7% similarity)
- **Population-based training** capabilities
- **Tournament competition** features

### **Basic Agent Operations**

#### **1. Check Agent Status**
```bash
# Via API
curl http://localhost:8000/agents/status

# Via Dashboard
# Go to Agent Overview tab -> View status indicators
```

#### **2. Start/Stop Agents**
```bash
# Start specific agent
curl -X POST http://localhost:8000/agents/agent_0/start

# Stop specific agent
curl -X POST http://localhost:8000/agents/agent_0/stop

# Or use the Dashboard Control Panel
```

#### **3. View Agent Metrics**
```bash
# Get detailed metrics
curl http://localhost:8000/agents/agent_0/metrics

# View in dashboard - Analytics tab
```

### **Advanced Agent Operations**

#### **1. Run Agent Competitions**
```python
# Using Python API
from src.agents.competition import TournamentManager
from src.agents.evolution import Agent, Env

# Create tournament
tournament = TournamentManager()

# Register agents
tournament.register_agent("agent_0")
tournament.register_agent("agent_1")

# Run competition
match = tournament.run_match(agent1, agent2, env, "agent_0", "agent_1")
print(f"Winner: {match.result}")
```

#### **2. Population-Based Training**
```python
from src.agents.pbt.agent import AgentConfig
from src.agents.pbt.trainer import EnhancedTrainer

# Create agent configuration
config = AgentConfig.from_baseline_analysis(agent_id=0)

# Initialize trainer
trainer = EnhancedTrainer(env, config)

# Start training
trainer.train(episodes=1000)
```

---

## **📊 Analytics and Monitoring**

### **1. Performance Monitoring**

#### **View Real-time Metrics**
```bash
# System health
curl http://localhost:8000/health

# Agent performance
curl http://localhost:8000/analytics/performance

# Or use Grafana dashboard at http://localhost:3000
```

#### **Key Metrics to Watch**
- **Success Rate**: Target >15% (currently ~11.9%)
- **Zero Rate**: Target <8% (currently ~12%)
- **Response Time**: Sub-millisecond for most operations
- **Memory Usage**: Monitor for memory leaks
- **Error Rate**: Should be <1%

### **2. Advanced Analytics**

#### **Predictive Analysis**
```bash
# Get performance predictions
curl -X POST http://localhost:8000/analytics/predict \
  -H "Content-Type: application/json" \
  -d '{"agent_ids": ["agent_0", "agent_1"], "horizon": 30}'
```

#### **Anomaly Detection**
```bash
# Run anomaly detection
curl -X POST http://localhost:8000/analytics/anomalies \
  -H "Content-Type: application/json" \
  -d '{"window_hours": 24}'
```

#### **Pattern Recognition**
```bash
# Analyze behavioral patterns
curl -X POST http://localhost:8000/analytics/patterns \
  -H "Content-Type: application/json" \
  -d '{"agents": ["agent_0", "agent_1", "agent_2"]}'
```

---

## **🔧 Configuration and Customization**

### **1. Environment Configuration**
Edit your `.env` file to customize:
```env
# Core settings
ELITE_MODE=production          # or development
LOG_LEVEL=INFO                 # DEBUG, INFO, WARNING, ERROR
WORKER_PROCESSES=4             # Number of worker processes

# Database settings
DATABASE_URL=postgresql://user:pass@localhost:5432/db
REDIS_URL=redis://localhost:6379/0

# Security
JWT_SECRET_KEY=your-secret-key
CORS_ORIGINS=http://localhost:3000

# Performance
MAX_CONNECTIONS=1000
CACHE_TTL=3600
```

### **2. Agent Configuration**
Customize agent behavior:
```python
from src.agents.pbt.agent import AgentConfig

# Create custom configuration
config = AgentConfig(
    epsilon=0.25,              # Exploration rate
    lr=0.001,                  # Learning rate
    discount=0.95,             # Discount factor
    reward_shaping=1.2,        # Reward shaping scale
    partial_reward=0.15,       # Partial progress reward
    near_success_reward=0.25,  # Near-success reward
    entropy_bonus=0.02         # Exploration bonus
)

# Save configuration
config.to_json(Path("configs/my_agent_config.json"))
```

### **3. Monitoring Configuration**
Customize monitoring in `config/development.json`:
```json
{
  "monitoring": {
    "enabled": true,
    "interval": 30,
    "retention_days": 30,
    "alerts": {
      "error_threshold": 0.05,
      "response_time_threshold": 1000,
      "memory_threshold": 0.8
    }
  }
}
```

---

## **🧪 Running Experiments**

### **1. Basic Training Experiment**
```python
# Example: Train agent with different exploration rates
from src.agents.pbt.scheduler import PBTScheduler

# Create scheduler
scheduler = PBTScheduler(
    population_size=5,
    num_generations=100,
    tournament_size=3
)

# Run experiment
results = scheduler.run_experiment(
    env_name="your_environment",
    max_episodes=10000
)

# View results
print(f"Best agent: {results['best_agent']}")
print(f"Final performance: {results['final_performance']}")
```

### **2. Competition Experiment**
```python
# Run tournament between agents
from src.agents.competition import CompetitionFramework

framework = CompetitionFramework()

# Register agents
framework.register_agent("agent_0", agent_0)
framework.register_agent("agent_1", agent_1)

# Run tournament
results = framework.run_tournament(num_rounds=10)

# View leaderboard
leaderboard = framework.tournament_manager.get_leaderboard()
for agent in leaderboard:
    print(f"{agent.agent_id}: Rating {agent.rating:.1f}, Win Rate {agent.win_rate:.2%}")
```

### **3. Data Analysis Experiment**
```python
# Analyze your 5M episode dataset
import pandas as pd
from scripts.analyze_agent_dump import read_agent_data, analyze_all_agents

# Load data
df = read_agent_data("data/")

# Run comprehensive analysis
analyze_all_agents("data/")

# Custom analysis
print(f"Total episodes: {len(df)}")
print(f"Success rate: {df['success'].mean():.2%}")
print(f"Zero rate: {(df['value'] == 0).mean():.2%}")
```

---

## **🔍 Troubleshooting Guide**

### **Common Issues & Solutions**

#### **1. Services Won't Start**
```bash
# Check Docker status
docker-compose ps

# View logs
docker-compose logs

# Restart services
docker-compose restart

# Nuclear option - full restart
docker-compose down
docker-compose up -d
```

#### **2. Database Connection Issues**
```bash
# Check database is running
docker-compose exec postgres pg_isready

# Check connection string in .env
# Verify DATABASE_URL matches your setup
```

#### **3. Agent Performance Issues**
```bash
# Check agent logs
docker-compose logs app

# View system resources
docker stats

# Check for memory leaks
curl http://localhost:8000/health
```

#### **4. Dashboard Not Loading**
```bash
# Check if frontend is built
ls dashboard/frontend/dist/

# Rebuild frontend if needed
cd dashboard/frontend
npm install
npm run build
```

### **Performance Optimization**

#### **1. System Performance**
```env
# In .env file
WORKER_PROCESSES=8        # Increase for more CPU cores
MAX_CONNECTIONS=2000      # Increase for high load
CACHE_TTL=7200           # Longer caching
```

#### **2. Agent Performance**
```python
# Optimize agent configuration
config = AgentConfig(
    epsilon=0.20,            # Balanced exploration
    lr=0.0005,              # Conservative learning rate
    reward_shaping=1.5,      # Strong reward shaping
    entropy_bonus=0.03       # Encourage diversity
)
```

---

## **🚀 Advanced Features**

### **1. Blockchain Integration**
```python
# Connect to blockchain networks
from dashboard.backend.blockchain.blockchain_api import BlockchainAPI

api = BlockchainAPI()

# Get account balance
balance = await api.get_balance("0x123...")

# Execute smart contract
result = await api.call_contract(
    contract_address="0x456...",
    function_name="getValue",
    parameters=[]
)
```

### **2. Plugin System**
```python
# Create custom plugin
from dashboard.backend.plugins.base import BasePlugin

class MyPlugin(BasePlugin):
    def execute(self, params):
        # Your custom logic here
        return {"status": "success", "data": result}

# Register plugin
plugin_manager.register_plugin("my_plugin", MyPlugin())
```

### **3. Custom Analytics**
```python
# Create custom analytics
from dashboard.backend.analytics.base import BaseAnalyzer

class CustomAnalyzer(BaseAnalyzer):
    def analyze(self, data):
        # Your analysis logic
        return insights
```

---

## **📈 Production Deployment**

### **1. Cloud Deployment**
```bash
# Deploy to AWS/GCP/Azure
kubectl apply -f k8s/

# Or use Helm
helm install elite-ai helm-chart/scriptsynthcore/
```

### **2. Scaling Configuration**
```yaml
# In docker-compose.yml
services:
  app:
    replicas: 4
    resources:
      limits:
        cpus: '2'
        memory: 4G
```

### **3. Production Monitoring**
```bash
# Set up monitoring stack
docker-compose -f docker-compose.prod.yml up -d

# Access production dashboards
# Grafana: http://your-domain:3000
# Prometheus: http://your-domain:9090
```

---

## **🎯 Best Practices**

### **1. Regular Maintenance**
- **Daily**: Check system health and logs
- **Weekly**: Review performance metrics and optimize
- **Monthly**: Update dependencies and run security scans

### **2. Performance Monitoring**
- Monitor success rates (target >15%)
- Watch for memory leaks
- Track response times (<1s)
- Alert on error rates (>1%)

### **3. Security**
- Regularly rotate JWT secrets
- Update dependencies monthly
- Monitor for suspicious activity
- Backup data regularly

---

## **🆘 Getting Help**

### **1. Built-in Help**
```bash
# API documentation
http://localhost:8000/docs

# Health check
curl http://localhost:8000/health

# System status
curl http://localhost:8000/status
```

### **2. Logs and Debugging**
```bash
# View all logs
docker-compose logs -f

# Specific service logs
docker-compose logs app
docker-compose logs postgres
docker-compose logs redis
```

### **3. Community Resources**
- Check the comprehensive documentation in `docs/`
- Review examples in `examples/`
- Read the troubleshooting guide in `TROUBLESHOOTING.md`

---

**🎉 Congratulations! You now know how to use your Elite AI Agent System!**

Your system is incredibly sophisticated - take time to explore all its features. Start with basic agent monitoring, then move to advanced analytics and competitions. The possibilities are endless!

**Happy experimenting!** 🚀 