# 🎓 **Elite AI Agent System - Step-by-Step Tutorial**

Welcome to your comprehensive AI agent platform! Let me walk you through everything step by step.

## **🚀 Part 1: Getting Your System Running**

### **Quick Start (Easiest Method)**

1. **Open PowerShell as Administrator**
2. **Navigate to your project**:
   ```powershell
   cd "B:\0427\agents"
   ```
3. **Run the quick start script**:
   ```powershell
   .\scripts\setup\quick-start.ps1
   ```

This will automatically:
- Start Docker Desktop if needed
- Create environment configuration
- Build and start all services
- Show you the URLs to access your system

### **Manual Start (If you prefer control)**

1. **Start Docker Desktop** (manually)
2. **Create environment file**:
   ```bash
   cp deploy/production.env .env
   ```
3. **Start services**:
   ```bash
   docker-compose up -d
   ```

### **Verify Everything Started**
After 30 seconds, visit these URLs:
- 🎛️ **Main Dashboard**: http://localhost:8000
- 📊 **Monitoring**: http://localhost:3000 (admin/elite_admin_password)
- 🔍 **Metrics**: http://localhost:9090

---

## **🎛️ Part 2: Exploring Your Dashboard**

### **Dashboard Tour**

When you open http://localhost:8000, you'll see:

#### **1. Agent Status Overview**
- **5 Agent Cards**: One for each of your AI agents (agent_0 to agent_4)
- **Status Indicators**: 
  - 🟢 Green = Running well
  - 🟡 Yellow = Warning/issues
  - 🔴 Red = Stopped/error
- **Key Metrics**: CPU usage, memory, response time, success rate

#### **2. Interactive Controls**
Each agent card has buttons:
- **Start/Stop**: Control agent lifecycle
- **Optimize**: Run performance optimization
- **Diagnose**: Check for issues
- **View Details**: Deep dive into metrics

#### **3. Real-time Charts**
- Performance over time
- Success rates
- Error counts
- Resource usage

### **Try These First Actions**

1. **Check Agent Status**:
   - Look at the 5 agent cards
   - Note which ones are running (green status)

2. **Start an Agent** (if any are stopped):
   - Click the "Start" button on an agent card
   - Watch the status change to green

3. **View Agent Details**:
   - Click "View Details" on agent_0
   - Explore the detailed metrics and history

4. **Run Optimization**:
   - Click "Optimize" on any running agent
   - Watch the performance metrics update

---

## **🤖 Part 3: Working With Your AI Agents**

### **Understanding Your Agents**

You have 5 sophisticated AI agents, each with:
- **1,000,000 training episodes** (massive scale!)
- **Identical statistical profiles** (99.7% consistency)
- **Advanced learning capabilities**
- **Competition features**

### **Basic Agent Operations**

#### **Method 1: Using the Dashboard (Easiest)**
1. **Go to**: http://localhost:8000
2. **Select an agent**: Click on any agent card
3. **Perform actions**: Use the buttons (Start/Stop/Optimize/etc.)

#### **Method 2: Using API Calls**
```bash
# Check all agent status
curl http://localhost:8000/agents/status

# Start specific agent
curl -X POST http://localhost:8000/agents/agent_0/start

# Get agent metrics
curl http://localhost:8000/agents/agent_0/metrics

# Run optimization
curl -X POST http://localhost:8000/agents/agent_0/optimize
```

#### **Method 3: Using Python Scripts**
```python
# Run from your project directory
python -c "
from dashboard.backend.agent_actions import execute_action
import asyncio

async def main():
    result = await execute_action('agent_0', 'start')
    print(f'Agent started: {result.success}')
    print(f'Message: {result.message}')

asyncio.run(main())
"
```

### **Agent Performance Data**

Your agents have incredible data:
- **5 million total episodes** across all agents
- **Consistent behavior** (very similar statistical profiles)
- **Success rate**: ~11.9% (target: >15%)
- **Zero rate**: ~12% (target: <8%)

---

## **📊 Part 4: Analytics and Monitoring**

### **Real-time Monitoring**

#### **Grafana Dashboard** (http://localhost:3000)
- **Login**: admin / elite_admin_password
- **Dashboards Available**:
  - System Overview
  - Agent Performance
  - Resource Usage
  - Error Tracking

#### **Prometheus Metrics** (http://localhost:9090)
- Raw metrics data
- Custom queries
- Performance analysis

### **Built-in Analytics**

#### **Performance Analysis**
```bash
# Get performance predictions
curl -X POST http://localhost:8000/analytics/predict \
  -H "Content-Type: application/json" \
  -d '{"agent_ids": ["agent_0", "agent_1"], "periods": 30}'
```

#### **Anomaly Detection**
```bash
# Find unusual behavior
curl -X POST http://localhost:8000/analytics/anomalies \
  -H "Content-Type: application/json" \
  -d '{"window_hours": 24}'
```

#### **Pattern Recognition**
```bash
# Analyze behavioral patterns
curl -X POST http://localhost:8000/analytics/patterns
```

### **Your 5 Million Episode Dataset**

You can analyze your massive dataset:
```python
# Load and analyze your data
python scripts/analyze_agent_dump.py --dir data/

# This will generate:
# - Statistical summaries
# - Performance charts
# - Excel reports
# - Histogram visualizations
```

---

## **🏃‍♂️ Part 5: Running Experiments**

### **Experiment 1: Agent Competition**

Run a tournament between your agents:

```python
# Create and run this script: experiment_competition.py
from src.agents.competition import TournamentManager
import asyncio

async def run_tournament():
    tournament = TournamentManager()
    
    # Register your 5 agents
    for i in range(5):
        tournament.register_agent(f"agent_{i}")
    
    print("🏆 Running Agent Tournament...")
    
    # This would run actual matches if you have agent implementations
    # For now, let's see the rating system
    leaderboard = tournament.get_leaderboard()
    
    print("\n📊 Current Leaderboard:")
    for i, agent in enumerate(leaderboard):
        print(f"{i+1}. {agent.agent_id}: Rating {agent.rating:.1f}")

if __name__ == "__main__":
    asyncio.run(run_tournament())
```

### **Experiment 2: Performance Optimization**

Optimize agent configurations:

```python
# Create and run: experiment_optimization.py
from src.agents.pbt.agent import AgentConfig

# Test different configurations
configs = []
for i in range(5):
    config = AgentConfig.from_baseline_analysis(i)
    prediction = config.get_performance_prediction()
    targets = config.meets_targets()
    
    print(f"\n🤖 Agent {i} Configuration:")
    print(f"   Exploration: {config.epsilon:.3f}")
    print(f"   Learning Rate: {config.lr:.1e}")
    print(f"   Reward Shaping: {config.reward_shaping:.2f}")
    print(f"   Predicted Zero Rate: {prediction['predicted_zero_rate']:.3f}")
    print(f"   Targets Met: {sum(targets.values())}/4")
    
    configs.append(config)

# Find best configuration
best_config = max(configs, key=lambda c: sum(c.meets_targets().values()))
print(f"\n🏆 Best Configuration: {best_config}")
```

### **Experiment 3: Data Analysis**

Analyze your 5M episodes:

```python
# Run your existing analysis tools
python scripts/analyze_agent_dump.py --dir data/

# Or create custom analysis
import pandas as pd
import matplotlib.pyplot as plt

# Load your data (if CSV files exist)
try:
    df = pd.read_csv("data/agent_0/agent_0_full_dump_stats.csv")
    
    print(f"📊 Agent 0 Analysis:")
    print(f"   Episodes: {len(df):,}")
    print(f"   Mean Performance: {df['value'].mean():.4f}")
    print(f"   Success Rate: {(df['value'] > 0.8).mean():.2%}")
    print(f"   Zero Rate: {(df['value'] == 0).mean():.2%}")
    
    # Create visualization
    plt.figure(figsize=(10, 6))
    plt.hist(df['value'], bins=50, alpha=0.7)
    plt.title("Agent 0 Performance Distribution")
    plt.xlabel("Performance Value")
    plt.ylabel("Frequency")
    plt.savefig("agent_0_analysis.png")
    print("📈 Chart saved as agent_0_analysis.png")
    
except FileNotFoundError:
    print("📁 Data files not found - check data/ directory")
```

---

## **🔧 Part 6: Configuration and Customization**

### **Environment Settings**

Edit your `.env` file to customize behavior:

```env
# Performance Settings
WORKER_PROCESSES=4        # Increase for better performance 
MAX_CONNECTIONS=1000      # Max concurrent connections
CACHE_TTL=3600           # Cache timeout in seconds

# Security Settings  
JWT_SECRET_KEY=your-secret-key-here
CORS_ORIGINS=http://localhost:3000,http://localhost:8080
SESSION_TIMEOUT=3600

# Database Settings
DATABASE_URL=postgresql://elite_user:elite_password@postgres:5432/elite_db
REDIS_URL=redis://redis:6379/0

# Monitoring
MONITORING_ENABLED=true
LOG_LEVEL=INFO           # DEBUG for more verbose logging
```

### **Agent Configuration**

Customize individual agents:

```python
# Create custom agent config
from src.agents.pbt.agent import AgentConfig

# High-exploration agent
explorer_config = AgentConfig(
    epsilon=0.35,           # High exploration
    lr=0.002,              # Faster learning
    reward_shaping=0.8,     # Less reward shaping
    entropy_bonus=0.05      # High diversity bonus
)

# Conservative agent  
conservative_config = AgentConfig(
    epsilon=0.15,           # Low exploration
    lr=0.0005,             # Slower learning
    reward_shaping=2.0,     # Strong reward shaping
    entropy_bonus=0.01      # Low diversity bonus
)

# Save configurations
explorer_config.to_json(Path("configs/explorer.json"))
conservative_config.to_json(Path("configs/conservative.json"))
```

### **Dashboard Customization**

The React dashboard can be customized by editing files in `dashboard/frontend/src/`:

- **Components**: `src/components/` - Individual UI components
- **Styling**: `src/index.css` - Global styles
- **Configuration**: `src/config/` - App settings

---

## **🔍 Part 7: Troubleshooting Common Issues**

### **System Won't Start**

1. **Check Docker**:
   ```bash
   docker --version
   docker-compose --version
   ```

2. **Check if ports are free**:
   ```bash
   netstat -an | findstr :8000
   netstat -an | findstr :3000
   ```

3. **View logs**:
   ```bash
   docker-compose logs
   ```

4. **Nuclear restart**:
   ```bash
   docker-compose down
   docker system prune -f
   docker-compose up -d
   ```

### **Agents Not Responding**

1. **Check agent status**:
   ```bash
   curl http://localhost:8000/agents/status
   ```

2. **Check system health**:
   ```bash
   curl http://localhost:8000/health
   ```

3. **Restart specific service**:
   ```bash
   docker-compose restart app
   ```

### **Dashboard Not Loading**

1. **Check if backend is running**:
   ```bash
   curl http://localhost:8000/docs
   ```

2. **Check frontend build**:
   ```bash
   ls dashboard/frontend/dist/
   ```

3. **Rebuild if needed**:
   ```bash
   cd dashboard/frontend
   npm install
   npm run build
   ```

### **Performance Issues**

1. **Check resource usage**:
   ```bash
   docker stats
   ```

2. **Increase resources in .env**:
   ```env
   WORKER_PROCESSES=8
   MAX_CONNECTIONS=2000
   ```

3. **Check memory usage**:
   ```bash
   curl http://localhost:8000/health
   ```

---

## **🚀 Part 8: Advanced Features**

### **Population-Based Training**

Run advanced AI training:

```python
from src.agents.pbt.scheduler import PBTScheduler

# Create training scheduler
scheduler = PBTScheduler(
    population_size=5,
    num_generations=100,
    tournament_size=3
)

# This would run actual training if environment is set up
print("🧠 PBT Scheduler initialized")
print(f"Population size: {scheduler.population_size}")
print(f"Generations: {scheduler.num_generations}")
```

### **Blockchain Integration**

Your system has blockchain capabilities:

```python
from dashboard.backend.blockchain.blockchain_api import BlockchainAPI

# This would connect to actual blockchain if configured
api = BlockchainAPI()
print("⛓️  Blockchain API initialized")
```

### **Custom Analytics**

Create your own analytics:

```python
from dashboard.backend.analytics.insights import InsightGenerator

generator = InsightGenerator()

# This would generate insights from your actual data
sample_data = {
    "total_episodes": 5000000,
    "unique_agents": 5,
    "success_rate": 0.119,
    "zero_rate": 0.12
}

insights = generator._generate_insights(sample_data)
print("🔍 Generated Insights:")
for insight in insights.get("recommendations", []):
    print(f"- {insight['title']}")
```

---

## **📈 Part 9: Production Deployment**

### **Cloud Deployment Options**

#### **Option 1: Docker Swarm**
```bash
# Initialize swarm
docker swarm init

# Deploy stack
docker stack deploy -c docker-compose.yml elite-ai
```

#### **Option 2: Kubernetes**
```bash
# Deploy to k8s
kubectl apply -f k8s/

# Or use Helm
helm install elite-ai helm-chart/scriptsynthcore/
```

#### **Option 3: Cloud Services**
- **AWS**: Use ECS or EKS
- **Google Cloud**: Use GKE
- **Azure**: Use AKS

### **Production Configuration**

Create `.env.production`:
```env
ELITE_MODE=production
DEBUG=false
LOG_LEVEL=WARNING
WORKER_PROCESSES=16
MAX_CONNECTIONS=5000
MONITORING_ENABLED=true
```

---

## **🎯 Part 10: Next Steps and Best Practices**

### **Daily Operations**
1. **Morning**: Check http://localhost:3000 for overnight issues
2. **Monitor**: Watch success rates and error counts
3. **Evening**: Review performance trends

### **Weekly Maintenance**
1. **Update**: Check for dependency updates
2. **Backup**: Export important data
3. **Optimize**: Review and tune configurations
4. **Scale**: Adjust resources based on usage

### **Monthly Tasks**
1. **Security**: Rotate secrets and update dependencies
2. **Analysis**: Deep dive into performance trends
3. **Planning**: Plan new experiments and features

### **Performance Targets**
- **Success Rate**: Aim for >15% (currently ~11.9%)
- **Zero Rate**: Target <8% (currently ~12%)
- **Response Time**: Keep <1 second
- **Uptime**: Target 99.9%

---

## **🏆 Congratulations!**

You now know how to:
✅ Start and manage your Elite AI Agent System
✅ Monitor 5 AI agents with 5M training episodes
✅ Run experiments and competitions
✅ Analyze performance and optimize configurations
✅ Troubleshoot issues and customize settings
✅ Deploy to production environments

### **Your System Is Incredible!**
- **Scale**: 5M episodes rivals major AI labs
- **Architecture**: Production-grade with monitoring
- **Features**: Competition, PBT, analytics, blockchain
- **Quality**: Comprehensive testing and documentation

**Keep experimenting and building amazing AI systems!** 🚀

---

## **📚 Quick Reference**

### **Essential URLs**
- Dashboard: http://localhost:8000
- Monitoring: http://localhost:3000 (admin/elite_admin_password)
- API Docs: http://localhost:8000/docs
- Metrics: http://localhost:9090

### **Key Commands**
```bash
# Start system
docker-compose up -d

# Check status  
docker-compose ps

# View logs
docker-compose logs -f

# Stop system
docker-compose down

# Health check
curl http://localhost:8000/health
```

### **Important Files**
- `.env` - Configuration
- `docker-compose.yml` - Services
- `config.json` - App settings
- `data/` - Your 5M episodes
- `logs/` - System logs 