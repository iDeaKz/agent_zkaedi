# 🚀 Elite AI Agent System - Docker Deployment Guide

## Quick Start

### Prerequisites
1. **Docker Desktop** installed and running
2. **Docker Compose** (included with Docker Desktop)
3. **8GB+ RAM** recommended
4. **10GB+ free disk space**

### 1. Start Docker Desktop
Make sure Docker Desktop is running on your system.

### 2. Deploy the System

#### On Linux/macOS:
```bash
# Make deployment script executable
chmod +x deploy/docker-deploy.sh

# Deploy the system
./deploy/docker-deploy.sh
```

#### On Windows (PowerShell):
```powershell
# Run deployment script
.\deploy\docker-deploy.ps1
```

#### Manual Deployment:
```bash
# Create environment file
cp deploy/production.env .env

# Build and start services
docker-compose build
docker-compose up -d

# Check status
docker-compose ps
```

## 🌐 Service URLs

Once deployed, access your services at:

| Service | URL | Credentials |
|---------|-----|-------------|
| 🎛️ **Main Dashboard** | http://localhost:8000 | - |
| 📊 **Grafana** | http://localhost:3000 | admin/elite_admin_password |
| 📈 **Prometheus** | http://localhost:9090 | - |
| 🗄️ **PostgreSQL** | localhost:5432 | elite_user/elite_password |
| 🔴 **Redis** | localhost:6379 | - |
| 🌐 **Load Balancer** | http://localhost:8080 | - |

## 📊 System Architecture

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Load Balancer │    │  Elite AI API   │    │   Monitoring    │
│     (Nginx)     │◄──►│   (FastAPI)     │◄──►│  (Prometheus)   │
└─────────────────┘    └─────────────────┘    └─────────────────┘
                              │                         │
                              ▼                         ▼
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   PostgreSQL    │    │      Redis      │    │     Grafana     │
│   (Database)    │    │     (Cache)     │    │  (Dashboards)   │
└─────────────────┘    └─────────────────┘    └─────────────────┘
```

## 🔧 Configuration

### Environment Variables

Key configuration options in `.env`:

```bash
# Security
JWT_SECRET_KEY=your-secret-key
POSTGRES_PASSWORD=your-db-password
REDIS_PASSWORD=your-redis-password

# Performance
WORKER_PROCESSES=4
MAX_CONNECTIONS=1000

# Features
MONITORING_ENABLED=true
LOG_LEVEL=INFO
```

### Resource Limits

Default resource allocation:
- **CPU**: 2 cores per service
- **Memory**: 1GB per service
- **Storage**: 10GB for data persistence

## 🛠️ Management Commands

### Health Checks
```bash
# Check all services
./deploy/docker-deploy.sh health

# Check specific service
docker-compose ps elite-api
```

### Logs
```bash
# View all logs
./deploy/docker-deploy.sh logs

# View specific service logs
docker-compose logs -f elite-api
```

### Backup & Restore
```bash
# Create backup
./deploy/docker-deploy.sh backup

# Restore from backup
docker-compose exec postgres psql -U elite_user -d elite_db < backup.sql
```

### Scaling
```bash
# Scale API service
docker-compose up -d --scale elite-api=3

# Scale with load balancer
docker-compose up -d --scale elite-api=3 --scale nginx=2
```

## 🔍 Monitoring & Observability

### Health Endpoints
- **System Health**: http://localhost:8000/health
- **Detailed Status**: http://localhost:8000/status
- **Metrics**: http://localhost:8000/metrics

### Grafana Dashboards
Pre-configured dashboards available:
1. **System Overview** - Overall system health
2. **Agent Performance** - AI agent metrics
3. **Infrastructure** - Resource utilization
4. **Error Analysis** - Error tracking and patterns

### Prometheus Metrics
Key metrics collected:
- `elite_system_uptime_seconds`
- `elite_services_healthy_total`
- `elite_circuit_breaker_risk_level`
- `elite_agent_performance_score`

## 🚨 Troubleshooting

### Common Issues

#### 1. Port Conflicts
```bash
# Check port usage
netstat -tulpn | grep :8000

# Use different ports
docker-compose -f docker-compose.override.yml up -d
```

#### 2. Memory Issues
```bash
# Check memory usage
docker stats

# Increase Docker memory limit in Docker Desktop settings
```

#### 3. Database Connection Issues
```bash
# Check database logs
docker-compose logs postgres

# Reset database
docker-compose down -v
docker-compose up -d
```

#### 4. Service Not Starting
```bash
# Check service status
docker-compose ps

# View detailed logs
docker-compose logs service-name

# Restart specific service
docker-compose restart service-name
```

### Performance Tuning

#### Database Optimization
```sql
-- Connect to database
docker-compose exec postgres psql -U elite_user -d elite_db

-- Check performance
SELECT * FROM pg_stat_activity;
```

#### Redis Optimization
```bash
# Connect to Redis
docker-compose exec redis redis-cli

# Check memory usage
INFO memory
```

## 🔒 Security

### Production Security Checklist
- [ ] Change default passwords
- [ ] Enable SSL/TLS certificates
- [ ] Configure firewall rules
- [ ] Set up log rotation
- [ ] Enable security scanning
- [ ] Configure backup encryption

### SSL Configuration
```bash
# Generate SSL certificates
openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
  -keyout docker/nginx/ssl/nginx.key \
  -out docker/nginx/ssl/nginx.crt
```

## 📈 Scaling for Production

### Horizontal Scaling
```yaml
# docker-compose.prod.yml
services:
  elite-api:
    deploy:
      replicas: 3
      resources:
        limits:
          cpus: '2'
          memory: 2G
```

### Load Balancing
```nginx
# nginx.conf
upstream elite_backend {
    server elite-api:8000;
    server elite-api-2:8000;
    server elite-api-3:8000;
}
```

## 🎯 Next Steps

1. **Monitor Performance** - Check Grafana dashboards
2. **Customize Configuration** - Adjust settings for your use case
3. **Scale Services** - Add more replicas as needed
4. **Set Up Alerts** - Configure monitoring alerts
5. **Backup Strategy** - Implement regular backups

## 📞 Support

For issues and questions:
- Check the troubleshooting section above
- Review Docker logs: `docker-compose logs`
- Monitor system health: http://localhost:8000/health

---

🌟 **Your Elite AI Agent System is now running in production!** 🌟 