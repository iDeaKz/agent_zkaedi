"""
Resilience Core - Production-grade retry, circuit breaker, and health check patterns.

A modular, configurable resilience library for robust system operations.
"""

from .config import ResilienceConfig
from .retry import retry_on_exception
from .health import HealthCheckThread
from .breaker import CircuitBreaker

__version__ = "0.1.0"
__author__ = "Resilience Core Team"

__all__ = [
    "ResilienceConfig",
    "retry_on_exception", 
    "HealthCheckThread",
    "CircuitBreaker"
] 