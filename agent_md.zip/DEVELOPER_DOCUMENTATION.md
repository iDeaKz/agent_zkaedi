# 🚀 Agent Monitoring Platform - Developer Documentation

**The Complete Developer's Guide to the Enterprise Agent Monitoring Ecosystem**

[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/downloads/)
[![TypeScript](https://img.shields.io/badge/typescript-5.0+-blue.svg)](https://www.typescriptlang.org/)
[![React](https://img.shields.io/badge/react-18+-blue.svg)](https://reactjs.org/)
[![FastAPI](https://img.shields.io/badge/fastapi-0.95+-green.svg)](https://fastapi.tiangolo.com/)

## 📖 Table of Contents

1. [🏗️ System Architecture](#-system-architecture)
2. [🔧 Core Components](#-core-components)
3. [🚀 Quick Start Guide](#-quick-start-guide)
4. [📊 API Reference](#-api-reference)
5. [🧩 Plugin System](#-plugin-system)
6. [🛡️ Security Framework](#-security-framework)
7. [📈 Monitoring & Observability](#-monitoring--observability)
8. [🔄 Resilience Patterns](#-resilience-patterns)
9. [🧪 Testing Strategy](#-testing-strategy)
10. [🚢 Deployment Guide](#-deployment-guide)
11. [🛠️ Development Workflow](#-development-workflow)

---

## 🏗️ System Architecture

### High-Level Overview

This is a production-grade agent monitoring platform consisting of:

- **Frontend Dashboard**: React 18 + TypeScript with Material-UI
- **Backend API**: FastAPI with comprehensive security and monitoring
- **Resilience Core**: Standalone package for fault tolerance patterns
- **Plugin System**: Secure sandboxed execution environment
- **Monitoring Stack**: Prometheus metrics with anomaly detection

### Technology Stack

#### Frontend Stack
- **React 18** - Modern UI framework with concurrent features
- **TypeScript** - Type-safe JavaScript with strict configuration
- **Material-UI v5** - Component library with theming
- **Vite** - Next-generation build tool and dev server
- **Three.js** - 3D visualizations and force-directed graphs
- **Chart.js** - Interactive data visualization
- **Framer Motion** - Smooth animations and transitions

#### Backend Stack
- **FastAPI** - High-performance Python API framework
- **Pydantic** - Data validation and serialization
- **SQLAlchemy** - Database ORM with audit logging
- **Redis** - Caching, session management, and real-time data
- **JWT** - Stateless authentication with refresh token rotation
- **Prometheus** - Metrics collection and monitoring

#### Infrastructure
- **Docker** - Containerization with multi-stage builds
- **Kubernetes** - Orchestration with Helm charts
- **GitHub Actions** - CI/CD pipeline with security scanning
- **Playwright** - End-to-end testing framework
- **Locust** - Load testing and performance benchmarking

---

## 🔧 Core Components

### 1. Dashboard Backend (`dashboard/backend/`)

#### Main Application (`main.py`)
The FastAPI application with comprehensive lifecycle management:

```python
@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup: Initialize all services
    initialize_resilience_system()
    await anomaly_engine.init_redis()
    plugin_health_check = initialize_plugin_health_check(plugin_manager)
    yield
    # Shutdown: Cleanup resources
    resilience_manager.stop_all_health_checks()
```

**Key Features:**
- Graceful startup/shutdown with resource cleanup
- CORS middleware for cross-origin requests
- Rate limiting with Redis backend (5/min login, 10/min actions, 100/min general)
- Comprehensive error handling with structured logging
- Health checks and metrics endpoints

#### Authentication System (`auth.py`, `auth_service.py`)
Advanced JWT authentication with security best practices:

```python
# Short-lived access tokens (5 minutes)
# Rotating refresh tokens (30 minutes)
# Device fingerprint binding
# IP hash verification for privacy
# RBAC with hierarchical roles
```

**Security Features:**
- Password hashing with bcrypt
- Environment-based credential management
- Token rotation on refresh
- Device fingerprinting for session security
- Rate limiting on authentication endpoints

#### Anomaly Detection (`anomaly_service.py`)
Real-time anomaly detection using ensemble machine learning:

```python
class AnomalyEngine:
    detectors = {
        "halfspace": HalfSpaceTrees(n_trees=10),
        "lof": LocalOutlierFactor(n_neighbors=20),
        "svm": OneClassSVM(nu=0.1)
    }
    # Dynamic threshold adjustment
    # Redis persistence with 7-day retention
    # WebSocket streaming interface
```

#### Plugin System (`plugin_sandbox.py`)
Secure execution environment with comprehensive isolation:

```python
class PluginSandbox:
    # Process isolation with subprocess
    # Resource limits (CPU: 5s, Memory: 256MB, Timeout: 10s)
    # Import whitelist validation
    # Checksum verification for integrity
    # Health monitoring with automatic recovery
```

### 2. Dashboard Frontend (`dashboard/frontend/`)

#### React Architecture
Plugin-based architecture with TypeScript:

```typescript
interface Plugin {
  name: string;
  init(): Promise<void>;
  destroy?(): Promise<void>;
  onError?(error: Error): void;
}

// Main plugins:
// - MetricsPlugin: Real-time data collection
// - VisualizationPlugin: Charts and 3D graphs
// - AgentPlugin: Agent lifecycle management
```

#### Component Structure
```
src/
├── components/
│   ├── AgentVisualization.tsx    # 3D network visualization
│   ├── AuditLogViewer.tsx       # Security audit interface
│   └── LoginDialog.tsx          # Authentication UI
├── config/
│   ├── security.ts              # CSP and security headers
│   ├── performance.ts           # Performance monitoring
│   └── accessibility.ts         # A11y configuration
├── plugins/
│   ├── PluginManager.ts         # Plugin lifecycle management
│   ├── usePlugin.ts             # React hooks for plugins
│   └── index.ts                 # Plugin registry
```

### 3. Resilience Core (`resilience_core/`)

Standalone Python package implementing fault tolerance patterns:

#### Retry Pattern
```python
@retry_on_exception(RetryConfig(
    max_attempts=3,
    base_delay=1.0,
    exponential_base=2.0,
    jitter=True
))
def unreliable_operation():
    # Your code with automatic retry
    pass
```

#### Circuit Breaker
```python
breaker = CircuitBreaker(CircuitBreakerConfig(
    failure_threshold=5,
    recovery_timeout=60.0
))
result = breaker.call(external_service_call)
```

#### Health Monitoring
```python
health_thread = HealthCheckThread(
    check_function=system_health_check,
    interval=30.0
)
health_thread.start()
```

---

## 🚀 Quick Start Guide

### Prerequisites
```bash
# Required software
- Python 3.10+
- Node.js 18+
- Redis 6+
- Git

# Optional for development
- Docker & Docker Compose
- PostgreSQL 14+ (production)
```

### One-Command Setup
```bash
# Clone and setup everything
git clone <repository-url>
cd agents
make install  # Installs all dependencies
make dev      # Starts all services
```

### Manual Setup

#### Backend Setup
```bash
cd dashboard/backend
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate
pip install -r requirements.txt

# Start Redis
docker run -d -p 6379:6379 redis:alpine

# Configure environment
cp .env.example .env
# Edit .env with your configuration

# Start backend
uvicorn main:app --reload --port 8000
```

#### Frontend Setup
```bash
cd dashboard/frontend
npm install

# Start development server
npm run dev
# Opens http://localhost:5173
```

### Environment Configuration
```bash
# .env file
JWT_SECRET=your-super-secret-jwt-key-here
ADMIN_USERNAME=admin
ADMIN_PASSWORD_HASH=hashed-password
REDIS_URL=redis://localhost:6379/0
DATABASE_URL=sqlite:///audit.db
```

---

## 📊 API Reference

### Authentication Endpoints

#### Login
```http
POST /auth/login
Content-Type: application/json

{
  "username": "admin",
  "password": "admin123"
}
```

Response:
```json
{
  "access_token": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9...",
  "refresh_token": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9...",
  "token_type": "bearer",
  "expires_in": 300
}
```

#### Refresh Token
```http
POST /auth/refresh
Authorization: Bearer <refresh_token>
```

### Agent Management

#### List Agents
```http
GET /agents
Authorization: Bearer <access_token>
```

Response:
```json
{
  "agents": [
    {
      "id": "agent1",
      "name": "Blockchain Agent",
      "status": "active",
      "metrics": {
        "cpu_usage": 45.2,
        "memory_usage": 256.5,
        "response_time": 106
      }
    }
  ]
}
```

#### Execute Agent Action
```http
POST /agents/{agent_id}/action
Authorization: Bearer <access_token>
Content-Type: application/json

{
  "action": "restart",
  "parameters": {
    "force": false,
    "timeout": 30
  }
}
```

### Anomaly Detection

#### Real-time Detection
```http
POST /anomaly/detect
Authorization: Bearer <access_token>
Content-Type: application/json

{
  "metric": "cpu_usage",
  "value": 95.0,
  "timestamp": 1640995200.0
}
```

#### WebSocket Stream
```javascript
const ws = new WebSocket('ws://localhost:8000/anomaly/ws/stream');
ws.onmessage = (event) => {
  const anomaly = JSON.parse(event.data);
  console.log('Real-time anomaly:', anomaly);
};
```

### Audit Logging

#### Create Audit Entry
```http
POST /audit
Authorization: Bearer <token>
Content-Type: application/json

{
  "actor": "admin",
  "action": "execute",
  "target": "agent:agent1",
  "meta": {
    "action_type": "restart",
    "parameters": {"force": false}
  }
}
```

#### Verify Audit Chain
```http
GET /audit/verify
Authorization: Bearer <token>
```

Response:
```json
{
  "valid": true,
  "total_entries": 1247,
  "checked_entries": 1247,
  "integrity_hash": "sha256:abc123..."
}
```

---

## 🛡️ Security Framework

### Authentication & Authorization

#### JWT Token Flow
- **Access tokens**: 5-minute lifespan for API requests
- **Refresh tokens**: 30-minute sliding window
- **Device fingerprinting**: Binds tokens to device characteristics
- **IP verification**: Privacy-preserving IP hash validation

#### RBAC (Role-Based Access Control)
```yaml
# rbac.yml structure
roles:
  ADMIN: [MANAGER]
  MANAGER: [USER]
  USER: [GUEST]

permissions:
  execute_plugin:
    roles: [ADMIN, MANAGER]
    conditions:
      payload_size: {max: 1048576}
```

### Security Headers
```python
security_headers = {
    'Strict-Transport-Security': 'max-age=31536000; includeSubDomains',
    'X-Content-Type-Options': 'nosniff',
    'X-Frame-Options': 'DENY',
    'X-XSS-Protection': '1; mode=block',
    'Referrer-Policy': 'strict-origin-when-cross-origin',
    'Content-Security-Policy': "default-src 'self'"
}
```

### Rate Limiting
```python
limits = {
    "/auth/login": "5/minute",      # Login attempts
    "/agents/*/action": "10/minute", # Agent actions
    "/api/*": "100/minute"          # General API
}
```

### Audit Trail
Every action is cryptographically logged with hash chaining:
```python
audit_entry = {
    "id": "uuid",
    "actor": "username",
    "action": "execute",
    "target": "agent:id",
    "timestamp": 1640995200.0,
    "hash": "sha256:current_hash",
    "prev_hash": "sha256:previous_hash"  # Chain link
}
```

---

## 📈 Monitoring & Observability

### Prometheus Metrics
```python
# HTTP request metrics
http_request_duration = Histogram(
    'http_request_duration_seconds',
    'HTTP request latency',
    ['method', 'endpoint', 'status_code']
)

# Business metrics
agent_actions_total = Counter(
    'agent_actions_total',
    'Total agent actions',
    ['agent_id', 'action', 'status']
)

# Anomaly detection metrics
anomaly_detections_total = Counter(
    'anomaly_detections_total',
    'Anomaly detections',
    ['metric', 'is_anomaly']
)
```

### Structured Logging
```python
# Contextual logging with trace IDs
logger.info(
    "plugin_executed",
    plugin_name=name,
    duration_ms=duration,
    success=result.success,
    trace_id=trace_id,
    request_id=request_id
)
```

### Health Checks
```http
GET /health
```

Response:
```json
{
  "status": "healthy",
  "timestamp": "2024-01-01T12:00:00Z",
  "version": "2.0.0",
  "components": {
    "database": "healthy",
    "redis": "healthy",
    "plugins": "healthy"
  }
}
```

---

## 🧪 Testing Strategy

### Test Pyramid
```
             E2E Tests (Playwright)
           ┌─────────────────────┐
          ┌─────────────────────────┐
         │  Integration Tests      │
        ├─────────────────────────────┤
       │     Unit Tests (Pytest)     │
      └─────────────────────────────────┘
```

### Running Tests
```bash
# All tests
make test

# Specific test suites
make test-unit          # Unit tests
make test-integration   # Integration tests
make test-security      # Security tests
make test-load          # Load tests with Locust

# Coverage report
make coverage
```

### Security Testing
```python
# Automated security test suite
class SecurityTests:
    def test_jwt_algorithm_confusion(self):
        # Test algorithm switching attacks
    
    def test_rate_limiting(self):
        # Verify rate limits are enforced
    
    def test_sql_injection(self):
        # Test parameterized queries
    
    def test_xss_protection(self):
        # Test input sanitization
```

---

## 🚢 Deployment Guide

### Docker Deployment

#### Multi-stage Dockerfile
```dockerfile
FROM python:3.11-slim as base
WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

FROM base as production
COPY . .
EXPOSE 8000
CMD ["uvicorn", "main:app", "--host", "0.0.0.0", "--port", "8000"]
```

#### Docker Compose
```yaml
version: '3.8'
services:
  backend:
    build: ./dashboard/backend
    ports: ["8000:8000"]
    environment:
      - REDIS_URL=redis://redis:6379
    depends_on: [redis]
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8000/health"]

  frontend:
    build: ./dashboard/frontend
    ports: ["3000:3000"]
    depends_on: [backend]

  redis:
    image: redis:7-alpine
    command: redis-server --appendonly yes
    healthcheck:
      test: ["CMD", "redis-cli", "ping"]
```

### Kubernetes Deployment
```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: agent-dashboard-backend
spec:
  replicas: 3
  template:
    spec:
      containers:
      - name: backend
        image: agent-dashboard:latest
        resources:
          requests: {memory: "256Mi", cpu: "250m"}
          limits: {memory: "512Mi", cpu: "500m"}
        livenessProbe:
          httpGet: {path: /health, port: 8000}
```

### CI/CD Pipeline
```yaml
# GitHub Actions
name: CI/CD Pipeline
on: [push, pull_request]

jobs:
  test:
    strategy:
      matrix:
        python-version: ['3.10', '3.11', '3.12']
    steps:
    - uses: actions/checkout@v4
    - name: Run tests
      run: pytest tests/ --cov=. --cov-report=xml
    - name: Security scan
      uses: pypa/gh-action-pip-audit@v1.0.8
```

---

## 🛠️ Development Workflow

### Development Commands
```bash
# Setup development environment
make install

# Start development servers
make dev

# Code quality
make lint        # Run linting
make format      # Format code
make type-check  # Type checking

# Testing
make test-watch  # Watch mode testing
make test-coverage  # Coverage report

# Database operations
make db-migrate  # Run migrations
make db-seed     # Seed test data

# Documentation
make docs        # Build documentation
make docs-serve  # Serve documentation locally
```

### Code Quality Tools
- **Black**: Code formatting (line length: 100)
- **isort**: Import sorting
- **flake8**: Linting with custom rules
- **mypy**: Static type checking
- **pytest**: Testing framework with fixtures
- **pre-commit**: Git hooks for quality checks

### Contributing Guidelines
1. Fork the repository
2. Create feature branch: `git checkout -b feature/amazing-feature`
3. Make changes with tests
4. Run quality checks: `make pre-commit`
5. Commit with conventional commits
6. Push and create pull request

### Performance Optimization
- Bundle size optimization with code splitting
- Lazy loading for components
- Resource timing monitoring
- Performance budgets in CI
- Lighthouse CI integration

---

## 🔍 Debugging & Troubleshooting

### Common Issues

#### Backend Won't Start
```bash
# Check dependencies
pip list | grep -E "(fastapi|uvicorn|redis)"

# Verify Redis connection
redis-cli ping

# Check port conflicts
netstat -tulpn | grep :8000

# View logs
tail -f logs/app.log
```

#### Frontend Build Errors
```bash
# Clear cache
npm run clean
rm -rf node_modules package-lock.json
npm install

# Check Node version
node --version  # Should be 18+
```

#### Plugin Execution Failures
```bash
# Check plugin sandbox logs
tail -f logs/plugins.log

# Verify resource limits
ps aux | grep python | grep plugin

# Test plugin locally
make test-plugin PLUGIN=my_plugin
```

### Monitoring Dashboard
Access comprehensive monitoring at:
- **Health**: http://localhost:8000/health
- **Metrics**: http://localhost:8000/prometheus
- **API Docs**: http://localhost:8000/docs
- **Frontend**: http://localhost:5173

---

## 📚 Additional Resources

### Documentation
- [API Reference](http://localhost:8000/docs) - Interactive OpenAPI documentation
- [Architecture Decision Records](./docs/adr/) - Design decisions and rationale
- [Plugin Development Guide](./docs/plugins.md) - Creating custom plugins
- [Security Best Practices](./docs/security.md) - Security guidelines

### External Links
- [FastAPI Documentation](https://fastapi.tiangolo.com/)
- [React Documentation](https://react.dev/)
- [Material-UI Components](https://mui.com/)
- [Prometheus Monitoring](https://prometheus.io/)

---

**Ready to build amazing agent monitoring solutions!** 🚀

For support, please open an issue in the GitHub repository or contact the development team. 