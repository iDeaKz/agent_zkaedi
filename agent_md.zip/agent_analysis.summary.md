# Data Summary
|Metric|Value|
|---|---|
|Value.count|17.0|
|Value.mean|65838.79701887711|
|Value.std|242452.48133145884|
|Value.min|-0.7590365418920992|
|Value.25%|0.0|
|Value.50%|0.278098071443637|
|Value.75%|0.7356670888402379|
|Value.max|1000000.0|
